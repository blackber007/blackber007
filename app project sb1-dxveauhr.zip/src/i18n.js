import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

// Import translations
import enTranslation from './locales/en.json';
import esTranslation from './locales/es.json';
import frTranslation from './locales/fr.json';
import deTranslation from './locales/de.json';
import ptTranslation from './locales/pt.json';
import zhTranslation from './locales/zh.json';
import jaTranslation from './locales/ja.json';
import arTranslation from './locales/ar.json';

// Initialize i18next
i18n
  .use(initReactI18next)
  .init({
    resources: {
      en: { translation: enTranslation },
      es: { translation: esTranslation },
      fr: { translation: frTranslation },
      de: { translation: deTranslation },
      pt: { translation: ptTranslation },
      zh: { translation: zhTranslation },
      ja: { translation: jaTranslation },
      ar: { translation: arTranslation }
    },
    lng: localStorage.getItem('appLanguage') || 'en',
    fallbackLng: 'en',
    interpolation: {
      escapeValue: false // React already escapes values
    }
  });

export default i18n;