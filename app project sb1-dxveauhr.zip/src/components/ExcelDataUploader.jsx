import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { FiUpload, FiCheck, FiAlertCircle } from 'react-icons/fi';
import * as XLSX from 'xlsx';
import { supabase } from '../lib/supabase';

const ExcelDataUploader = ({ onImportComplete }) => {
  const { t } = useTranslation();
  const [isUploading, setIsUploading] = useState(false);
  const [uploadStatus, setUploadStatus] = useState(null);
  const [importedData, setImportedData] = useState({
    harvests: [],
    yields: [],
    costs: [],
    allocations: []
  });

  const handleFileUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    setIsUploading(true);
    setUploadStatus(null);

    try {
      const workbook = await readExcelFile(file);
      
      // Process each sheet
      const processedData = {
        harvests: processHarvestSheet(workbook.Sheets[workbook.SheetNames[0]]),
        yields: processYieldSheet(workbook.Sheets[workbook.SheetNames[1]]),
        costs: processCostSheet(workbook.Sheets[workbook.SheetNames[2]]),
        allocations: processAllocationSheet(workbook.Sheets[workbook.SheetNames[3]])
      };

      setImportedData(processedData);
      await saveImportedData(processedData);

      setUploadStatus({
        success: true,
        message: t('excelImport.successMessage', { 
          count: Object.values(processedData).reduce((sum, arr) => sum + arr.length, 0)
        })
      });

      if (onImportComplete) {
        onImportComplete(processedData);
      }
    } catch (error) {
      console.error('Error importing Excel data:', error);
      setUploadStatus({
        success: false,
        message: t('excelImport.errorMessage', { error: error.message })
      });
    } finally {
      setIsUploading(false);
    }
  };

  const readExcelFile = (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      
      reader.onload = (e) => {
        try {
          const data = e.target.result;
          const workbook = XLSX.read(data, { type: 'array' });
          resolve(workbook);
        } catch (error) {
          reject(error);
        }
      };
      
      reader.onerror = (error) => reject(error);
      reader.readAsArrayBuffer(file);
    });
  };

  const processHarvestSheet = (sheet) => {
    const data = XLSX.utils.sheet_to_json(sheet, { header: 1 });
    if (data.length < 2) throw new Error(t('excelImport.noDataError'));

    const headers = data[0];
    const harvests = [];

    for (let i = 1; i < data.length; i++) {
      const row = data[i];
      if (row.length === 0) continue;

      const harvest = {
        date: row[headers.indexOf('Date')],
        project_id: row[headers.indexOf('Project ID')],
        field_id: row[headers.indexOf('Field ID')],
        product: row[headers.indexOf('Product')],
        quantity: parseFloat(row[headers.indexOf('Quantity')] || '0'),
        unit: row[headers.indexOf('Unit')],
        quality_grade: row[headers.indexOf('Quality Grade')],
        harvester_id: row[headers.indexOf('Harvester ID')],
        notes: row[headers.indexOf('Notes')]
      };

      if (harvest.quantity > 0) {
        harvests.push(harvest);
      }
    }

    return harvests;
  };

  const processYieldSheet = (sheet) => {
    const data = XLSX.utils.sheet_to_json(sheet, { header: 1 });
    if (data.length < 2) return [];

    const headers = data[0];
    const yields = [];

    for (let i = 1; i < data.length; i++) {
      const row = data[i];
      if (row.length === 0) continue;

      const yieldData = {
        project_id: row[headers.indexOf('Project ID')],
        field_id: row[headers.indexOf('Field ID')],
        period: row[headers.indexOf('Period')],
        expected_yield: parseFloat(row[headers.indexOf('Expected Yield')] || '0'),
        actual_yield: parseFloat(row[headers.indexOf('Actual Yield')] || '0'),
        yield_unit: row[headers.indexOf('Unit')],
        variance_percentage: parseFloat(row[headers.indexOf('Variance %')] || '0')
      };

      if (yieldData.actual_yield > 0) {
        yields.push(yieldData);
      }
    }

    return yields;
  };

  const processCostSheet = (sheet) => {
    const data = XLSX.utils.sheet_to_json(sheet, { header: 1 });
    if (data.length < 2) return [];

    const headers = data[0];
    const costs = [];

    for (let i = 1; i < data.length; i++) {
      const row = data[i];
      if (row.length === 0) continue;

      const cost = {
        date: row[headers.indexOf('Date')],
        project_id: row[headers.indexOf('Project ID')],
        category: row[headers.indexOf('Category')],
        description: row[headers.indexOf('Description')],
        amount: parseFloat(row[headers.indexOf('Amount')] || '0'),
        currency: row[headers.indexOf('Currency')],
        member_id: row[headers.indexOf('Member ID')],
        cost_type: row[headers.indexOf('Cost Type')]
      };

      if (cost.amount > 0) {
        costs.push(cost);
      }
    }

    return costs;
  };

  const processAllocationSheet = (sheet) => {
    const data = XLSX.utils.sheet_to_json(sheet, { header: 1 });
    if (data.length < 2) return [];

    const headers = data[0];
    const allocations = [];

    for (let i = 1; i < data.length; i++) {
      const row = data[i];
      if (row.length === 0) continue;

      const allocation = {
        project_id: row[headers.indexOf('Project ID')],
        member_id: row[headers.indexOf('Member ID')],
        contribution_amount: parseFloat(row[headers.indexOf('Contribution Amount')] || '0'),
        contribution_percentage: parseFloat(row[headers.indexOf('Contribution %')] || '0'),
        allocated_share: parseFloat(row[headers.indexOf('Allocated Share')] || '0'),
        start_date: row[headers.indexOf('Start Date')],
        end_date: row[headers.indexOf('End Date')],
        status: row[headers.indexOf('Status')] || 'active'
      };

      if (allocation.contribution_amount > 0) {
        allocations.push(allocation);
      }
    }

    return allocations;
  };

  const calculateRentability = (costs, revenues, memberContribution, totalContributions) => {
    const totalCosts = costs.reduce((sum, cost) => sum + cost.amount, 0);
    const totalRevenues = revenues.reduce((sum, rev) => sum + rev.amount, 0);
    const profit = totalRevenues - totalCosts;
    
    // Project rentability
    const projectRentability = totalCosts > 0 ? (profit / totalCosts) * 100 : 0;
    
    // Member proportional rentability
    const contributionShare = totalContributions > 0 ? memberContribution / totalContributions : 0;
    const memberProfit = profit * contributionShare;
    const memberRentability = memberContribution > 0 ? (memberProfit / memberContribution) * 100 : 0;

    return {
      projectRentability,
      memberRentability,
      memberProfit,
      contributionShare
    };
  };

  const saveImportedData = async (data) => {
    const { harvests, yields, costs, allocations } = data;

    try {
      // Save harvests
      for (const harvest of harvests) {
        const { error: harvestError } = await supabase
          .from('harvests')
          .insert([harvest]);

        if (harvestError) throw harvestError;
      }

      // Save yields
      for (const yieldData of yields) {
        const { error: yieldError } = await supabase
          .from('yields')
          .insert([yieldData]);

        if (yieldError) throw yieldError;
      }

      // Save costs
      for (const cost of costs) {
        const { error: costError } = await supabase
          .from('costs')
          .insert([cost]);

        if (costError) throw costError;
      }

      // Save allocations
      for (const allocation of allocations) {
        const { error: allocationError } = await supabase
          .from('allocations')
          .insert([allocation]);

        if (allocationError) throw allocationError;
      }

      // Log import success
      await supabase
        .from('system_logs')
        .insert([{
          event_type: 'HARVEST_DATA_IMPORT',
          details: {
            harvests_count: harvests.length,
            yields_count: yields.length,
            costs_count: costs.length,
            allocations_count: allocations.length
          }
        }]);

    } catch (error) {
      console.error('Error saving imported data:', error);
      throw error;
    }
  };

  return (
    <div className="bg-white shadow rounded-lg p-6">
      <h2 className="text-lg font-semibold mb-4">{t('excelImport.title')}</h2>
      
      <div className="space-y-4">
        <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
          <input
            type="file"
            id="excel-file"
            accept=".xlsx,.xls"
            className="hidden"
            onChange={handleFileUpload}
            disabled={isUploading}
          />
          <label
            htmlFor="excel-file"
            className="cursor-pointer flex flex-col items-center justify-center"
          >
            <FiUpload className="h-10 w-10 text-gray-400 mb-2" />
            <span className="text-sm font-medium text-gray-900">
              {t('excelImport.dropzoneText')}
            </span>
            <span className="text-xs text-gray-500 mt-1">
              {t('excelImport.fileTypes')}
            </span>
            <button
              type="button"
              className="mt-4 btn btn-primary text-sm"
              onClick={() => document.getElementById('excel-file').click()}
              disabled={isUploading}
            >
              {isUploading ? t('excelImport.uploading') : t('excelImport.selectFile')}
            </button>
          </label>
        </div>
        
        {uploadStatus && (
          <div className={`p-4 rounded-md ${uploadStatus.success ? 'bg-green-50' : 'bg-red-50'}`}>
            <div className="flex">
              <div className="flex-shrink-0">
                {uploadStatus.success ? (
                  <FiCheck className="h-5 w-5 text-green-400" />
                ) : (
                  <FiAlertCircle className="h-5 w-5 text-red-400" />
                )}
              </div>
              <div className="ml-3">
                <p className={`text-sm font-medium ${uploadStatus.success ? 'text-green-800' : 'text-red-800'}`}>
                  {uploadStatus.message}
                </p>
              </div>
            </div>
          </div>
        )}
        
        {/* Preview imported data */}
        {Object.entries(importedData).map(([type, items]) => items.length > 0 && (
          <div key={type} className="mt-6">
            <h3 className="text-md font-medium mb-2">
              {t(`excelImport.imported${type.charAt(0).toUpperCase() + type.slice(1)}`)}
            </h3>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    {Object.keys(items[0]).map(key => (
                      <th key={key} scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        {key.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {items.slice(0, 5).map((item, index) => (
                    <tr key={index}>
                      {Object.values(item).map((value, i) => (
                        <td key={i} className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">
                          {value?.toString() || '-'}
                        </td>
                      ))}
                    </tr>
                  ))}
                  {items.length > 5 && (
                    <tr>
                      <td colSpan={Object.keys(items[0]).length} className="px-4 py-3 text-sm text-gray-500 text-center">
                        {t('excelImport.moreRecords', { count: items.length - 5 })}
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ExcelDataUploader;