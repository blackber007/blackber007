import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useTranslation } from 'react-i18next';
import { FiGlobe } from 'react-icons/fi';

function LanguageSelector() {
  const { t } = useTranslation();
  const { currentLanguage, languages, changeLanguage } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const handleLanguageChange = (langCode) => {
    changeLanguage(langCode);
    setIsOpen(false);
  };

  const getLanguageDisplayName = (code) => {
    switch(code) {
      case 'en': return t('language.english');
      case 'es': return t('language.spanish');
      case 'fr': return t('language.french');
      case 'de': return t('language.german');
      case 'pt': return t('language.portuguese');
      case 'zh': return t('language.chinese');
      case 'ja': return t('language.japanese');
      case 'ar': return t('language.arabic');
      default: return 'English';
    }
  };

  return (
    <div className="relative">
      <button
        type="button"
        className="flex items-center text-gray-600 hover:text-gray-900 focus:outline-none"
        id="language-menu-button"
        aria-expanded={isOpen}
        aria-haspopup="true"
        onClick={toggleMenu}
      >
        <FiGlobe className="mr-1 text-lg" />
        <span className="hidden md:inline-block">
          {languages.find(lang => lang.code === currentLanguage)?.name || 'English'}
        </span>
      </button>

      {isOpen && (
        <div
          className="origin-top-right absolute right-0 mt-2 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 focus:outline-none z-10"
          role="menu"
          aria-orientation="vertical"
          aria-labelledby="language-menu-button"
          tabIndex="-1"
        >
          <div className="py-1" role="none">
            {languages.map(language => (
              <button
                key={language.code}
                onClick={() => handleLanguageChange(language.code)}
                className={`block px-4 py-2 text-sm w-full text-left ${
                  currentLanguage === language.code
                    ? 'bg-primary-50 text-primary-600'
                    : 'text-gray-700 hover:bg-gray-50 hover:text-gray-900'
                }`}
                role="menuitem"
                tabIndex="-1"
              >
                {getLanguageDisplayName(language.code)}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default LanguageSelector;