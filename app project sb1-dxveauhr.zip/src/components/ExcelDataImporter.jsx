import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { FiUpload, FiCheck, FiAlertCircle } from 'react-icons/fi';
import * as XLSX from 'xlsx';
import { supabase } from '../lib/supabase';

const ExcelDataImporter = ({ onImportComplete }) => {
  const { t } = useTranslation();
  const [isUploading, setIsUploading] = useState(false);
  const [uploadStatus, setUploadStatus] = useState(null);
  const [importedData, setImportedData] = useState([]);

  const handleFileUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    setIsUploading(true);
    setUploadStatus(null);

    try {
      // Read the Excel file
      const data = await readExcelFile(file);
      
      // Process and validate the data
      const processedData = processExcelData(data);
      
      // Store the data in state
      setImportedData(processedData);
      
      // Save the data to Supabase
      await saveImportedData(processedData);
      
      setUploadStatus({
        success: true,
        message: t('excelImport.successMessage', { count: processedData.length })
      });
      
      if (onImportComplete) {
        onImportComplete(processedData);
      }
    } catch (error) {
      console.error('Error importing Excel data:', error);
      setUploadStatus({
        success: false,
        message: t('excelImport.errorMessage', { error: error.message })
      });
    } finally {
      setIsUploading(false);
    }
  };

  const readExcelFile = (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      
      reader.onload = (e) => {
        try {
          const data = e.target.result;
          const workbook = XLSX.read(data, { type: 'array' });
          
          // Get the first worksheet
          const worksheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[worksheetName];
          
          // Convert to JSON
          const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
          resolve(jsonData);
        } catch (error) {
          reject(error);
        }
      };
      
      reader.onerror = (error) => {
        reject(error);
      };
      
      reader.readAsArrayBuffer(file);
    });
  };

  const processExcelData = (data) => {
    // Assuming the first row contains headers
    if (data.length < 2) {
      throw new Error(t('excelImport.noDataError'));
    }
    
    const headers = data[0];
    const processedData = [];
    
    // Map Excel columns to our data structure
    for (let i = 1; i < data.length; i++) {
      const row = data[i];
      if (row.length === 0) continue; // Skip empty rows
      
      const item = {};
      headers.forEach((header, index) => {
        // Map Excel headers to our field names
        const fieldName = mapHeaderToField(header);
        if (fieldName && index < row.length) {
          item[fieldName] = row[index];
        }
      });
      
      // Validate required fields
      if (item.email) { // Email is the minimum required field
        processedData.push(item);
      }
    }
    
    return processedData;
  };

  const mapHeaderToField = (header) => {
    // Convert header to lowercase for case-insensitive matching
    const headerLower = String(header).toLowerCase().trim();
    
    // Map Excel headers to our field names
    const headerMap = {
      'email': 'email',
      'e-mail': 'email',
      'mail': 'email',
      'name': 'full_name',
      'full name': 'full_name',
      'fullname': 'full_name',
      'full_name': 'full_name',
      'company': 'company',
      'organization': 'company',
      'position': 'position',
      'title': 'position',
      'job title': 'position',
      'phone': 'phone',
      'phone number': 'phone',
      'telephone': 'phone'
    };
    
    return headerMap[headerLower] || null;
  };

  const saveImportedData = async (data) => {
    // Save the imported data to Supabase
    const { error } = await supabase
      .from('imported_excel_data')
      .insert(data.map(item => ({
        email: item.email,
        full_name: item.full_name,
        company: item.company,
        position: item.position,
        phone: item.phone,
        imported_at: new Date()
      })));
      
    if (error) throw error;
  };

  return (
    <div className="bg-white shadow rounded-lg p-6">
      <h2 className="text-lg font-semibold mb-4">{t('excelImport.title')}</h2>
      
      <div className="space-y-4">
        <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
          <input
            type="file"
            id="excel-file"
            accept=".xlsx,.xls"
            className="hidden"
            onChange={handleFileUpload}
            disabled={isUploading}
          />
          <label
            htmlFor="excel-file"
            className="cursor-pointer flex flex-col items-center justify-center"
          >
            <FiUpload className="h-10 w-10 text-gray-400 mb-2" />
            <span className="text-sm font-medium text-gray-900">
              {t('excelImport.dropzoneText')}
            </span>
            <span className="text-xs text-gray-500 mt-1">
              {t('excelImport.fileTypes')}
            </span>
            <button
              type="button"
              className="mt-4 btn btn-primary text-sm"
              onClick={() => document.getElementById('excel-file').click()}
              disabled={isUploading}
            >
              {isUploading ? t('excelImport.uploading') : t('excelImport.selectFile')}
            </button>
          </label>
        </div>
        
        {uploadStatus && (
          <div className={`p-4 rounded-md ${uploadStatus.success ? 'bg-green-50' : 'bg-red-50'}`}>
            <div className="flex">
              <div className="flex-shrink-0">
                {uploadStatus.success ? (
                  <FiCheck className="h-5 w-5 text-green-400" />
                ) : (
                  <FiAlertCircle className="h-5 w-5 text-red-400" />
                )}
              </div>
              <div className="ml-3">
                <p className={`text-sm font-medium ${uploadStatus.success ? 'text-green-800' : 'text-red-800'}`}>
                  {uploadStatus.message}
                </p>
              </div>
            </div>
          </div>
        )}
        
        {importedData.length > 0 && (
          <div className="mt-6">
            <h3 className="text-md font-medium mb-2">{t('excelImport.importedData')}</h3>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('auth.email')}
                    </th>
                    <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('profile.fullName')}
                    </th>
                    <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('profile.company')}
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {importedData.slice(0, 5).map((item, index) => (
                    <tr key={index}>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">{item.email}</td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">{item.full_name || '-'}</td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">{item.company || '-'}</td>
                    </tr>
                  ))}
                  {importedData.length > 5 && (
                    <tr>
                      <td colSpan="3" className="px-4 py-3 text-sm text-gray-500 text-center">
                        {t('excelImport.moreRecords', { count: importedData.length - 5 })}
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ExcelDataImporter;