import React from 'react';
import { useTranslation } from 'react-i18next';
import { FiTrendingUp, FiTrendingDown, FiDollarSign, FiUsers, FiActivity } from 'react-icons/fi';

const DashboardMetrics = ({ metrics }) => {
  const { t } = useTranslation();

  const getMetricIcon = (type) => {
    switch (type) {
      case 'revenue':
        return <FiDollarSign className="h-6 w-6" />;
      case 'users':
        return <FiUsers className="h-6 w-6" />;
      case 'activity':
        return <FiActivity className="h-6 w-6" />;
      case 'trending_up':
        return <FiTrendingUp className="h-6 w-6" />;
      case 'trending_down':
        return <FiTrendingDown className="h-6 w-6" />;
      default:
        return <FiActivity className="h-6 w-6" />;
    }
  };

  const getMetricColor = (trend) => {
    if (trend > 0) return 'text-green-600 bg-green-100';
    if (trend < 0) return 'text-red-600 bg-red-100';
    return 'text-blue-600 bg-blue-100';
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {metrics.map((metric, index) => (
        <div key={index} className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
          <div className="flex items-center">
            <div className={`p-3 rounded-full ${getMetricColor(metric.trend)}`}>
              {getMetricIcon(metric.type)}
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-500">{metric.label}</p>
              <div className="flex items-baseline">
                <p className="text-2xl font-semibold">{metric.value}</p>
                {metric.trend !== 0 && (
                  <span className={`ml-2 text-sm ${metric.trend > 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {metric.trend > 0 ? '+' : ''}{metric.trend}%
                  </span>
                )}
              </div>
            </div>
          </div>
          {metric.subtext && (
            <p className="mt-2 text-sm text-gray-500">{metric.subtext}</p>
          )}
        </div>
      ))}
    </div>
  );
};

export default DashboardMetrics;