import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { FiCheck, FiX, FiAlertCircle } from 'react-icons/fi';

const DataComparisonModal = ({ isOpen, onClose, userData, existingData, onConfirm }) => {
  const { t } = useTranslation();
  const [comparisonResults, setComparisonResults] = useState([]);
  const [selectedItems, setSelectedItems] = useState({});
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    if (userData && existingData) {
      // Compare the data and generate results
      const results = compareData(userData, existingData);
      setComparisonResults(results);
      
      // Initialize selected items with user data as default
      const initialSelection = {};
      results.forEach(item => {
        initialSelection[item.field] = 'user';
      });
      setSelectedItems(initialSelection);
    }
  }, [userData, existingData]);

  const compareData = (userData, existingData) => {
    // Fields to compare
    const fieldsToCompare = [
      { field: 'full_name', label: t('profile.fullName') },
      { field: 'email', label: t('auth.email') },
      { field: 'company', label: t('profile.company') },
      { field: 'position', label: t('profile.position') },
      { field: 'phone', label: t('profile.phone') }
    ];

    return fieldsToCompare
      .filter(item => userData[item.field] || existingData[item.field])
      .map(item => ({
        field: item.field,
        label: item.label,
        userData: userData[item.field] || '',
        existingData: existingData[item.field] || '',
        isDifferent: userData[item.field] !== existingData[item.field]
      }));
  };

  const handleSelectionChange = (field, source) => {
    setSelectedItems(prev => ({
      ...prev,
      [field]: source
    }));
  };

  const handleConfirm = async () => {
    setIsProcessing(true);
    
    try {
      // Create merged data based on selections
      const mergedData = {};
      comparisonResults.forEach(item => {
        const source = selectedItems[item.field];
        mergedData[item.field] = source === 'user' ? item.userData : item.existingData;
      });
      
      // Call the onConfirm callback with the merged data
      await onConfirm(mergedData);
      onClose();
    } catch (error) {
      console.error('Error merging data:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div className="fixed inset-0 transition-opacity" aria-hidden="true">
          <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
        </div>

        <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>

        <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
          <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
            <div className="sm:flex sm:items-start">
              <div className="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-yellow-100 sm:mx-0 sm:h-10 sm:w-10">
                <FiAlertCircle className="h-6 w-6 text-yellow-600" />
              </div>
              <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left w-full">
                <h3 className="text-lg leading-6 font-medium text-gray-900">
                  {t('dataComparison.title')}
                </h3>
                <div className="mt-2">
                  <p className="text-sm text-gray-500 mb-4">
                    {t('dataComparison.description')}
                  </p>
                  
                  {comparisonResults.length > 0 ? (
                    <div className="mt-4 border rounded-lg overflow-hidden">
                      <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                          <tr>
                            <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              {t('dataComparison.field')}
                            </th>
                            <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              {t('dataComparison.yourData')}
                            </th>
                            <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              {t('dataComparison.existingData')}
                            </th>
                            <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              {t('dataComparison.select')}
                            </th>
                          </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                          {comparisonResults.map((item) => (
                            <tr key={item.field} className={item.isDifferent ? "bg-yellow-50" : ""}>
                              <td className="px-4 py-3 whitespace-nowrap text-sm font-medium text-gray-900">
                                {item.label}
                              </td>
                              <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">
                                {item.userData || <span className="text-gray-400 italic">{t('dataComparison.noData')}</span>}
                              </td>
                              <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">
                                {item.existingData || <span className="text-gray-400 italic">{t('dataComparison.noData')}</span>}
                              </td>
                              <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">
                                {item.isDifferent ? (
                                  <div className="flex space-x-2">
                                    <button
                                      type="button"
                                      className={`px-2 py-1 rounded text-xs ${
                                        selectedItems[item.field] === 'user'
                                          ? 'bg-blue-100 text-blue-800 border border-blue-500'
                                          : 'bg-gray-100 text-gray-800 border border-gray-300'
                                      }`}
                                      onClick={() => handleSelectionChange(item.field, 'user')}
                                    >
                                      {t('dataComparison.yours')}
                                    </button>
                                    <button
                                      type="button"
                                      className={`px-2 py-1 rounded text-xs ${
                                        selectedItems[item.field] === 'existing'
                                          ? 'bg-blue-100 text-blue-800 border border-blue-500'
                                          : 'bg-gray-100 text-gray-800 border border-gray-300'
                                      }`}
                                      onClick={() => handleSelectionChange(item.field, 'existing')}
                                    >
                                      {t('dataComparison.existing')}
                                    </button>
                                  </div>
                                ) : (
                                  <span className="text-green-500 flex items-center">
                                    <FiCheck className="mr-1" /> {t('dataComparison.match')}
                                  </span>
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="text-center py-4 text-gray-500">
                      {t('dataComparison.noDataToCompare')}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
          <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
            <button
              type="button"
              className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-primary-600 text-base font-medium text-white hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 sm:ml-3 sm:w-auto sm:text-sm"
              onClick={handleConfirm}
              disabled={isProcessing}
            >
              {isProcessing ? t('common.processing') : t('dataComparison.confirm')}
            </button>
            <button
              type="button"
              className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
              onClick={onClose}
              disabled={isProcessing}
            >
              {t('common.cancel')}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DataComparisonModal;