import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { FiPlus, FiEdit2, FiTrash2, FiMove, FiClock } from 'react-icons/fi';
import { DndContext, closestCenter, KeyboardSensor, PointerSensor, useSensor, useSensors } from '@dnd-kit/core';
import { arrayMove, SortableContext, sortableKeyboardCoordinates, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { supabase } from '../lib/supabase';
import CategoryHistory from './CategoryHistory';

const ExpenseCategoryManager = ({ projectId, isProjectLeader }) => {
  const { t } = useTranslation();
  const [categories, setCategories] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [showHistory, setShowHistory] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    notes: ''
  });

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  useEffect(() => {
    fetchCategories();
  }, [projectId]);

  const fetchCategories = async () => {
    try {
      const { data, error } = await supabase
        .from('expense_categories')
        .select('*')
        .eq('project_id', projectId)
        .order('order_index');

      if (error) throw error;
      setCategories(data || []);
    } catch (err) {
      console.error('Error fetching categories:', err);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingCategory) {
        const { error } = await supabase
          .from('expense_categories')
          .update({
            name: formData.name,
            notes: formData.notes
          })
          .eq('id', editingCategory.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('expense_categories')
          .insert([{
            project_id: projectId,
            name: formData.name,
            notes: formData.notes,
            order_index: categories.length
          }]);

        if (error) throw error;
      }

      setIsModalOpen(false);
      setEditingCategory(null);
      setFormData({ name: '', notes: '' });
      fetchCategories();
    } catch (err) {
      console.error('Error saving category:', err);
    }
  };

  const handleEdit = (category) => {
    setEditingCategory(category);
    setFormData({
      name: category.name,
      notes: category.notes || ''
    });
    setIsModalOpen(true);
  };

  const handleDelete = async (categoryId) => {
    if (!confirm(t('expenses.confirmDeleteCategory'))) return;

    try {
      const { error } = await supabase
        .from('expense_categories')
        .delete()
        .eq('id', categoryId);

      if (error) throw error;
      fetchCategories();
    } catch (err) {
      console.error('Error deleting category:', err);
    }
  };

  const handleViewHistory = (category) => {
    setSelectedCategory(category);
    setShowHistory(true);
  };

  const handleDragEnd = async (event) => {
    const { active, over } = event;
    
    if (active.id !== over.id) {
      const oldIndex = categories.findIndex(cat => cat.id === active.id);
      const newIndex = categories.findIndex(cat => cat.id === over.id);
      
      const newCategories = arrayMove(categories, oldIndex, newIndex);
      setCategories(newCategories);

      // Update order indexes in database
      try {
        const updates = newCategories.map((category, index) => ({
          id: category.id,
          order_index: index
        }));

        const { error } = await supabase
          .from('expense_categories')
          .upsert(updates);

        if (error) throw error;
      } catch (err) {
        console.error('Error updating category order:', err);
        fetchCategories(); // Revert to original order on error
      }
    }
  };

  const SortableItem = ({ id, category, onEdit, onDelete, isProjectLeader }) => {
    const {
      attributes,
      listeners,
      setNodeRef,
      transform,
      transition,
    } = useSortable({ id });

    const style = {
      transform: CSS.Transform.toString(transform),
      transition,
    };

    return (
      <div
        ref={setNodeRef}
        style={style}
        className="flex items-center justify-between p-4 bg-white border border-gray-200 rounded-lg mb-2 hover:shadow-md transition-shadow"
      >
        <div className="flex items-center flex-1">
          {isProjectLeader && (
            <button
              className="mr-2 text-gray-400 hover:text-gray-600 cursor-move"
              {...attributes}
              {...listeners}
            >
              <FiMove />
            </button>
          )}
          <div className="flex-1">
            <h3 className="font-medium text-gray-900">{category.name}</h3>
            {category.notes && (
              <p className="text-sm text-gray-500">{category.notes}</p>
            )}
          </div>
        </div>
        <div className="flex space-x-2">
          <button
            onClick={() => handleViewHistory(category)}
            className="text-gray-600 hover:text-gray-800"
            title="View history"
          >
            <FiClock />
          </button>
          {isProjectLeader && (
            <>
              <button
                onClick={() => onEdit(category)}
                className="text-blue-600 hover:text-blue-800"
                title="Edit category"
              >
                <FiEdit2 />
              </button>
              <button
                onClick={() => onDelete(category.id)}
                className="text-red-600 hover:text-red-800"
                title="Delete category"
              >
                <FiTrash2 />
              </button>
            </>
          )}
        </div>
      </div>
    );
  };

  const HistoryModal = () => (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div className="fixed inset-0 transition-opacity">
          <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
        </div>

        <span className="hidden sm:inline-block sm:align-middle sm:h-screen">&#8203;</span>

        <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
          <div className="bg-white px-4 pt-5 pb-4 sm:p-6">
            <div className="sm:flex sm:items-start">
              <div className="mt-3 text-center sm:mt-0 sm:text-left w-full">
                <h3 className="text-lg font-medium text-gray-900 mb-4">
                  Category History
                </h3>
                <CategoryHistory categoryId={selectedCategory?.id} />
              </div>
            </div>
          </div>
          <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => {
                setShowHistory(false);
                setSelectedCategory(null);
              }}
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-lg font-semibold">{t('expenses.categories')}</h2>
        {isProjectLeader && (
          <button
            onClick={() => {
              setEditingCategory(null);
              setFormData({ name: '', notes: '' });
              setIsModalOpen(true);
            }}
            className="btn btn-primary flex items-center"
          >
            <FiPlus className="mr-2" />
            {t('expenses.addCategory')}
          </button>
        )}
      </div>

      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragEnd={handleDragEnd}
      >
        <SortableContext
          items={categories.map(cat => cat.id)}
          strategy={verticalListSortingStrategy}
        >
          {categories.map((category) => (
            <SortableItem
              key={category.id}
              id={category.id}
              category={category}
              onEdit={handleEdit}
              onDelete={handleDelete}
              isProjectLeader={isProjectLeader}
            />
          ))}
        </SortableContext>
      </DndContext>

      {/* Add/Edit Category Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 transition-opacity">
              <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
            </div>

            <span className="hidden sm:inline-block sm:align-middle sm:h-screen">&#8203;</span>

            <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
              <form onSubmit={handleSubmit}>
                <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                  <h3 className="text-lg font-medium text-gray-900 mb-4">
                    {editingCategory ? t('expenses.editCategory') : t('expenses.addCategory')}
                  </h3>

                  <div className="mb-4">
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                      {t('expenses.categoryName')}
                    </label>
                    <input
                      type="text"
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                      required
                    />
                  </div>

                  <div className="mb-4">
                    <label htmlFor="notes" className="block text-sm font-medium text-gray-700">
                      {t('expenses.categoryNotes')}
                    </label>
                    <textarea
                      id="notes"
                      value={formData.notes}
                      onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                      rows="3"
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                    />
                  </div>
                </div>

                <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                  <button
                    type="submit"
                    className="btn btn-primary sm:ml-3"
                  >
                    {editingCategory ? t('common.save') : t('common.add')}
                  </button>
                  <button
                    type="button"
                    className="btn btn-secondary mt-3 sm:mt-0"
                    onClick={() => setIsModalOpen(false)}
                  >
                    {t('common.cancel')}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Add History Modal */}
      {showHistory && selectedCategory && <HistoryModal />}
    </div>
  );
};

export default ExpenseCategoryManager;