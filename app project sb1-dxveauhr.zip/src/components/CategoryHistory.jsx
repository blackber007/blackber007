import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { format } from 'date-fns';
import { FiClock, FiEdit2, FiTrash2, FiMove, FiPlus } from 'react-icons/fi';
import { supabase } from '../lib/supabase';

const CategoryHistory = ({ categoryId }) => {
  const { t } = useTranslation();
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchHistory();
  }, [categoryId]);

  const fetchHistory = async () => {
    try {
      const { data, error } = await supabase
        .from('category_history')
        .select(`
          *,
          changed_by:profiles!category_history_changed_by_fkey(full_name, email)
        `)
        .eq('category_id', categoryId)
        .order('changed_at', { ascending: false });

      if (error) throw error;
      setHistory(data || []);
    } catch (err) {
      console.error('Error fetching category history:', err);
    } finally {
      setLoading(false);
    }
  };

  const getChangeIcon = (changeType) => {
    switch (changeType) {
      case 'create':
        return <FiPlus className="text-green-500" />;
      case 'update':
        return <FiEdit2 className="text-blue-500" />;
      case 'delete':
        return <FiTrash2 className="text-red-500" />;
      case 'reorder':
        return <FiMove className="text-yellow-500" />;
      default:
        return <FiClock className="text-gray-500" />;
    }
  };

  const getChangeDescription = (change) => {
    const changedBy = change.changed_by?.full_name || change.changed_by?.email || 'Unknown';
    
    switch (change.change_type) {
      case 'create':
        return `Created by ${changedBy}`;
      case 'update':
        const changes = [];
        if (change.old_values.name !== change.new_values.name) {
          changes.push(`name from "${change.old_values.name}" to "${change.new_values.name}"`);
        }
        if (change.old_values.notes !== change.new_values.notes) {
          changes.push('notes');
        }
        return `Updated ${changes.join(' and ')} by ${changedBy}`;
      case 'delete':
        return `Deleted by ${changedBy}`;
      case 'reorder':
        return `Reordered by ${changedBy}`;
      default:
        return `Modified by ${changedBy}`;
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-32">
        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-medium text-gray-900">Change History</h3>
      <div className="space-y-2">
        {history.map((change) => (
          <div
            key={change.id}
            className="flex items-start space-x-3 p-3 bg-white rounded-lg border border-gray-200"
          >
            <div className="flex-shrink-0 mt-1">
              {getChangeIcon(change.change_type)}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm text-gray-900">
                {getChangeDescription(change)}
              </p>
              <p className="text-xs text-gray-500">
                {format(new Date(change.changed_at), 'MMM d, yyyy HH:mm:ss')}
              </p>
            </div>
          </div>
        ))}
        {history.length === 0 && (
          <p className="text-sm text-gray-500 text-center py-4">
            No history available
          </p>
        )}
      </div>
    </div>
  );
};

export default CategoryHistory;