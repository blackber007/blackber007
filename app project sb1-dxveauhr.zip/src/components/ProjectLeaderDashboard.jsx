import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { FiActivity, FiUsers, FiDollarSign, FiTrendingUp, FiAlertCircle } from 'react-icons/fi';
import { supabase } from '../lib/supabase';
import { Line } from 'react-chartjs-2';
import { format } from 'date-fns';

const ProjectLeaderDashboard = ({ projectId }) => {
  const { t } = useTranslation();
  const [stats, setStats] = useState({
    totalMembers: 0,
    activeMembers: 0,
    totalTransactions: 0,
    totalCategories: 0,
    recentActivity: []
  });
  const [loading, setLoading] = useState(true);
  const [chartData, setChartData] = useState(null);

  useEffect(() => {
    fetchProjectStats();
  }, [projectId]);

  const fetchProjectStats = async () => {
    try {
      setLoading(true);
      
      // Fetch member stats
      const { data: members } = await supabase
        .from('project_members')
        .select('*')
        .eq('project_id', projectId);

      // Fetch transaction stats
      const { data: transactions } = await supabase
        .from('transactions')
        .select('*')
        .eq('project_id', projectId)
        .order('date', { ascending: false });

      // Fetch category stats
      const { data: categories } = await supabase
        .from('expense_categories')
        .select('*')
        .eq('project_id', projectId);

      // Fetch recent activity
      const { data: activity } = await supabase
        .from('category_history')
        .select(`
          *,
          changed_by:profiles!category_history_changed_by_fkey(full_name, email)
        `)
        .eq('project_id', projectId)
        .order('changed_at', { ascending: false })
        .limit(5);

      // Prepare chart data
      const last7Days = Array.from({ length: 7 }, (_, i) => {
        const date = new Date();
        date.setDate(date.getDate() - i);
        return format(date, 'yyyy-MM-dd');
      }).reverse();

      const chartData = {
        labels: last7Days,
        datasets: [
          {
            label: 'Transactions',
            data: last7Days.map(date => 
              transactions?.filter(t => t.date.startsWith(date)).length || 0
            ),
            borderColor: '#2aabf3',
            tension: 0.4
          }
        ]
      };

      setChartData(chartData);
      setStats({
        totalMembers: members?.length || 0,
        activeMembers: members?.filter(m => m.last_active_at > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)).length || 0,
        totalTransactions: transactions?.length || 0,
        totalCategories: categories?.length || 0,
        recentActivity: activity || []
      });
    } catch (err) {
      console.error('Error fetching project stats:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-blue-100 text-blue-600">
              <FiUsers className="h-6 w-6" />
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-500">Total Members</p>
              <p className="text-2xl font-semibold">{stats.totalMembers}</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-green-100 text-green-600">
              <FiActivity className="h-6 w-6" />
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-500">Active Members</p>
              <p className="text-2xl font-semibold">{stats.activeMembers}</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-purple-100 text-purple-600">
              <FiDollarSign className="h-6 w-6" />
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-500">Total Transactions</p>
              <p className="text-2xl font-semibold">{stats.totalTransactions}</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-yellow-100 text-yellow-600">
              <FiTrendingUp className="h-6 w-6" />
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-500">Categories</p>
              <p className="text-2xl font-semibold">{stats.totalCategories}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold mb-4">Activity Overview</h3>
          {chartData && (
            <div className="h-64">
              <Line 
                data={chartData}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  scales: {
                    y: {
                      beginAtZero: true,
                      ticks: {
                        stepSize: 1
                      }
                    }
                  }
                }}
              />
            </div>
          )}
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold mb-4">Recent Activity</h3>
          <div className="space-y-4">
            {stats.recentActivity.length > 0 ? (
              stats.recentActivity.map((activity) => (
                <div key={activity.id} className="flex items-start space-x-3">
                  <div className="flex-shrink-0">
                    <FiAlertCircle className="h-5 w-5 text-blue-500" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-900">
                      {activity.changed_by?.full_name || activity.changed_by?.email} 
                      {' '}
                      {activity.change_type === 'create' ? 'created' : 
                       activity.change_type === 'update' ? 'updated' :
                       activity.change_type === 'delete' ? 'deleted' : 
                       'modified'} a category
                    </p>
                    <p className="text-xs text-gray-500">
                      {format(new Date(activity.changed_at), 'MMM d, yyyy HH:mm')}
                    </p>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-sm text-gray-500 text-center">No recent activity</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProjectLeaderDashboard;