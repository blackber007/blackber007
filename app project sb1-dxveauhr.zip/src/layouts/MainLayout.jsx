import React, { useState, useEffect } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useProjects } from '../contexts/ProjectsContext';
import { useTranslation } from 'react-i18next';
import { FiHome, FiFolder, FiUsers, FiDollarSign, FiUser, FiMenu, FiX, FiLogOut, FiSettings } from 'react-icons/fi';
import LanguageSelector from '../components/LanguageSelector';

function MainLayout() {
  const { t } = useTranslation();
  const { user, signOut } = useAuth();
  const { isAdmin } = useProjects();
  const navigate = useNavigate();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleSignOut = async () => {
    try {
      await signOut();
      navigate('/login');
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
  };

  const navItems = [
    { to: '/', icon: <FiHome className="mr-3 text-lg" />, label: t('common.dashboard') },
    { to: '/projects', icon: <FiFolder className="mr-3 text-lg" />, label: t('common.projects') },
    { to: '/members', icon: <FiUsers className="mr-3 text-lg" />, label: t('common.members') },
    { to: '/expenses', icon: <FiDollarSign className="mr-3 text-lg" />, label: t('common.expenses') },
    { to: '/profile', icon: <FiUser className="mr-3 text-lg" />, label: t('common.profile') },
  ];

  // Add admin panel link if user is admin
  const adminItems = isAdmin ? [
    { to: '/admin', icon: <FiSettings className="mr-3 text-lg" />, label: 'Admin Panel' }
  ] : [];

  return (
    <div className="flex h-screen bg-neutral-50">
      {/* Top Language Selector Bar */}
      <div className="fixed top-0 right-0 left-0 z-50 bg-white border-b border-neutral-200 h-12 flex justify-end items-center px-4 md:px-8">
        <LanguageSelector />
      </div>

      {/* Sidebar for desktop */}
      <aside className="hidden md:flex md:flex-col md:w-64 md:fixed md:inset-y-0 bg-white border-r border-neutral-200 shadow-soft">
        <div className="flex flex-col flex-grow pt-5 pb-4 overflow-y-auto mt-12"> {/* Added mt-12 for top bar space */}
          <div className="flex items-center flex-shrink-0 px-4">
            <h1 className="text-xl font-bold text-primary-600">FINNIF05</h1>
          </div>
          <div className="px-4 mt-1 text-xs text-neutral-500">
            by Gilles Sunang
          </div>
          <nav className="mt-8 flex-1 px-2 space-y-1">
            {navItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  `flex items-center px-4 py-3 text-sm font-medium rounded-lg ${
                    isActive
                      ? 'bg-primary-50 text-primary-600'
                      : 'text-neutral-600 hover:bg-neutral-50 hover:text-neutral-900'
                  }`
                }
              >
                {item.icon}
                {item.label}
              </NavLink>
            ))}
            
            {/* Admin panel link */}
            {adminItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  `flex items-center px-4 py-3 text-sm font-medium rounded-lg ${
                    isActive
                      ? 'bg-accent-50 text-accent-600'
                      : 'text-neutral-600 hover:bg-accent-50 hover:text-accent-600'
                  }`
                }
              >
                {item.icon}
                {item.label}
              </NavLink>
            ))}
          </nav>
          <div className="p-4 mt-auto">
            <button
              onClick={handleSignOut}
              className="flex items-center w-full px-4 py-2 text-sm font-medium text-red-600 rounded-lg hover:bg-red-50"
            >
              <FiLogOut className="mr-3 text-lg" />
              {t('common.signOut')}
            </button>
          </div>
        </div>
      </aside>

      {/* Mobile header */}
      <div className="md:hidden bg-white border-b border-neutral-200 fixed top-12 left-0 right-0 z-10 shadow-soft"> {/* Updated top-12 for top bar space */}
        <div className="flex items-center justify-between h-16 px-4">
          <div>
            <h1 className="text-xl font-bold text-primary-600">FINNIF05</h1>
            <div className="text-xs text-neutral-500">by Gilles Sunang</div>
          </div>
          <button
            onClick={toggleMobileMenu}
            className="ml-2 p-2 text-neutral-600 rounded-lg hover:bg-neutral-100 focus:outline-none"
          >
            {isMobileMenuOpen ? (
              <FiX className="text-2xl" />
            ) : (
              <FiMenu className="text-2xl" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden fixed inset-0 z-20 bg-neutral-800 bg-opacity-50">
          <div className="fixed inset-y-0 left-0 w-64 bg-white shadow-xl">
            <div className="flex flex-col h-full">
              <div className="flex items-center justify-between h-16 px-4 border-b border-neutral-200">
                <div>
                  <h1 className="text-xl font-bold text-primary-600">FINNIF05</h1>
                  <div className="text-xs text-neutral-500">by Gilles Sunang</div>
                </div>
                <button
                  onClick={closeMobileMenu}
                  className="p-2 text-neutral-600 rounded-lg hover:bg-neutral-100 focus:outline-none"
                >
                  <FiX className="text-2xl" />
                </button>
              </div>
              <nav className="flex-1 px-2 pt-4 pb-4 overflow-y-auto">
                {navItems.map((item) => (
                  <NavLink
                    key={item.to}
                    to={item.to}
                    onClick={closeMobileMenu}
                    className={({ isActive }) =>
                      `flex items-center px-4 py-3 text-sm font-medium rounded-lg ${
                        isActive
                          ? 'bg-primary-50 text-primary-600'
                          : 'text-neutral-600 hover:bg-neutral-50 hover:text-neutral-900'
                      }`
                    }
                  >
                    {item.icon}
                    {item.label}
                  </NavLink>
                ))}
                
                {/* Admin panel link */}
                {adminItems.map((item) => (
                  <NavLink
                    key={item.to}
                    to={item.to}
                    onClick={closeMobileMenu}
                    className={({ isActive }) =>
                      `flex items-center px-4 py-3 text-sm font-medium rounded-lg ${
                        isActive
                          ? 'bg-accent-50 text-accent-600'
                          : 'text-neutral-600 hover:bg-accent-50 hover:text-accent-600'
                      }`
                    }
                  >
                    {item.icon}
                    {item.label}
                  </NavLink>
                ))}
              </nav>
              <div className="p-4 border-t border-neutral-200">
                <button
                  onClick={handleSignOut}
                  className="flex items-center w-full px-4 py-2 text-sm font-medium text-red-600 rounded-lg hover:bg-red-50"
                >
                  <FiLogOut className="mr-3 text-lg" />
                  {t('common.signOut')}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Main content */}
      <div className="flex flex-col flex-1 md:pl-64">
        <main className="flex-1 pt-28 md:pt-12"> {/* Updated padding-top for top bar space */}
          <div className="py-6 mx-auto max-w-7xl px-4 sm:px-6 md:px-8">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
}

export default MainLayout;