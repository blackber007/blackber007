import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { FiUser, FiUserCheck, FiUserX, FiRefreshCw, FiUpload, FiDatabase, FiList, FiClock } from 'react-icons/fi';
import ExcelDataUploader from '../components/ExcelDataUploader';
import { format } from 'date-fns';

function AdminPanel() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [users, setUsers] = useState([]);
  const [importedData, setImportedData] = useState([]);
  const [systemLogs, setSystemLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [activeTab, setActiveTab] = useState('users');

  // Check if current user is admin
  useEffect(() => {
    const checkAdminStatus = async () => {
      if (!user) {
        navigate('/login');
        return;
      }

      try {
        const { data, error } = await supabase
          .from('profiles')
          .select('is_admin')
          .eq('id', user.id)
          .maybeSingle();

        if (error) throw error;
        
        const isUserAdmin = data?.is_admin || false;
        setIsAdmin(isUserAdmin);
        
        if (!isUserAdmin) {
          navigate('/');
        }
      } catch (err) {
        console.error('Error checking admin status:', err);
        setError(err.message);
        navigate('/');
      }
    };

    checkAdminStatus();
  }, [user, navigate]);

  // Fetch all users
  useEffect(() => {
    const fetchUsers = async () => {
      if (!isAdmin) return;
      
      try {
        setLoading(true);
        
        const { data, error } = await supabase
          .from('profiles')
          .select('*')
          .order('created_at', { ascending: false });
          
        if (error) throw error;
        
        setUsers(data || []);
      } catch (err) {
        console.error('Error fetching users:', err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    if (isAdmin) {
      fetchUsers();
    }
  }, [isAdmin]);

  // Fetch imported data
  useEffect(() => {
    const fetchImportedData = async () => {
      if (!isAdmin) return;
      
      try {
        console.log("Fetching imported data...");
        const { data, error } = await supabase
          .from('imported_excel_data')
          .select('*')
          .order('imported_at', { ascending: false });
          
        if (error) {
          console.error("Error fetching imported data:", error);
          throw error;
        }
        
        console.log("Fetched imported data:", data?.length || 0, "records");
        setImportedData(data || []);
      } catch (err) {
        console.error('Error fetching imported data:', err);
      }
    };

    if (isAdmin && activeTab === 'importedData') {
      fetchImportedData();
    }
  }, [isAdmin, activeTab]);

  // Fetch system logs
  useEffect(() => {
    const fetchSystemLogs = async () => {
      if (!isAdmin) return;
      
      try {
        const { data, error } = await supabase
          .from('system_logs')
          .select('*')
          .order('timestamp', { ascending: false })
          .limit(100);
          
        if (error) throw error;
        
        setSystemLogs(data || []);
      } catch (err) {
        console.error('Error fetching system logs:', err);
      }
    };

    if (isAdmin && activeTab === 'systemLogs') {
      fetchSystemLogs();
    }
  }, [isAdmin, activeTab]);

  const toggleAdminStatus = async (userId, currentStatus) => {
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ is_admin: !currentStatus })
        .eq('id', userId);
        
      if (error) throw error;
      
      // Update local state
      setUsers(users.map(user => 
        user.id === userId ? { ...user, is_admin: !currentStatus } : user
      ));
      
      // Log the admin status change
      await supabase
        .from('system_logs')
        .insert([{
          event_type: !currentStatus ? 'ADMIN_ROLE_GRANTED' : 'ADMIN_ROLE_REVOKED',
          user_id: userId,
          user_email: users.find(u => u.id === userId)?.email,
          details: {
            changed_by: user.id,
            changed_by_email: user.email
          }
        }]);
    } catch (err) {
      console.error('Error updating admin status:', err);
      setError(err.message);
    }
  };

  const refreshUserProfiles = async () => {
    try {
      setRefreshing(true);
      
      // Call RPC function to sync auth users with profiles
      const { error } = await supabase.rpc('sync_user_profiles');
      
      if (error) throw error;
      
      // Refresh the user list
      const { data, error: fetchError } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false });
        
      if (fetchError) throw fetchError;
      
      setUsers(data || []);
      
      // Log the refresh action
      await supabase
        .from('system_logs')
        .insert([{
          event_type: 'PROFILES_REFRESHED',
          user_id: user.id,
          user_email: user.email
        }]);
    } catch (err) {
      console.error('Error refreshing user profiles:', err);
      setError(err.message);
    } finally {
      setRefreshing(false);
    }
  };

  const handleImportComplete = async (importedData) => {
    // Refresh the imported data list
    console.log("Import completed with", importedData.length, "records");
    try {
      const { data, error } = await supabase
        .from('imported_excel_data')
        .select('*')
        .order('imported_at', { ascending: false });
        
      if (error) throw error;
      
      setImportedData(data || []);
      
      // Log the import action
      await supabase
        .from('system_logs')
        .insert([{
          event_type: 'DATA_IMPORT',
          user_id: user.id,
          user_email: user.email,
          details: {
            records_count: importedData.length
          }
        }]);
    } catch (err) {
      console.error('Error refreshing imported data:', err);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  if (!isAdmin) {
    return null;
  }

  return (
    <div>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Admin Panel</h1>
        <div className="flex space-x-2 mt-3 md:mt-0">
          <button 
            onClick={refreshUserProfiles}
            disabled={refreshing}
            className="btn btn-secondary flex items-center"
          >
            <FiRefreshCw className={`mr-2 ${refreshing ? 'animate-spin' : ''}`} />
            {refreshing ? 'Refreshing...' : 'Refresh User Profiles'}
          </button>
        </div>
      </div>

      {error && (
        <div className="bg-red-50 p-4 rounded-md text-red-700 mb-6">
          <p>{error}</p>
        </div>
      )}

      {/* Tabs */}
      <div className="border-b border-gray-200 mb-6">
        <nav className="-mb-px flex space-x-8">
          <button
            onClick={() => setActiveTab('users')}
            className={`${
              activeTab === 'users'
                ? 'border-primary-500 text-primary-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
          >
            <FiUser className="inline-block mr-2" />
            Users
          </button>
          <button
            onClick={() => setActiveTab('importData')}
            className={`${
              activeTab === 'importData'
                ? 'border-primary-500 text-primary-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
          >
            <FiUpload className="inline-block mr-2" />
            Import Data
          </button>
          <button
            onClick={() => setActiveTab('importedData')}
            className={`${
              activeTab === 'importedData'
                ? 'border-primary-500 text-primary-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
          >
            <FiDatabase className="inline-block mr-2" />
            Imported Data
          </button>
          <button
            onClick={() => setActiveTab('systemLogs')}
            className={`${
              activeTab === 'systemLogs'
                ? 'border-primary-500 text-primary-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
          >
            <FiList className="inline-block mr-2" />
            System Logs
          </button>
        </nav>
      </div>

      {/* Users Tab */}
      {activeTab === 'users' && (
        <div className="bg-white shadow overflow-hidden sm:rounded-md">
          <div className="px-4 py-5 sm:px-6 bg-gray-50">
            <h2 className="text-lg font-medium text-gray-900">User Management</h2>
            <p className="mt-1 text-sm text-gray-500">
              Manage user accounts and admin privileges
            </p>
          </div>
          
          <ul className="divide-y divide-gray-200">
            {users.map((profile) => (
              <li key={profile.id}>
                <div className="px-4 py-4 sm:px-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center">
                        {profile.avatar_url ? (
                          <img src={profile.avatar_url} alt="" className="h-10 w-10 rounded-full" />
                        ) : (
                          <FiUser className="text-gray-600 text-xl" />
                        )}
                      </div>
                      <div className="ml-4">
                        <div className="text-sm font-medium text-gray-900">
                          {profile.first_name} {profile.last_name || profile.full_name}
                          {profile.id === user.id && (
                            <span className="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                              You
                            </span>
                          )}
                          {profile.is_admin && (
                            <span className="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                              Admin
                            </span>
                          )}
                        </div>
                        <div className="text-sm text-gray-500">
                          {profile.email}
                        </div>
                      </div>
                    </div>
                    <div>
                      <button
                        onClick={() => toggleAdminStatus(profile.id, profile.is_admin)}
                        className={`inline-flex items-center px-3 py-1 border border-transparent text-sm leading-4 font-medium rounded-md ${
                          profile.is_admin
                            ? 'text-red-700 bg-red-100 hover:bg-red-200'
                            : 'text-green-700 bg-green-100 hover:bg-green-200'
                        } focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500`}
                      >
                        {profile.is_admin ? (
                          <>
                            <FiUserX className="mr-1.5 -ml-0.5 h-4 w-4" />
                            Remove Admin
                          </>
                        ) : (
                          <>
                            <FiUserCheck className="mr-1.5 -ml-0.5 h-4 w-4" />
                            Make Admin
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                  <div className="mt-2 sm:flex sm:justify-between">
                    <div className="sm:flex">
                      <p className="flex items-center text-sm text-gray-500">
                        Location: {profile.location || 'Not specified'}
                      </p>
                      {profile.birthday && (
                        <p className="mt-2 flex items-center text-sm text-gray-500 sm:mt-0 sm:ml-6">
                          Birthday: {new Date(profile.birthday).toLocaleDateString()}
                        </p>
                      )}
                    </div>
                    <div className="mt-2 flex items-center text-sm text-gray-500 sm:mt-0">
                      <p>
                        Registered: {profile.registration_time 
                          ? new Date(profile.registration_time).toLocaleString() 
                          : new Date(profile.created_at).toLocaleString()}
                      </p>
                    </div>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Import Data Tab */}
      {activeTab === 'importData' && (
        <ExcelDataUploader onImportComplete={handleImportComplete} />
      )}

      {/* Imported Data Tab */}
      {activeTab === 'importedData' && (
        <div className="bg-white shadow overflow-hidden sm:rounded-md">
          <div className="px-4 py-5 sm:px-6 bg-gray-50">
            <h2 className="text-lg font-medium text-gray-900">Imported Data</h2>
            <p className="mt-1 text-sm text-gray-500">
              View and manage data imported from Excel
            </p>
          </div>
          
          {importedData.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Email
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Full Name
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Company
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Position
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Imported At
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {importedData.map((item) => (
                    <tr key={item.id}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.email}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.full_name || '-'}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.company || '-'}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.position || '-'}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {new Date(item.imported_at).toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="px-4 py-5 sm:p-6 text-center">
              <p className="text-gray-500">No imported data yet. Go to the Import Data tab to upload Excel data.</p>
            </div>
          )}
        </div>
      )}

      {/* System Logs Tab */}
      {activeTab === 'systemLogs' && (
        <div className="bg-white shadow overflow-hidden sm:rounded-md">
          <div className="px-4 py-5 sm:px-6 bg-gray-50">
            <h2 className="text-lg font-medium text-gray-900">System Logs</h2>
            <p className="mt-1 text-sm text-gray-500">
              View system activity and audit logs
            </p>
          </div>
          
          {systemLogs.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Timestamp
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Event Type
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      User
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      IP Address
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Details
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {systemLogs.map((log) => (
                    <tr key={log.id}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {format(new Date(log.timestamp), 'yyyy-MM-dd HH:mm:ss')}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          log.event_type.includes('ERROR') || log.event_type.includes('FAIL')
                            ? 'bg-red-100 text-red-800'
                            : log.event_type.includes('SUCCESS') || log.event_type.includes('GRANTED')
                              ? 'bg-green-100 text-green-800'
                              : 'bg-blue-100 text-blue-800'
                        }`}>
                          {log.event_type}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {log.user_email || '-'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {log.ip_address || '-'}
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-500 max-w-xs truncate">
                        {log.details ? JSON.stringify(log.details) : '-'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="px-4 py-5 sm:p-6 text-center">
              <p className="text-gray-500">No system logs available yet.</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default AdminPanel;