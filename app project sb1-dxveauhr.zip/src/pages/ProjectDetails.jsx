import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useProjects } from '../contexts/ProjectsContext';
import { useAuth } from '../contexts/AuthContext';
import { useForm } from 'react-hook-form';
import { FiUsers, FiDollarSign, FiTag, FiPlus, FiEdit2, FiTrash2, FiArrowLeft, FiLogOut } from 'react-icons/fi';
import { format } from 'date-fns';
import currencyCodes from 'currency-codes';
import { Pie } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend
} from 'chart.js';

// Register ChartJS components
ChartJS.register(
  ArcElement,
  Tooltip,
  Legend
);

function ProjectDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, signOut } = useAuth();
  const { 
    projects, 
    getProjectMembers, 
    addProjectMember,
    getExpenseCategories,
    addExpenseCategory,
    getProjectTransactions,
    addTransaction
  } = useProjects();
  
  const [project, setProject] = useState(null);
  const [members, setMembers] = useState([]);
  const [categories, setCategories] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  
  // Modal states
  const [isAddMemberModalOpen, setIsAddMemberModalOpen] = useState(false);
  const [isAddCategoryModalOpen, setIsAddCategoryModalOpen] = useState(false);
  const [isAddTransactionModalOpen, setIsAddTransactionModalOpen] = useState(false);
  const [transactionType, setTransactionType] = useState('expense');
  
  // Financial summary
  const [financialSummary, setFinancialSummary] = useState({
    income: 0,
    expense: 0,
    balance: 0,
    currency: ''
  });
  
  // Chart data
  const [chartData, setChartData] = useState(null);
  
  // Form handling
  const { 
    register: registerMember, 
    handleSubmit: handleSubmitMember, 
    reset: resetMember,
    formState: { errors: memberErrors }
  } = useForm();
  
  const { 
    register: registerCategory, 
    handleSubmit: handleSubmitCategory, 
    reset: resetCategory,
    formState: { errors: categoryErrors }
  } = useForm();
  
  const { 
    register: registerTransaction, 
    handleSubmit: handleSubmitTransaction, 
    reset: resetTransaction,
    formState: { errors: transactionErrors }
  } = useForm({
    defaultValues: {
      date: new Date().toISOString().split('T')[0]
    }
  });
  
  // Get currency options
  const currencies = currencyCodes.data.map(currency => ({
    value: currency.code,
    label: `${currency.code} - ${currency.currency}`
  }));

  // Load project data
  useEffect(() => {
    const loadProjectData = async () => {
      try {
        setLoading(true);
        
        // Find project in context
        const foundProject = projects.find(p => p.id === id);
        if (!foundProject) {
          navigate('/projects');
          return;
        }
        
        setProject(foundProject);
        setIsAdmin(foundProject.role === 'admin');
        
        // Load members
        const membersData = await getProjectMembers(id);
        setMembers(membersData);
        
        // Load categories
        const categoriesData = await getExpenseCategories(id);
        setCategories(categoriesData);
        
        // Load transactions
        const transactionsData = await getProjectTransactions(id);
        setTransactions(transactionsData);
        
        // Calculate financial summary
        const baseCurrency = foundProject.base_currency;
        
        const baseCurrencyTransactions = transactionsData.filter(
          t => t.currency === baseCurrency
        );
        
        const income = baseCurrencyTransactions
          .filter(t => t.type === 'income')
          .reduce((sum, t) => sum + t.amount, 0);
          
        const expense = baseCurrencyTransactions
          .filter(t => t.type === 'expense')
          .reduce((sum, t) => sum + t.amount, 0);
          
        setFinancialSummary({
          income,
          expense,
          balance: income - expense,
          currency: baseCurrency
        });
        
        // Prepare chart data
        if (transactionsData.length > 0) {
          // Group expenses by category
          const expensesByCategory = {};
          
          baseCurrencyTransactions
            .filter(t => t.type === 'expense' && t.expense_categories)
            .forEach(transaction => {
              const categoryName = transaction.expense_categories.name;
              if (!expensesByCategory[categoryName]) {
                expensesByCategory[categoryName] = 0;
              }
              expensesByCategory[categoryName] += transaction.amount;
            });
          
          // Prepare chart data
          const labels = Object.keys(expensesByCategory);
          const data = Object.values(expensesByCategory);
          
          // Generate colors
          const backgroundColors = [
            'rgba(255, 99, 132, 0.6)',
            'rgba(54, 162, 235, 0.6)',
            'rgba(255, 206, 86, 0.6)',
            'rgba(75, 192, 192, 0.6)',
            'rgba(153, 102, 255, 0.6)',
            'rgba(255, 159, 64, 0.6)',
            'rgba(199, 199, 199, 0.6)',
          ];
          
          setChartData({
            labels,
            datasets: [
              {
                data,
                backgroundColor: backgroundColors.slice(0, labels.length),
                borderWidth: 1,
              },
            ],
          });
        }
      } catch (err) {
        console.error('Error loading project data:', err);
      } finally {
        setLoading(false);
      }
    };
    
    if (id && projects.length > 0) {
      loadProjectData();
    }
  }, [id, projects, navigate, getProjectMembers, getExpenseCategories, getProjectTransactions]);

  // Add member handler
  const onAddMember = async (data) => {
    try {
      await addProjectMember(id, data.email, data.role);
      setIsAddMemberModalOpen(false);
      resetMember();
      
      // Refresh members list
      const membersData = await getProjectMembers(id);
      setMembers(membersData);
    } catch (err) {
      console.error('Error adding member:', err);
      // Handle error (show message, etc.)
    }
  };

  // Add category handler
  const onAddCategory = async (data) => {
    try {
      await addExpenseCategory(id, data);
      setIsAddCategoryModalOpen(false);
      resetCategory();
      
      // Refresh categories list
      const categoriesData = await getExpenseCategories(id);
      setCategories(categoriesData);
    } catch (err) {
      console.error('Error adding category:', err);
      // Handle error (show message, etc.)
    }
  };

  // Add transaction handler
  const onAddTransaction = async (data) => {
    try {
      const transactionData = {
        project_id: id,
        user_id: user.id,
        category_id: data.category_id === '' ? null : data.category_id,
        type: transactionType,
        amount: parseFloat(data.amount),
        currency: data.currency,
        description: data.description,
        date: data.date
      };
      
      await addTransaction(transactionData);
      setIsAddTransactionModalOpen(false);
      resetTransaction();
      
      // Refresh transactions list and financial summary
      const transactionsData = await getProjectTransactions(id);
      setTransactions(transactionsData);
      
      // Recalculate financial summary
      const baseCurrency = project.base_currency;
      const baseCurrencyTransactions = transactionsData.filter(
        t => t.currency === baseCurrency
      );
      
      const income = baseCurrencyTransactions
        .filter(t => t.type === 'income')
        .reduce((sum, t) => sum + t.amount, 0);
        
      const expense = baseCurrencyTransactions
        .filter(t => t.type === 'expense')
        .reduce((sum, t) => sum + t.amount, 0);
        
      setFinancialSummary({
        income,
        expense,
        balance: income - expense,
        currency: baseCurrency
      });
    } catch (err) {
      console.error('Error adding transaction:', err);
      // Handle error (show message, etc.)
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut();
      navigate('/login');
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="bg-red-50 p-4 rounded-md text-red-700">
        <p>Project not found.</p>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-6">
        <Link to="/projects" className="flex items-center text-primary-600 hover:text-primary-700">
          <FiArrowLeft className="mr-2" />
          Back to Projects
        </Link>
      </div>
      
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">{project.name}</h1>
        <div className="mt-4 md:mt-0 flex space-x-2">
          {isAdmin && (
            <button
              onClick={() => {
                setTransactionType('income');
                setIsAddTransactionModalOpen(true);
              }}
              className="btn btn-secondary flex items-center"
            >
              <FiPlus className="mr-2" />
              Add Income
            </button>
          )}
          
          {isAdmin && (
            <button
              onClick={() => {
                setTransactionType('expense');
                setIsAddTransactionModalOpen(true);
              }}
              className="btn btn-primary flex items-center"
            >
              <FiPlus className="mr-2" />
              Add Expense
            </button>
          )}
          
          <button
            onClick={handleSignOut}
            className="btn btn-danger flex items-center"
          >
            <FiLogOut className="mr-2" />
            Sign Out
          </button>
        </div>
      </div>
      
      {project.description && (
        <div className="bg-white rounded-lg shadow-md p-4 mb-6">
          <p className="text-gray-700">{project.description}</p>
        </div>
      )}
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <div className="card bg-white shadow-sm">
          <h2 className="text-lg font-semibold mb-4">Financial Summary</h2>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-gray-600">Income:</span>
              <span className="text-green-600 font-medium">
                {financialSummary.currency} {financialSummary.income.toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Expenses:</span>
              <span className="text-red-600 font-medium">
                {financialSummary.currency} {financialSummary.expense.toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between pt-2 border-t">
              <span className="font-medium">Balance:</span>
              <span className={`font-bold ${financialSummary.balance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {financialSummary.currency} {financialSummary.balance.toFixed(2)}
              </span>
            </div>
          </div>
        </div>
        
        <div className="card bg-white shadow-sm">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold">Categories</h2>
            {isAdmin && (
              <button
                onClick={() => setIsAddCategoryModalOpen(true)}
                className="text-sm text-primary-600 hover:text-primary-700 flex items-center"
              >
                <FiPlus className="mr-1" />
                Add
              </button>
            )}
          </div>
          
          {categories.length > 0 ? (
            <ul className="space-y-2">
              {categories.map(category => (
                <li key={category.id} className="flex items-center">
                  <div className="w-3 h-3 rounded-full bg-primary-500 mr-2"></div>
                  <span>{category.name}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-gray-500">No categories yet</p>
          )}
        </div>
        
        <div className="card bg-white shadow-sm">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold">Team Members</h2>
            {isAdmin && (
              <button
                onClick={() => setIsAddMemberModalOpen(true)}
                className="text-sm text-primary-600 hover:text-primary-700 flex items-center"
              >
                <FiPlus className="mr-1" />
                Add
              </button>
            )}
          </div>
          
          {members.length > 0 ? (
            <ul className="space-y-2">
              {members.map(member => (
                <li key={member.id} className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center mr-2">
                      {member.avatar_url ? (
                        <img src={member.avatar_url} alt="" className="w-8 h-8 rounded-full" />
                      ) : (
                        <span className="text-gray-600">{member.full_name.charAt(0).toUpperCase()}</span>
                      )}
                    </div>
                    <span>{member.full_name}</span>
                  </div>
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    member.role === 'admin' 
                      ? 'bg-red-100 text-red-800' 
                      : 'bg-gray-100 text-gray-800'
                  }`}>
                    {member.role}
                  </span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-gray-500">No team members yet</p>
          )}
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div className="card bg-white shadow-sm">
          <h2 className="text-lg font-semibold mb-4">Expense Breakdown</h2>
          {chartData ? (
            <div className="h-64">
              <Pie 
                data={chartData} 
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: {
                      position: 'right',
                    }
                  }
                }}
              />
            </div>
          ) : (
            <p className="text-gray-500">No expense data available</p>
          )}
        </div>
        
        <div className="card bg-white shadow-sm">
          <h2 className="text-lg font-semibold mb-4">Project Details</h2>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-gray-600">Base Currency:</span>
              <span className="font-medium">{project.base_currency}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Created:</span>
              <span className="font-medium">{format(new Date(project.created_at), 'MMM d, yyyy')}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Status:</span>
              <span className={`font-medium ${
                project.status === 'active' 
                  ? 'text-green-600' 
                  : project.status === 'completed'
                    ? 'text-blue-600'
                    : 'text-gray-600'
              }`}>
                {project.status.charAt(0).toUpperCase() + project.status.slice(1)}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Your Role:</span>
              <span className="font-medium">{project.role}</span>
            </div>
          </div>
        </div>
      </div>
      
      <div className="card bg-white shadow-sm">
        <h2 className="text-lg font-semibold mb-4">Recent Transactions</h2>
        
        {transactions.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Date
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Description
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Category
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Amount
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {transactions.map((transaction) => (
                  <tr key={transaction.id} className={transaction.type === 'income' ? 'bg-green-50' : ''}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {format(new Date(transaction.date), 'MMM d, yyyy')}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {transaction.description}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {transaction.expense_categories?.name || '-'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <span className={transaction.type === 'income' ? 'text-green-600' : 'text-red-600'}>
                        {transaction.type === 'income' ? '+' : '-'} {transaction.currency} {transaction.amount.toFixed(2)}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-gray-500">No transactions yet</p>
        )}
      </div>
      
      {/* Add Member Modal */}
      {isAddMemberModalOpen && (
        <div className="fixed inset-0 z-10 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 transition-opacity" aria-hidden="true">
              <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
            </div>

            <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>

            <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
              <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                <div className="sm:flex sm:items-start">
                  <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left w-full">
                    <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
                      Add Team Member
                    </h3>
                    
                    <form onSubmit={handleSubmitMember(onAddMember)}>
                      <div className="mb-4">
                        <label htmlFor="email" className="label">
                          Email Address
                        </label>
                        <input
                          type="email"
                          id="email"
                          className={`input ${memberErrors.email ? 'border-red-500' : ''}`}
                          {...registerMember('email', { 
                            required: 'Email is required',
                            pattern: {
                              value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                              message: 'Invalid email address'
                            }
                          })}
                        />
                        {memberErrors.email && (
                          <p className="mt-1 text-sm text-red-600">{memberErrors.email.message}</p>
                        )}
                      </div>

                      <div className="mb-4">
                        <label htmlFor="role" className="label">
                          Role
                        </label>
                        <select
                          id="role"
                          className={`input ${memberErrors.role ? 'border-red-500' : ''}`}
                          {...registerMember('role', { required: 'Role is required' })}
                        >
                          <option value="member">Member</option>
                          {isAdmin && <option value="admin">Admin</option>}
                        </select>
                        {memberErrors.role && (
                          <p className="mt-1 text-sm text-red-600">{memberErrors.role.message}</p>
                        )}
                      </div>
                    </form>
                  </div>
                </div>
              </div>
              <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                <button
                  type="button"
                  className="btn btn-primary sm:ml-3"
                  onClick={handleSubmitMember(onAddMember)}
                >
                  Add Member
                </button>
                <button
                  type="button"
                  className="btn btn-secondary mt-3 sm:mt-0"
                  onClick={() => {
                    setIsAddMemberModalOpen(false);
                    resetMember();
                  }}
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Add Category Modal */}
      {isAddCategoryModalOpen && (
        <div className="fixed inset-0 z-10 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 transition-opacity" aria-hidden="true">
              <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
            </div>

            <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>

            <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
              <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                <div className="sm:flex sm:items-start">
                  <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left w-full">
                    <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
                      Add Expense Category
                    </h3>
                    
                    <form onSubmit={handleSubmitCategory(onAddCategory)}>
                      <div className="mb-4">
                        <label htmlFor="name" className="label">
                          Category Name
                        </label>
                        <input
                          type="text"
                          id="name"
                          className={`input ${categoryErrors.name ? 'border-red-500' : ''}`}
                          {...registerCategory('name', { required: 'Category name is required' })}
                        />
                        {categoryErrors.name && (
                          <p className="mt-1 text-sm text-red-600">{categoryErrors.name.message}</p>
                        )}
                      </div>

                      <div className="mb-4">
                        <label htmlFor="description" className="label">
                          Description (Optional)
                        </label>
                        <textarea
                          id="description"
                          rows="3"
                          className="input"
                          {...registerCategory('description')}
                        ></textarea>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
              <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                <button
                  type="button"
                  className="btn btn-primary sm:ml-3"
                  onClick={handleSubmitCategory(onAddCategory)}
                >
                  Add Category
                </button>
                <button
                  type="button"
                  className="btn btn-secondary mt-3 sm:mt-0"
                  onClick={() => {
                    setIsAddCategoryModalOpen(false);
                    resetCategory();
                  }}
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Add Transaction Modal */}
      {isAddTransactionModalOpen && (
        <div className="fixed inset-0 z-10 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 transition-opacity" aria-hidden="true">
              <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
            </div>

            <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>

            <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
              <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                <div className="sm:flex sm:items-start">
                  <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left w-full">
                    <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
                      {transactionType === 'income' ? 'Add Income' : 'Add Expense'}
                    </h3>
                    
                    <form onSubmit={handleSubmitTransaction(onAddTransaction)}>
                      <div className="mb-4">
                        <label htmlFor="description" className="label">
                          Description
                        </label>
                        <input
                          type="text"
                          id="description"
                          className={`input ${transactionErrors.description ? 'border-red-500' : ''}`}
                          {...registerTransaction('description', { required: 'Description is required' })}
                        />
                        {transactionErrors.description && (
                          <p className="mt-1 text-sm text-red-600">{transactionErrors.description.message}</p>
                        )}
                      </div>

                      <div className="mb-4">
                        <label htmlFor="amount" className="label">
                          Amount
                        </label>
                        <input
                          type="number"
                          id="amount"
                          step="0.01"
                          min="0"
                          className={`input ${transactionErrors.amount ? 'border-red-500' : ''}`}
                          {...registerTransaction('amount', { 
                            required: 'Amount is required',
                            min: {
                              value: 0,
                              message: 'Amount must be positive'
                            }
                          })}
                        />
                        {transactionErrors.amount && (
                          <p className="mt-1 text-sm text-red-600">{transactionErrors.amount.message}</p>
                        )}
                      </div>

                      <div className="mb-4">
                        <label htmlFor="currency" className="label">
                          Currency
                        </label>
                        <select
                          id="currency"
                          className={`input ${transactionErrors.currency ? 'border-red-500' : ''}`}
                          {...registerTransaction('currency', { required: 'Currency is required' })}
                          defaultValue={project.base_currency}
                        >
                          {currencies.map(currency => (
                            <option key={currency.value} value={currency.value}>
                              {currency.label}
                            </option>
                          ))}
                        </select>
                        {transactionErrors.currency && (
                          <p className="mt-1 text-sm text-red-600">{transactionErrors.currency.message}</p>
                        )}
                      </div>

                      <div className="mb-4">
                        <label htmlFor="date" className="label">
                          Date
                        </label>
                        <input
                          type="date"
                          id="date"
                          className={`input ${transactionErrors.date ? 'border-red-500' : ''}`}
                          {...registerTransaction('date', { required: 'Date is required' })}
                        />
                        {transactionErrors.date && (
                          <p className="mt-1 text-sm text-red-600">{transactionErrors.date.message}</p>
                        )}
                      </div>

                      {transactionType === 'expense' && (
                        <div className="mb-4">
                          <label htmlFor="category_id" className="label">
                            Category
                          </label>
                          <select
                            id="category_id"
                            className="input"
                            {...registerTransaction('category_id')}
                          >
                            <option value="">-- Select Category --</option>
                            {categories.map(category => (
                              <option key={category.id} value={category.id}>
                                {category.name}
                              </option>
                            ))}
                          </select>
                        </div>
                      )}
                    </form>
                  </div>
                </div>
              </div>
              <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                <button
                  type="button"
                  className={`btn ${transactionType === 'income' ? 'btn-secondary' : 'btn-primary'} sm:ml-3`}
                  onClick={handleSubmitTransaction(onAddTransaction)}
                >
                  {transactionType === 'income' ? 'Add Income' : 'Add Expense'}
                </button>
                <button
                  type="button"
                  className="btn btn-secondary mt-3 sm:mt-0"
                  onClick={() => {
                    setIsAddTransactionModalOpen(false);
                    resetTransaction();
                  }}
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default ProjectDetails;