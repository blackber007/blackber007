import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { supabase } from '../lib/supabase';
import DataComparisonModal from '../components/DataComparisonModal';

function Register() {
  const { t } = useTranslation();
  const { signUp } = useAuth();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [existingData, setExistingData] = useState(null);
  const [showComparisonModal, setShowComparisonModal] = useState(false);
  const [userData, setUserData] = useState(null);
  const [location, setLocation] = useState(null);
  
  const { register, handleSubmit, formState: { errors }, watch, setValue } = useForm();
  const password = watch('password');
  const email = watch('email');

  // Get user's location when component mounts
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude
          });
        },
        (error) => {
          console.error("Error getting location:", error);
        }
      );
    }
  }, []);

  // Check for existing data when email changes
  useEffect(() => {
    const checkExistingData = async () => {
      if (!email || email.length < 5 || !email.includes('@')) return;
      
      try {
        // Check if the email exists in the imported data
        const { data, error } = await supabase
          .from('imported_excel_data')
          .select('*')
          .eq('email', email.toLowerCase())
          .maybeSingle();
          
        if (error) throw error;
        
        if (data) {
          setExistingData(data);
          
          // Pre-fill the name field if available
          if (data.full_name && !watch('fullName')) {
            setValue('fullName', data.full_name);
          }
        } else {
          setExistingData(null);
        }
      } catch (err) {
        console.error('Error checking existing data:', err);
      }
    };
    
    const debounceTimer = setTimeout(() => {
      checkExistingData();
    }, 500);
    
    return () => clearTimeout(debounceTimer);
  }, [email, setValue, watch]);

  const onSubmit = async (data) => {
    try {
      setIsLoading(true);
      setError(null);
      
      // Prepare user data
      const newUserData = {
        email: data.email,
        first_name: data.firstName,
        last_name: data.lastName,
        full_name: `${data.firstName} ${data.lastName}`,
        birthday: data.birthday,
        location: data.location,
        registration_time: new Date().toISOString(),
        registration_location: location ? `${location.latitude},${location.longitude}` : null
      };
      
      // If we have existing data from Excel, show comparison modal
      if (existingData) {
        setUserData(newUserData);
        setShowComparisonModal(true);
        setIsLoading(false);
        return;
      }
      
      // Otherwise proceed with normal registration
      await completeRegistration(newUserData, data.password);
    } catch (err) {
      setError(err.message || t('auth.registrationFailed'));
      setIsLoading(false);
    }
  };
  
  const completeRegistration = async (userData, password) => {
    try {
      setIsLoading(true);
      
      // Log the registration attempt
      await logSystemEvent({
        event_type: 'REGISTRATION_ATTEMPT',
        user_email: userData.email,
        details: {
          registration_time: userData.registration_time,
          registration_location: userData.registration_location
        }
      });
      
      // Register the user
      const result = await signUp(userData.email, password, userData.full_name);
      
      // Update the user's profile with additional information
      if (result && result.user) {
        const { error: profileError } = await supabase
          .from('profiles')
          .update({
            first_name: userData.first_name,
            last_name: userData.last_name,
            birthday: userData.birthday,
            location: userData.location,
            registration_time: userData.registration_time,
            registration_location: userData.registration_location,
            is_admin: true // Make all new users admin
          })
          .eq('id', result.user.id);
          
        if (profileError) {
          console.error('Error updating profile:', profileError);
        }
        
        // Log successful registration
        await logSystemEvent({
          event_type: 'REGISTRATION_SUCCESS',
          user_email: userData.email,
          user_id: result.user.id,
          details: {
            registration_time: userData.registration_time
          }
        });
      }
      
      Alert.alert('Success', 'Account created successfully', [
        { text: 'OK', onPress: () => navigate('/') }
      ]);
    } catch (err) {
      // Log failed registration
      await logSystemEvent({
        event_type: 'REGISTRATION_FAILURE',
        user_email: userData.email,
        details: {
          error: err.message
        }
      });
      
      setError(err.message || t('auth.registrationFailed'));
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleComparisonConfirm = async (mergedData) => {
    // Complete registration with the merged data
    await completeRegistration(mergedData, password);
  };
  
  // Function to log system events
  const logSystemEvent = async (eventData) => {
    try {
      const { error } = await supabase
        .from('system_logs')
        .insert([{
          ...eventData,
          timestamp: new Date().toISOString(),
          ip_address: '127.0.0.1', // In a real app, you'd get the actual IP
          user_agent: navigator.userAgent
        }]);
        
      if (error) {
        console.error('Error logging event:', error);
      }
    } catch (err) {
      console.error('Failed to log system event:', err);
    }
  };

  return (
    <div>
      <h2 className="text-2xl font-bold text-center text-neutral-800 mb-6">{t('auth.createAccount')}</h2>
      
      {error && (
        <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-lg text-sm">
          {error}
        </div>
      )}
      
      {existingData && !showComparisonModal && (
        <div className="mb-4 p-3 bg-yellow-50 text-yellow-700 rounded-lg text-sm">
          {t('auth.existingDataFound')}
        </div>
      )}
      
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="firstName" className="label">
              First Name
            </label>
            <input
              id="firstName"
              type="text"
              autoComplete="given-name"
              className={`input ${errors.firstName ? 'border-red-500' : ''}`}
              {...register('firstName', { 
                required: 'First name is required',
                minLength: {
                  value: 2,
                  message: 'First name must be at least 2 characters'
                }
              })}
            />
            {errors.firstName && (
              <p className="mt-1 text-sm text-red-600">{errors.firstName.message}</p>
            )}
          </div>
          
          <div>
            <label htmlFor="lastName" className="label">
              Last Name
            </label>
            <input
              id="lastName"
              type="text"
              autoComplete="family-name"
              className={`input ${errors.lastName ? 'border-red-500' : ''}`}
              {...register('lastName', { 
                required: 'Last name is required',
                minLength: {
                  value: 2,
                  message: 'Last name must be at least 2 characters'
                }
              })}
            />
            {errors.lastName && (
              <p className="mt-1 text-sm text-red-600">{errors.lastName.message}</p>
            )}
          </div>
        </div>

        <div>
          <label htmlFor="email" className="label">
            {t('auth.email')}
          </label>
          <input
            id="email"
            type="email"
            autoComplete="email"
            className={`input ${errors.email ? 'border-red-500' : ''}`}
            {...register('email', { 
              required: t('auth.emailRequired'),
              pattern: {
                value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                message: t('auth.invalidEmail')
              }
            })}
          />
          {errors.email && (
            <p className="mt-1 text-sm text-red-600">{errors.email.message}</p>
          )}
        </div>
        
        <div>
          <label htmlFor="birthday" className="label">
            Birthday
          </label>
          <input
            id="birthday"
            type="date"
            className={`input ${errors.birthday ? 'border-red-500' : ''}`}
            {...register('birthday', { 
              required: 'Birthday is required'
            })}
          />
          {errors.birthday && (
            <p className="mt-1 text-sm text-red-600">{errors.birthday.message}</p>
          )}
        </div>
        
        <div>
          <label htmlFor="location" className="label">
            Location
          </label>
          <input
            id="location"
            type="text"
            className={`input ${errors.location ? 'border-red-500' : ''}`}
            placeholder="City, Country"
            {...register('location', { 
              required: 'Location is required'
            })}
          />
          {errors.location && (
            <p className="mt-1 text-sm text-red-600">{errors.location.message}</p>
          )}
        </div>

        <div>
          <label htmlFor="password" className="label">
            {t('auth.password')}
          </label>
          <input
            id="password"
            type="password"
            autoComplete="new-password"
            className={`input ${errors.password ? 'border-red-500' : ''}`}
            {...register('password', { 
              required: t('auth.passwordRequired'),
              minLength: {
                value: 6,
                message: t('auth.passwordMinLength')
              }
            })}
          />
          {errors.password && (
            <p className="mt-1 text-sm text-red-600">{errors.password.message}</p>
          )}
        </div>

        <div>
          <label htmlFor="confirmPassword" className="label">
            {t('auth.confirmPassword')}
          </label>
          <input
            id="confirmPassword"
            type="password"
            className={`input ${errors.confirmPassword ? 'border-red-500' : ''}`}
            {...register('confirmPassword', { 
              required: t('auth.passwordRequired'),
              validate: value => value === password || t('auth.passwordsDoNotMatch')
            })}
          />
          {errors.confirmPassword && (
            <p className="mt-1 text-sm text-red-600">{errors.confirmPassword.message}</p>
          )}
        </div>

        <div>
          <button
            type="submit"
            disabled={isLoading}
            className="w-full btn btn-primary flex justify-center"
          >
            {isLoading ? (
              <span className="flex items-center">
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                {t('auth.creatingAccount')}
              </span>
            ) : (
              t('auth.register')
            )}
          </button>
        </div>
      </form>

      <div className="mt-6">
        <p className="text-center text-sm text-neutral-600">
          {t('auth.hasAccount')}{' '}
          <Link to="/login" className="font-medium text-primary-600 hover:text-primary-500">
            {t('auth.login')}
          </Link>
        </p>
      </div>
      
      {/* Data Comparison Modal */}
      <DataComparisonModal
        isOpen={showComparisonModal}
        onClose={() => setShowComparisonModal(false)}
        userData={userData}
        existingData={existingData}
        onConfirm={handleComparisonConfirm}
      />
    </div>
  );
}

export default Register;