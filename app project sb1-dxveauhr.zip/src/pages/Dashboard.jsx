import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useProjects } from '../contexts/ProjectsContext';
import { FiUsers, FiDollarSign, FiPlus, FiFilter } from 'react-icons/fi';
import { format } from 'date-fns';
import { Bar, Pie } from 'react-chartjs-2';
import ReactCountryFlag from 'react-country-flag';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
} from 'chart.js';
import { supabase } from '../lib/supabase';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
);

function Dashboard() {
  const { projects, getProjectTransactions } = useProjects();
  const [recentProjects, setRecentProjects] = useState([]);
  const [projectStats, setProjectStats] = useState({ active: 0, completed: 0 });
  const [chartData, setChartData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [users, setUsers] = useState([]);
  const [projectPayments, setProjectPayments] = useState({});
  const [rentabilityData, setRentabilityData] = useState({});
  const [viewMode, setViewMode] = useState('projects'); // 'projects' or 'users'
  const [selectedProject, setSelectedProject] = useState(null);

  useEffect(() => {
    const loadDashboardData = async () => {
      try {
        setLoading(true);
        
        // Get recent projects (sort by created_at desc)
        const sortedProjects = [...projects].sort((a, b) => 
          new Date(b.created_at) - new Date(a.created_at)
        );
        
        setRecentProjects(sortedProjects.slice(0, 5));
        
        // Calculate project stats
        const active = projects.filter(p => p.status !== 'completed' && p.status !== 'archived').length;
        const completed = projects.filter(p => p.status === 'completed').length;
        
        setProjectStats({
          active,
          completed
        });
        
        // Fetch all users
        const { data: usersData, error: usersError } = await supabase
          .from('profiles')
          .select('*');
          
        if (usersError) throw usersError;
        setUsers(usersData || []);
        
        // Prepare financial data for chart
        if (projects.length > 0) {
          const transactionsPromises = projects.slice(0, 3).map(project => 
            getProjectTransactions(project.id)
          );
          
          const transactionsArrays = await Promise.all(transactionsPromises);
          
          // Process transactions for chart
          const labels = projects.slice(0, 3).map(p => p.name);
          const incomeData = [];
          const expenseData = [];
          
          // Calculate payment status and rentability for each project
          const paymentStatus = {};
          const rentability = {};
          
          transactionsArrays.forEach((transactions, index) => {
            const projectId = projects[index]?.id;
            if (!projectId) return;
            
            const income = transactions
              .filter(t => t.type === 'income')
              .reduce((sum, t) => sum + t.amount, 0);
              
            const expense = transactions
              .filter(t => t.type === 'expense')
              .reduce((sum, t) => sum + t.amount, 0);
              
            incomeData.push(income);
            expenseData.push(expense);
            
            // Calculate rentability (income - expense) / expense * 100
            const projectRentability = expense > 0 ? ((income - expense) / expense * 100).toFixed(2) : 0;
            rentability[projectId] = {
              value: projectRentability,
              income,
              expense
            };
            
            // Calculate payment status per user for this project
            const userPayments = {};
            
            // Get all users involved in this project
            const projectUsers = [...new Set(transactions.map(t => t.user_id))];
            
            projectUsers.forEach(userId => {
              const userTransactions = transactions.filter(t => t.user_id === userId);
              const userIncome = userTransactions
                .filter(t => t.type === 'income')
                .reduce((sum, t) => sum + t.amount, 0);
                
              const userExpense = userTransactions
                .filter(t => t.type === 'expense')
                .reduce((sum, t) => sum + t.amount, 0);
                
              // Assume each user should contribute equally to the project
              const expectedContribution = expense / projectUsers.length;
              const paymentPercentage = expectedContribution > 0 ? 
                (userExpense / expectedContribution * 100).toFixed(2) : 100;
                
              userPayments[userId] = {
                paid: userExpense,
                expected: expectedContribution,
                percentage: paymentPercentage,
                isPaidFull: userExpense >= expectedContribution
              };
            });
            
            paymentStatus[projectId] = userPayments;
          });
          
          setProjectPayments(paymentStatus);
          setRentabilityData(rentability);
          
          setChartData({
            labels,
            datasets: [
              {
                label: 'Income',
                data: incomeData,
                backgroundColor: 'rgba(62, 170, 101, 0.7)',
              },
              {
                label: 'Expenses',
                data: expenseData,
                backgroundColor: 'rgba(255, 133, 10, 0.7)',
              },
            ],
          });
        }
      } catch (err) {
        console.error('Error loading dashboard data:', err);
      } finally {
        setLoading(false);
      }
    };
    
    if (projects.length > 0) {
      loadDashboardData();
    } else {
      setLoading(false);
    }
  }, [projects, getProjectTransactions]);

  // Get country code from location string
  const getCountryCode = (location) => {
    if (!location) return 'US'; // Default
    
    // Extract country code from location (assuming format "City, CountryCode")
    const parts = location.split(',');
    if (parts.length > 1) {
      const countryPart = parts[parts.length - 1].trim();
      // If country part is 2 letters, use it as is
      if (countryPart.length === 2) {
        return countryPart.toUpperCase();
      }
      
      // Map common country names to codes
      const countryMap = {
        'USA': 'US',
        'United States': 'US',
        'UK': 'GB',
        'United Kingdom': 'GB',
        'Germany': 'DE',
        'France': 'FR',
        'Spain': 'ES',
        'Italy': 'IT',
        'Canada': 'CA',
        'Australia': 'AU',
        'Japan': 'JP',
        'China': 'CN',
        'India': 'IN',
        'Brazil': 'BR',
        'Russia': 'RU'
      };
      
      return countryMap[countryPart] || 'US';
    }
    
    return 'US';
  };

  const renderUserPaymentStatus = (projectId) => {
    const projectPaymentData = projectPayments[projectId] || {};
    const projectUsers = Object.keys(projectPaymentData);
    
    if (projectUsers.length === 0) {
      return <p className="text-gray-500">No payment data available</p>;
    }
    
    return (
      <div className="space-y-4">
        {projectUsers.map(userId => {
          const user = users.find(u => u.id === userId);
          const paymentData = projectPaymentData[userId];
          
          if (!user || !paymentData) return null;
          
          return (
            <div 
              key={userId} 
              className={`border rounded-lg p-3 ${paymentData.isPaidFull ? 'bg-green-50' : 'bg-red-50'}`}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center">
                  <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center mr-2">
                    {user.location && (
                      <ReactCountryFlag 
                        countryCode={getCountryCode(user.location)}
                        svg
                        style={{
                          width: '1.2em',
                          height: '1.2em',
                        }}
                        title={user.location}
                      />
                    )}
                  </div>
                  <span className="font-medium">{user.full_name || user.email}</span>
                </div>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                  paymentData.isPaidFull ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                }`}>
                  {paymentData.isPaidFull ? 'Paid in Full' : 'Payment Incomplete'}
                </span>
              </div>
              
              <div className="w-full bg-gray-200 rounded-full h-2.5">
                <div 
                  className={`h-2.5 rounded-full ${paymentData.isPaidFull ? 'bg-green-600' : 'bg-red-600'}`}
                  style={{ width: `${Math.min(100, paymentData.percentage)}%` }}
                ></div>
              </div>
              
              <div className="flex justify-between text-xs mt-1">
                <span>Paid: {paymentData.paid.toFixed(2)}</span>
                <span>Expected: {paymentData.expected.toFixed(2)}</span>
                <span>{paymentData.percentage}%</span>
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  const renderProjectRentability = (projectId) => {
    const rentability = rentabilityData[projectId];
    
    if (!rentability) {
      return <p className="text-gray-500">No rentability data available</p>;
    }
    
    const isPositive = parseFloat(rentability.value) >= 0;
    
    return (
      <div className="border rounded-lg p-4">
        <h3 className="font-medium mb-2">Project Rentability</h3>
        <div className="flex items-center justify-between mb-2">
          <span>Rentability:</span>
          <span className={isPositive ? 'text-green-600 font-bold' : 'text-red-600 font-bold'}>
            {rentability.value}%
          </span>
        </div>
        <div className="space-y-2">
          <div className="flex justify-between">
            <span>Income:</span>
            <span className="text-green-600">{rentability.income.toFixed(2)}</span>
          </div>
          <div className="flex justify-between">
            <span>Expenses:</span>
            <span className="text-red-600">{rentability.expense.toFixed(2)}</span>
          </div>
          <div className="flex justify-between pt-2 border-t">
            <span>Profit/Loss:</span>
            <span className={isPositive ? 'text-green-600 font-bold' : 'text-red-600 font-bold'}>
              {(rentability.income - rentability.expense).toFixed(2)}
            </span>
          </div>
        </div>
      </div>
    );
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    <div>
      <h1 className="text-2xl font-bold text-neutral-900 mb-6">Dashboard</h1>
      
      {/* View Mode Selector */}
      <div className="flex mb-6 bg-white rounded-lg shadow-sm p-2">
        <button
          onClick={() => setViewMode('projects')}
          className={`flex-1 py-2 px-4 rounded-md ${viewMode === 'projects' ? 'bg-primary-100 text-primary-700' : 'text-gray-600 hover:bg-gray-100'}`}
        >
          Projects View
        </button>
        <button
          onClick={() => setViewMode('users')}
          className={`flex-1 py-2 px-4 rounded-md ${viewMode === 'users' ? 'bg-primary-100 text-primary-700' : 'text-gray-600 hover:bg-gray-100'}`}
        >
          Users View
        </button>
      </div>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        <div className="card flex items-center">
          <div className="rounded-full bg-secondary-100 p-3 mr-4">
            <FiUsers className="text-secondary-600 text-xl" />
          </div>
          <div>
            <p className="text-sm text-neutral-500">Active Projects</p>
            <p className="text-2xl font-bold">{projectStats.active}</p>
          </div>
        </div>
        
        <div className="card flex items-center">
          <div className="rounded-full bg-accent-100 p-3 mr-4">
            <FiDollarSign className="text-accent-600 text-xl" />
          </div>
          <div>
            <p className="text-sm text-neutral-500">Completed Projects</p>
            <p className="text-2xl font-bold">{projectStats.completed}</p>
          </div>
        </div>
        
        <div className="card flex items-center">
          <div className="rounded-full bg-primary-100 p-3 mr-4">
            <FiUsers className="text-primary-600 text-xl" />
          </div>
          <div>
            <p className="text-sm text-neutral-500">Total Users</p>
            <p className="text-2xl font-bold">{users.length}</p>
          </div>
        </div>
      </div>

      {viewMode === 'projects' ? (
        <>
          {/* Chart */}
          <div className="card mb-8">
            <h2 className="text-lg font-semibold mb-4">Financial Overview</h2>
            {chartData ? (
              <div className="h-64">
                <Bar 
                  data={chartData} 
                  options={{
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                      legend: {
                        position: 'top',
                      },
                      title: {
                        display: false,
                      },
                    },
                  }}
                />
              </div>
            ) : (
              <p className="text-neutral-500">No financial data available</p>
            )}
          </div>

          {/* Recent Projects */}
          <div className="card">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold">Recent Projects</h2>
              <Link to="/projects" className="text-sm text-primary-600 hover:text-primary-700">
                View all
              </Link>
            </div>
            
            {recentProjects.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-neutral-200">
                  <thead className="bg-neutral-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                        Project Name
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                        Created
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                        Currency
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                        Role
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-neutral-200">
                    {recentProjects.map((project) => (
                      <tr key={project.id} className="hover:bg-neutral-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <Link to={`/projects/${project.id}`} className="text-primary-600 hover:text-primary-700 font-medium">
                            {project.name}
                          </Link>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-500">
                          {format(new Date(project.created_at), 'MMM d, yyyy')}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-500">
                          {project.base_currency || 'USD'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`badge ${
                            project.role === 'admin' 
                              ? 'badge-secondary' 
                              : 'badge-primary'
                          }`}>
                            {project.role}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <button 
                            onClick={() => setSelectedProject(selectedProject === project.id ? null : project.id)}
                            className="text-primary-600 hover:text-primary-700"
                          >
                            {selectedProject === project.id ? 'Hide Details' : 'View Details'}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-neutral-500 mb-4">No projects yet</p>
                <Link to="/projects/new" className="btn btn-primary inline-flex items-center">
                  <FiPlus className="mr-2" />
                  Create your first project
                </Link>
              </div>
            )}
          </div>
          
          {/* Project Details (when selected) */}
          {selectedProject && (
            <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="card">
                <h3 className="text-lg font-semibold mb-4">Payment Status</h3>
                {renderUserPaymentStatus(selectedProject)}
              </div>
              <div className="card">
                <h3 className="text-lg font-semibold mb-4">Project Rentability</h3>
                {renderProjectRentability(selectedProject)}
              </div>
            </div>
          )}
        </>
      ) : (
        /* Users View */
        <div className="card">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold">User Overview</h2>
            <div className="flex items-center">
              <span className="inline-block w-3 h-3 rounded-full bg-green-500 mr-1"></span>
              <span className="text-xs mr-3">Paid in Full</span>
              <span className="inline-block w-3 h-3 rounded-full bg-red-500 mr-1"></span>
              <span className="text-xs">Payment Incomplete</span>
            </div>
          </div>
          
          {users.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-neutral-200">
                <thead className="bg-neutral-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                      User
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                      Email
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                      Location
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                      Projects
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                      Payment Status
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-neutral-200">
                  {users.map((user) => {
                    // Calculate overall payment status across all projects
                    let totalPaid = 0;
                    let totalExpected = 0;
                    let projectCount = 0;
                    
                    Object.keys(projectPayments).forEach(projectId => {
                      const userPayment = projectPayments[projectId][user.id];
                      if (userPayment) {
                        totalPaid += userPayment.paid;
                        totalExpected += userPayment.expected;
                        projectCount++;
                      }
                    });
                    
                    const paymentPercentage = totalExpected > 0 ? 
                      (totalPaid / totalExpected * 100).toFixed(2) : 100;
                    const isPaidFull = totalPaid >= totalExpected;
                    
                    return (
                      <tr key={user.id} className={`hover:bg-neutral-50 ${isPaidFull ? 'bg-green-50' : projectCount > 0 ? 'bg-red-50' : ''}`}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="flex-shrink-0 h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center">
                              {user.location ? (
                                <ReactCountryFlag 
                                  countryCode={getCountryCode(user.location)}
                                  svg
                                  style={{
                                    width: '1.5em',
                                    height: '1.5em',
                                  }}
                                  title={user.location}
                                />
                              ) : (
                                <span className="text-gray-600">{user.full_name?.charAt(0).toUpperCase() || user.email?.charAt(0).toUpperCase()}</span>
                              )}
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-gray-900">
                                {user.full_name || 'N/A'}
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {user.email}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {user.location || 'N/A'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {projectCount}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          {projectCount > 0 ? (
                            <div className="w-full">
                              <div className="flex items-center justify-between mb-1">
                                <span className={`text-xs font-medium ${isPaidFull ? 'text-green-700' : 'text-red-700'}`}>
                                  {paymentPercentage}%
                                </span>
                                <span className={`text-xs ${isPaidFull ? 'text-green-700' : 'text-red-700'}`}>
                                  {totalPaid.toFixed(2)} / {totalExpected.toFixed(2)}
                                </span>
                              </div>
                              <div className="w-full bg-gray-200 rounded-full h-2.5">
                                <div 
                                  className={`h-2.5 rounded-full ${isPaidFull ? 'bg-green-600' : 'bg-red-600'}`}
                                  style={{ width: `${Math.min(100, paymentPercentage)}%` }}
                                ></div>
                              </div>
                            </div>
                          ) : (
                            <span className="text-gray-500">No projects</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-neutral-500">No users found</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default Dashboard;