import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useForm } from 'react-hook-form';
import { FiUser, FiMail, FiLock } from 'react-icons/fi';
import { supabase } from '../lib/supabase';

function Profile() {
  const { user, updateProfile } = useAuth();
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState({ type: '', text: '' });
  const [profile, setProfile] = useState(null);
  
  const { register, handleSubmit, formState: { errors }, reset } = useForm();

  useEffect(() => {
    const getProfile = async () => {
      try {
        setLoading(true);
        
        const { data, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single();
          
        if (error) throw error;
        
        setProfile(data);
        reset({
          full_name: data.full_name || '',
          email: user.email || ''
        });
      } catch (err) {
        console.error('Error loading profile:', err);
      } finally {
        setLoading(false);
      }
    };
    
    if (user) {
      getProfile();
    }
  }, [user, reset]);

  const onSubmit = async (data) => {
    try {
      setLoading(true);
      setMessage({ type: '', text: '' });
      
      const updates = {
        full_name: data.full_name,
        updated_at: new Date()
      };
      
      await updateProfile(updates);
      
      setMessage({
        type: 'success',
        text: 'Profile updated successfully!'
      });
      
      // Update local profile state
      setProfile(prev => ({
        ...prev,
        ...updates
      }));
    } catch (err) {
      console.error('Error updating profile:', err);
      setMessage({
        type: 'error',
        text: err.message || 'Failed to update profile'
      });
    } finally {
      setLoading(false);
    }
  };

  if (loading && !profile) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Your Profile</h1>
      
      <div className="bg-white shadow rounded-lg p-6">
        <div className="flex flex-col md:flex-row">
          <div className="md:w-1/3 mb-6 md:mb-0">
            <div className="flex flex-col items-center">
              <div className="h-32 w-32 rounded-full bg-primary-100 flex items-center justify-center mb-4">
                <span className="text-primary-700 font-bold text-4xl">
                  {profile?.full_name?.charAt(0).toUpperCase() || user?.email?.charAt(0).toUpperCase()}
                </span>
              </div>
              <h2 className="text-xl font-medium">{profile?.full_name}</h2>
              <p className="text-gray-500">{user?.email}</p>
            </div>
          </div>
          
          <div className="md:w-2/3 md:pl-8">
            <h3 className="text-lg font-medium mb-4">Edit Profile</h3>
            
            {message.text && (
              <div className={`mb-4 p-3 rounded-md ${
                message.type === 'success' ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'
              }`}>
                {message.text}
              </div>
            )}
            
            <form onSubmit={handleSubmit(onSubmit)}>
              <div className="mb-4">
                <label htmlFor="full_name" className="label flex items-center">
                  <FiUser className="mr-2" />
                  Full Name
                </label>
                <input
                  type="text"
                  id="full_name"
                  className={`input ${errors.full_name ? 'border-red-500' : ''}`}
                  {...register('full_name', { 
                    required: 'Full name is required',
                    minLength: {
                      value: 2,
                      message: 'Name must be at least 2 characters'
                    }
                  })}
                />
                {errors.full_name && (
                  <p className="mt-1 text-sm text-red-600">{errors.full_name.message}</p>
                )}
              </div>

              <div className="mb-4">
                <label htmlFor="email" className="label flex items-center">
                  <FiMail className="mr-2" />
                  Email Address
                </label>
                <input
                  type="email"
                  id="email"
                  className="input bg-gray-100"
                  disabled
                  {...register('email')}
                />
                <p className="mt-1 text-sm text-gray-500">Email cannot be changed</p>
              </div>

              <div className="mt-6">
                <button
                  type="submit"
                  disabled={loading}
                  className="btn btn-primary w-full md:w-auto"
                >
                  {loading ? 'Saving...' : 'Save Changes'}
                </button>
              </div>
            </form>
            
            <div className="mt-8 pt-6 border-t border-gray-200">
              <h3 className="text-lg font-medium mb-4 flex items-center">
                <FiLock className="mr-2" />
                Password & Security
              </h3>
              <p className="text-gray-500 mb-4">
                For security reasons, password changes are handled through a separate process.
              </p>
              <button
                onClick={() => {
                  // This would typically trigger a password reset email
                  alert('Password reset functionality would be implemented here');
                }}
                className="btn btn-secondary"
              >
                Reset Password
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Profile;