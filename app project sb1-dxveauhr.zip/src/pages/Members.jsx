import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useProjects } from '../contexts/ProjectsContext';
import { FiUsers, FiSearch } from 'react-icons/fi';

function Members() {
  const { projects, getProjectMembers } = useProjects();
  const [allMembers, setAllMembers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const fetchAllMembers = async () => {
      try {
        setLoading(true);
        
        // Get members from all projects
        const membersPromises = projects.map(project => 
          getProjectMembers(project.id).then(members => 
            members.map(member => ({
              ...member,
              projectId: project.id,
              projectName: project.name
            }))
          )
        );
        
        const membersArrays = await Promise.all(membersPromises);
        
        // Flatten and deduplicate members by ID
        const membersMap = new Map();
        membersArrays.flat().forEach(member => {
          if (!membersMap.has(member.id)) {
            membersMap.set(member.id, {
              ...member,
              projects: [{ id: member.projectId, name: member.projectName }]
            });
          } else {
            const existingMember = membersMap.get(member.id);
            existingMember.projects.push({ id: member.projectId, name: member.projectName });
          }
        });
        
        setAllMembers(Array.from(membersMap.values()));
      } catch (err) {
        console.error('Error fetching members:', err);
      } finally {
        setLoading(false);
      }
    };
    
    if (projects.length > 0) {
      fetchAllMembers();
    } else {
      setLoading(false);
    }
  }, [projects, getProjectMembers]);

  const filteredMembers = allMembers.filter(member => 
    member.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    member.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Team Members</h1>
      
      <div className="bg-white shadow rounded-lg p-6">
        <div className="mb-6">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <FiSearch className="text-gray-400" />
            </div>
            <input
              type="text"
              className="input pl-10"
              placeholder="Search members..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        
        {filteredMembers.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Name
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Email
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Projects
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredMembers.map((member) => (
                  <tr key={member.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center">
                          {member.avatar_url ? (
                            <img className="h-10 w-10 rounded-full" src={member.avatar_url} alt="" />
                          ) : (
                            <span className="text-gray-500 font-medium">
                              {member.full_name.charAt(0).toUpperCase()}
                            </span>
                          )}
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900">
                            {member.full_name}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {member.email}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      <div className="flex flex-wrap gap-2">
                        {member.projects.map(project => (
                          <Link
                            key={project.id}
                            to={`/projects/${project.id}`}
                            className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-100 text-primary-800 hover:bg-primary-200"
                          >
                            {project.name}
                          </Link>
                        ))}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-8">
            <div className="rounded-full bg-gray-100 p-3 mx-auto w-16 h-16 flex items-center justify-center mb-4">
              <FiUsers className="text-gray-400 text-2xl" />
            </div>
            {searchTerm ? (
              <p className="text-gray-500">No members found matching "{searchTerm}"</p>
            ) : (
              <p className="text-gray-500">No team members yet</p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export default Members;