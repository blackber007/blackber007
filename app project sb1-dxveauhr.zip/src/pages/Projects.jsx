import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useProjects } from '../contexts/ProjectsContext';
import { useForm } from 'react-hook-form';
import { FiPlus, FiEdit2, FiTrash2, FiUsers, FiDollarSign, FiAlertCircle } from 'react-icons/fi';
import { format } from 'date-fns';
import currencyCodes from 'currency-codes';
import { useTranslation } from 'react-i18next';

function Projects() {
  const { t } = useTranslation();
  const { projects, loading, error, createProject, deleteProject, isAdmin } = useProjects();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [deleteId, setDeleteId] = useState(null);
  const [createError, setCreateError] = useState(null);
  const navigate = useNavigate();
  
  const { register, handleSubmit, formState: { errors }, reset } = useForm({
    defaultValues: {
      name: '',
      description: '',
      base_currency: 'USD',
      available_parts: 100
    }
  });

  const currencies = currencyCodes.data.map(currency => ({
    code: currency.code,
    name: `${currency.code} - ${currency.currency}`
  }));

  const onSubmit = async (data) => {
    try {
      setCreateError(null);
      const project = await createProject(data);
      setIsModalOpen(false);
      reset();
      navigate(`/projects/${project.id}`);
    } catch (err) {
      console.error('Error creating project:', err);
      setCreateError(err.message);
    }
  };

  const handleDelete = async (id) => {
    try {
      setIsDeleting(true);
      await deleteProject(id);
      setDeleteId(null);
    } catch (err) {
      console.error('Error deleting project:', err);
    } finally {
      setIsDeleting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 p-4 rounded-md text-red-700">
        <p>Error loading projects: {error}</p>
      </div>
    );
  }

  return (
    <div>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">{t('projects.title')}</h1>
        {isAdmin && (
          <button 
            onClick={() => setIsModalOpen(true)}
            className="mt-3 md:mt-0 btn btn-primary flex items-center"
          >
            <FiPlus className="mr-2" />
            {t('projects.newProject')}
          </button>
        )}
      </div>

      {projects.length > 0 ? (
        <div className="bg-white shadow overflow-hidden sm:rounded-md">
          <ul className="divide-y divide-gray-200">
            {projects.map((project) => (
              <li key={project.id}>
                <div className="px-4 py-4 sm:px-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 h-10 w-10 rounded-full bg-primary-100 flex items-center justify-center">
                        <span className="text-primary-700 font-medium text-lg">
                          {project.name.charAt(0).toUpperCase()}
                        </span>
                      </div>
                      <div className="ml-4">
                        <Link 
                          to={`/projects/${project.id}`}
                          className="text-lg font-medium text-primary-600 hover:text-primary-700"
                        >
                          {project.name}
                        </Link>
                        <p className="text-sm text-gray-500 mt-1">
                          {project.description || t('projects.noDescription')}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Link
                        to={`/projects/${project.id}`}
                        className="btn btn-secondary text-sm"
                      >
                        <FiDollarSign className="mr-1" />
                        {t('projects.finances')}
                      </Link>
                      {(project.role === 'admin' || project.role === 'project_leader') && (
                        <>
                          <Link
                            to={`/projects/${project.id}/members`}
                            className="btn btn-secondary text-sm"
                          >
                            <FiUsers className="mr-1" />
                            {t('common.members')}
                          </Link>
                          <Link
                            to={`/projects/${project.id}/edit`}
                            className="btn btn-secondary text-sm"
                          >
                            <FiEdit2 className="mr-1" />
                            {t('common.edit')}
                          </Link>
                          {project.role === 'admin' && (
                            <button
                              onClick={() => setDeleteId(project.id)}
                              className="btn btn-danger text-sm"
                            >
                              <FiTrash2 className="mr-1" />
                              {t('common.delete')}
                            </button>
                          )}
                        </>
                      )}
                    </div>
                  </div>
                  <div className="mt-2 sm:flex sm:justify-between">
                    <div className="sm:flex">
                      <p className="flex items-center text-sm text-gray-500">
                        {t('projects.currency')}: {project.base_currency || 'USD'}
                      </p>
                      <p className="mt-2 flex items-center text-sm text-gray-500 sm:mt-0 sm:ml-6">
                        {t('projects.role')}: {project.role}
                      </p>
                      <p className="mt-2 flex items-center text-sm text-gray-500 sm:mt-0 sm:ml-6">
                        Parts: {project.available_parts || 100}
                      </p>
                    </div>
                    <div className="mt-2 flex items-center text-sm text-gray-500 sm:mt-0">
                      <p>
                        {t('projects.created')}: {format(new Date(project.created_at), 'MMM d, yyyy')}
                      </p>
                    </div>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>
      ) : (
        <div className="bg-white shadow overflow-hidden sm:rounded-md p-6 text-center">
          <p className="text-gray-500 mb-4">{t('projects.noProjects')}</p>
          {isAdmin ? (
            <button 
              onClick={() => setIsModalOpen(true)}
              className="btn btn-primary inline-flex items-center"
            >
              <FiPlus className="mr-2" />
              {t('projects.createFirstProject')}
            </button>
          ) : (
            <div className="bg-blue-50 p-4 rounded-md text-blue-700 flex items-start">
              <FiAlertCircle className="mr-2 mt-0.5 flex-shrink-0" />
              <p>{t('projects.adminOnlyCreateInfo')}</p>
            </div>
          )}
        </div>
      )}

      {/* New Project Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-10 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 transition-opacity" aria-hidden="true">
              <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
            </div>

            <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>

            <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
              <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                <div className="sm:flex sm:items-start">
                  <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left w-full">
                    <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
                      {t('projects.createProject')}
                    </h3>
                    
                    {createError && (
                      <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-md text-sm">
                        {createError}
                      </div>
                    )}
                    
                    <form onSubmit={handleSubmit(onSubmit)}>
                      <div className="mb-4">
                        <label htmlFor="name" className="label">
                          {t('projects.projectName')}
                        </label>
                        <input
                          type="text"
                          id="name"
                          className={`input ${errors.name ? 'border-red-500' : ''}`}
                          {...register('name', { required: t('projects.projectNameRequired') })}
                        />
                        {errors.name && (
                          <p className="mt-1 text-sm text-red-600">{errors.name.message}</p>
                        )}
                      </div>

                      <div className="mb-4">
                        <label htmlFor="description" className="label">
                          {t('projects.description')}
                        </label>
                        <textarea
                          id="description"
                          rows="3"
                          className="input"
                          {...register('description')}
                        ></textarea>
                      </div>

                      <div className="mb-4">
                        <label htmlFor="base_currency" className="label">
                          {t('projects.baseCurrency')}
                        </label>
                        <select
                          id="base_currency"
                          className="input"
                          {...register('base_currency', { required: t('projects.currencyRequired') })}
                        >
                          {currencies.map(currency => (
                            <option key={currency.code} value={currency.code}>
                              {currency.name}
                            </option>
                          ))}
                        </select>
                        {errors.base_currency && (
                          <p className="mt-1 text-sm text-red-600">{errors.base_currency.message}</p>
                        )}
                      </div>

                      <div className="mb-4">
                        <label htmlFor="available_parts" className="label">
                          Available Project Parts
                        </label>
                        <input
                          type="number"
                          id="available_parts"
                          min="1"
                          className={`input ${errors.available_parts ? 'border-red-500' : ''}`}
                          {...register('available_parts', { 
                            required: 'Available parts is required',
                            min: {
                              value: 1,
                              message: 'Must have at least 1 part'
                            }
                          })}
                        />
                        {errors.available_parts && (
                          <p className="mt-1 text-sm text-red-600">{errors.available_parts.message}</p>
                        )}
                        <p className="mt-1 text-sm text-gray-500">
                          Define how many parts are available for this project. Members can request parts to contribute.
                        </p>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
              <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                <button
                  type="button"
                  className="btn btn-primary sm:ml-3"
                  onClick={handleSubmit(onSubmit)}
                >
                  {t('projects.createProject')}
                </button>
                <button
                  type="button"
                  className="btn btn-secondary mt-3 sm:mt-0"
                  onClick={() => {
                    setIsModalOpen(false);
                    setCreateError(null);
                    reset();
                  }}
                >
                  {t('common.cancel')}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteId && (
        <div className="fixed inset-0 z-10 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 transition-opacity" aria-hidden="true">
              <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
            </div>

            <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>

            <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
              <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                <div className="sm:flex sm:items-start">
                  <div className="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-red-100 sm:mx-0 sm:h-10 sm:w-10">
                    <FiTrash2 className="h-6 w-6 text-red-600" />
                  </div>
                  <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
                    <h3 className="text-lg leading-6 font-medium text-gray-900">
                      {t('projects.deleteProject')}
                    </h3>
                    <div className="mt-2">
                      <p className="text-sm text-gray-500">
                        {t('projects.deleteConfirmation')}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                <button
                  type="button"
                  className="btn btn-danger sm:ml-3"
                  onClick={() => handleDelete(deleteId)}
                  disabled={isDeleting}
                >
                  {isDeleting ? t('projects.deleting') : t('common.delete')}
                </button>
                <button
                  type="button"
                  className="btn btn-secondary mt-3 sm:mt-0"
                  onClick={() => setDeleteId(null)}
                  disabled={isDeleting}
                >
                  {t('common.cancel')}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Projects;