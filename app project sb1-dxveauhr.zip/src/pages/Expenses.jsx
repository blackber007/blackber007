import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useProjects } from '../contexts/ProjectsContext';
import { FiDollarSign, FiFilter, FiDownload } from 'react-icons/fi';
import { format } from 'date-fns';

function Expenses() {
  const { projects, getProjectTransactions } = useProjects();
  const [allTransactions, setAllTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    type: 'all',
    project: 'all',
    dateRange: 'all'
  });

  useEffect(() => {
    const fetchAllTransactions = async () => {
      try {
        setLoading(true);
        
        // Get transactions from all projects
        const transactionsPromises = projects.map(project => 
          getProjectTransactions(project.id).then(transactions => 
            transactions.map(transaction => ({
              ...transaction,
              projectId: project.id,
              projectName: project.name,
              baseCurrency: project.base_currency
            }))
          )
        );
        
        const transactionsArrays = await Promise.all(transactionsPromises);
        const allTransactions = transactionsArrays.flat();
        
        // Sort by date (newest first)
        allTransactions.sort((a, b) => new Date(b.date) - new Date(a.date));
        
        setAllTransactions(allTransactions);
      } catch (err) {
        console.error('Error fetching transactions:', err);
      } finally {
        setLoading(false);
      }
    };
    
    if (projects.length > 0) {
      fetchAllTransactions();
    } else {
      setLoading(false);
    }
  }, [projects, getProjectTransactions]);

  const handleFilterChange = (filterName, value) => {
    setFilters(prev => ({
      ...prev,
      [filterName]: value
    }));
  };

  const getDateRangeFilter = (dateRange) => {
    const today = new Date();
    switch (dateRange) {
      case 'today':
        return date => format(new Date(date), 'yyyy-MM-dd') === format(today, 'yyyy-MM-dd');
      case 'week':
        const weekAgo = new Date(today);
        weekAgo.setDate(today.getDate() - 7);
        return date => new Date(date) >= weekAgo;
      case 'month':
        const monthAgo = new Date(today);
        monthAgo.setMonth(today.getMonth() - 1);
        return date => new Date(date) >= monthAgo;
      case 'year':
        const yearAgo = new Date(today);
        yearAgo.setFullYear(today.getFullYear() - 1);
        return date => new Date(date) >= yearAgo;
      default:
        return () => true;
    }
  };

  const filteredTransactions = allTransactions.filter(transaction => {
    // Filter by type
    if (filters.type !== 'all' && transaction.type !== filters.type) {
      return false;
    }
    
    // Filter by project
    if (filters.project !== 'all' && transaction.projectId !== filters.project) {
      return false;
    }
    
    // Filter by date range
    const dateRangeFilter = getDateRangeFilter(filters.dateRange);
    if (!dateRangeFilter(transaction.date)) {
      return false;
    }
    
    return true;
  });

  // Calculate totals
  const totals = filteredTransactions.reduce((acc, transaction) => {
    const currency = transaction.currency;
    if (!acc[currency]) {
      acc[currency] = {
        income: 0,
        expense: 0
      };
    }
    
    if (transaction.type === 'income') {
      acc[currency].income += transaction.amount;
    } else {
      acc[currency].expense += transaction.amount;
    }
    
    return acc;
  }, {});

  const exportToCSV = () => {
    // Create CSV content
    const headers = ['Date', 'Project', 'Description', 'Category', 'Type', 'Amount', 'Currency'];
    const csvRows = [headers];
    
    filteredTransactions.forEach(transaction => {
      const row = [
        format(new Date(transaction.date), 'yyyy-MM-dd'),
        transaction.projectName,
        transaction.description,
        transaction.expense_categories?.name || '',
        transaction.type,
        transaction.amount,
        transaction.currency
      ];
      csvRows.push(row);
    });
    
    // Convert to CSV string
    const csvContent = csvRows.map(row => row.join(',')).join('\n');
    
    // Create and download file
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `transactions_${format(new Date(), 'yyyy-MM-dd')}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Expenses & Income</h1>
        <button 
          onClick={exportToCSV}
          className="mt-3 md:mt-0 btn btn-secondary flex items-center"
          disabled={filteredTransactions.length === 0}
        >
          <FiDownload className="mr-2" />
          Export CSV
        </button>
      </div>
      
      <div className="bg-white shadow rounded-lg p-6">
        {/* Filters */}
        <div className="mb-6 bg-gray-50 p-4 rounded-md">
          <div className="flex items-center mb-4">
            <FiFilter className="text-gray-500 mr-2" />
            <h2 className="text-lg font-medium">Filters</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label htmlFor="type-filter" className="label">
                Transaction Type
              </label>
              <select
                id="type-filter"
                className="input"
                value={filters.type}
                onChange={(e) => handleFilterChange('type', e.target.value)}
              >
                <option value="all">All Transactions</option>
                <option value="income">Income Only</option>
                <option value="expense">Expenses Only</option>
              </select>
            </div>
            
            <div>
              <label htmlFor="project-filter" className="label">
                Project
              </label>
              <select
                id="project-filter"
                className="input"
                value={filters.project}
                onChange={(e) => handleFilterChange('project', e.target.value)}
              >
                <option value="all">All Projects</option>
                {projects.map(project => (
                  <option key={project.id} value={project.id}>
                    {project.name}
                  </option>
                ))}
              </select>
            </div>
            
            <div>
              <label htmlFor="date-filter" className="label">
                Date Range
              </label>
              <select
                id="date-filter"
                className="input"
                value={filters.dateRange}
                onChange={(e) => handleFilterChange('dateRange', e.target.value)}
              >
                <option value="all">All Time</option>
                <option value="today">Today</option>
                <option value="week">Last 7 Days</option>
                <option value="month">Last 30 Days</option>
                <option value="year">Last Year</option>
              </select>
            </div>
          </div>
        </div>
        
        {/* Summary Cards */}
        {Object.keys(totals).length > 0 && (
          <div className="mb-6 grid grid-cols-1 md:grid-cols-3 gap-4">
            {Object.entries(totals).map(([currency, data]) => (
              <div key={currency} className="bg-gray-50 p-4 rounded-md">
                <h3 className="text-lg font-medium mb-2">{currency} Summary</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Income:</span>
                    <span className="text-green-600 font-medium">
                      {currency} {data.income.toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Expenses:</span>
                    <span className="text-red-600 font-medium">
                      {currency} {data.expense.toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between pt-2 border-t">
                    <span className="font-medium">Balance:</span>
                    <span className={`font-bold ${data.income - data.expense >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {currency} {(data.income - data.expense).toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
        
        {/* Transactions Table */}
        {filteredTransactions.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Date
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Project
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Description
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Category
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Amount
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredTransactions.map((transaction) => (
                  <tr key={transaction.id} className={transaction.type === 'income' ? 'bg-green-50' : ''}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {format(new Date(transaction.date), 'MMM d, yyyy')}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-primary-600">
                      <Link to={`/projects/${transaction.projectId}`}>
                        {transaction.projectName}
                      </Link>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {transaction.description}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {transaction.expense_categories?.name || '-'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <span className={transaction.type === 'income' ? 'text-green-600' : 'text-red-600'}>
                        {transaction.type === 'income' ? '+' : '-'} {transaction.currency} {transaction.amount.toFixed(2)}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-8">
            <div className="rounded-full bg-gray-100 p-3 mx-auto w-16 h-16 flex items-center justify-center mb-4">
              <FiDollarSign className="text-gray-400 text-2xl" />
            </div>
            <p className="text-gray-500 mb-4">No transactions found with the current filters</p>
            {projects.length > 0 && (
              <Link to={`/projects/${projects[0].id}`} className="btn btn-primary inline-flex items-center">
                Add your first transaction
              </Link>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export default Expenses;