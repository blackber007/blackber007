import React, { createContext, useContext, useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from './AuthContext';

const BankAccountsContext = createContext();

function useBankAccounts() {
  return useContext(BankAccountsContext);
}

export function BankAccountsProvider({ children }) {
  const { user } = useAuth();
  const [bankAccounts, setBankAccounts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Fetch all bank accounts
  useEffect(() => {
    if (!user) {
      setBankAccounts([]);
      setLoading(false);
      return;
    }

    // Set empty array and don't try to fetch from non-existent table
    setBankAccounts([]);
    setLoading(false);
    
    // Don't attempt to query the bank_accounts table since it doesn't exist
    // This prevents the 404 error in the console
  }, [user]);

  // Create a new bank account - this will be implemented when the table exists
  const createBankAccount = async (accountData) => {
    try {
      setError(null);
      // This would normally create a bank account, but we'll just return a placeholder
      return { id: 'placeholder', ...accountData };
    } catch (err) {
      setError(err.message);
      throw err;
    }
  };

  // Update a bank account - this will be implemented when the table exists
  const updateBankAccount = async (id, updates) => {
    try {
      setError(null);
      // This would normally update a bank account, but we'll just return a placeholder
      return { id, ...updates };
    } catch (err) {
      setError(err.message);
      throw err;
    }
  };

  // Delete a bank account - this will be implemented when the table exists
  const deleteBankAccount = async (id) => {
    try {
      setError(null);
      // This would normally delete a bank account, but we'll just return success
      return { success: true };
    } catch (err) {
      setError(err.message);
      throw err;
    }
  };

  const value = {
    bankAccounts,
    loading,
    error,
    createBankAccount,
    updateBankAccount,
    deleteBankAccount
  };

  return (
    <BankAccountsContext.Provider value={value}>
      {children}
    </BankAccountsContext.Provider>
  );
}