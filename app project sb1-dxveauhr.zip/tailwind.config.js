/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#eef9ff',
          100: '#d9f2ff',
          200: '#bae8ff',
          300: '#8adbff',
          400: '#54c7fc',
          500: '#2aabf3',
          600: '#1a8cd9',
          700: '#1771b0',
          800: '#195f91',
          900: '#1b4f78',
        },
        secondary: {
          50: '#f2fbf4',
          100: '#e0f7e7',
          200: '#c3efd1',
          300: '#95e0b0',
          400: '#62c785',
          500: '#3eaa65',
          600: '#2c8a4f',
          700: '#266e41',
          800: '#235737',
          900: '#1d482f',
        },
        accent: {
          50: '#fff8ed',
          100: '#ffefd3',
          200: '#ffdca6',
          300: '#ffc46d',
          400: '#ffa333',
          500: '#ff850a',
          600: '#ff6a00',
          700: '#cc4d02',
          800: '#a13d0b',
          900: '#82340d',
        },
        neutral: {
          50: '#f8f9fa',
          100: '#f1f3f5',
          200: '#e9ecef',
          300: '#dee2e6',
          400: '#ced4da',
          500: '#adb5bd',
          600: '#868e96',
          700: '#495057',
          800: '#343a40',
          900: '#212529',
        },
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
      },
      borderRadius: {
        'xl': '1rem',
        '2xl': '1.5rem',
      },
      boxShadow: {
        'soft': '0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03)',
        'card': '0 10px 15px -3px rgba(0, 0, 0, 0.05), 0 4px 6px -2px rgba(0, 0, 0, 0.03)',
      },
    },
  },
  plugins: [],
}