import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  Modal,
  TextInput
} from 'react-native';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { format } from 'date-fns';
import { Ionicons } from '@expo/vector-icons';

export default function ProjectDetailsScreen({ route, navigation }: any) {
  const { projectId, projectName } = route.params;
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [project, setProject] = useState<any>(null);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [members, setMembers] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [isAdmin, setIsAdmin] = useState(false);
  const [financialSummary, setFinancialSummary] = useState({
    income: 0,
    expense: 0,
    balance: 0,
    currency: 'USD'
  });
  
  // Transaction modal state
  const [transactionModalVisible, setTransactionModalVisible] = useState(false);
  const [transactionType, setTransactionType] = useState('expense');
  const [transactionAmount, setTransactionAmount] = useState('');
  const [transactionDescription, setTransactionDescription] = useState('');
  const [transactionCategory, setTransactionCategory] = useState('');
  const [transactionDate, setTransactionDate] = useState(new Date().toISOString().split('T')[0]);
  const [isSubmittingTransaction, setIsSubmittingTransaction] = useState(false);

  useEffect(() => {
    fetchProjectData();
  }, [projectId]);

  const fetchProjectData = async () => {
    try {
      setLoading(true);
      
      // Fetch project details
      const { data: projectData, error: projectError } = await supabase
        .from('projects')
        .select('*')
        .eq('id', projectId)
        .single();
        
      if (projectError) throw projectError;
      
      setProject(projectData);
      
      // Check if user is admin
      const { data: memberData, error: memberError } = await supabase
        .from('project_members')
        .select('role')
        .eq('project_id', projectId)
        .eq('user_id', user?.id)
        .single();
        
      if (memberError && memberError.code !== 'PGRST116') throw memberError;
      
      setIsAdmin(memberData?.role === 'admin' || projectData.owner_id === user?.id);
      
      // Fetch transactions
      const { data: transactionsData, error: transactionsError } = await supabase
        .from('transactions')
        .select(`
          *,
          profiles (
            id,
            full_name
          ),
          expense_categories (
            id,
            name
          )
        `)
        .eq('project_id', projectId)
        .order('date', { ascending: false });
        
      if (transactionsError) throw transactionsError;
      
      setTransactions(transactionsData || []);
      
      // Calculate financial summary
      const baseCurrency = projectData.base_currency;
      
      const baseCurrencyTransactions = (transactionsData || []).filter(
        (t: any) => t.currency === baseCurrency
      );
      
      const income = baseCurrencyTransactions
        .filter((t: any) => t.type === 'income')
        .reduce((sum: number, t: any) => sum + t.amount, 0);
        
      const expense = baseCurrencyTransactions
        .filter((t: any) => t.type === 'expense')
        .reduce((sum: number, t: any) => sum + t.amount, 0);
        
      setFinancialSummary({
        income,
        expense,
        balance: income - expense,
        currency: baseCurrency
      });
      
      // Fetch members
      const { data: membersData, error: membersError } = await supabase
        .from('project_members')
        .select(`
          user_id,
          role,
          profiles (
            id,
            full_name,
            email
          )
        `)
        .eq('project_id', projectId);
        
      if (membersError) throw membersError;
      
      setMembers((membersData || []).map((item: any) => ({
        id: item.user_id,
        role: item.role,
        ...item.profiles
      })));
      
      // Fetch categories
      const { data: categoriesData, error: categoriesError } = await supabase
        .from('expense_categories')
        .select('*')
        .eq('project_id', projectId);
        
      if (categoriesError) throw categoriesError;
      
      setCategories(categoriesData || []);
    } catch (err) {
      console.error('Error fetching project data:', err);
      Alert.alert('Error', 'Failed to load project data');
    } finally {
      setLoading(false);
    }
  };

  const addTransaction = async () => {
    if (!transactionDescription || !transactionAmount) {
      Alert.alert('Error', 'Please fill in all required fields');
      return;
    }

    const amount = parseFloat(transactionAmount);
    if (isNaN(amount) || amount <= 0) {
      Alert.alert('Error', 'Amount must be a positive number');
      return;
    }

    try {
      setIsSubmittingTransaction(true);
      
      const transactionData = {
        project_id: projectId,
        user_id: user?.id,
        category_id: transactionCategory || null,
        type: transactionType,
        amount,
        currency: project?.base_currency || 'USD',
        description: transactionDescription,
        date: transactionDate
      };
      
      const { data, error } = await supabase
        .from('transactions')
        .insert([transactionData])
        .select();
        
      if (error) throw error;
      
      // Reset form and close modal
      setTransactionDescription('');
      setTransactionAmount('');
      setTransactionCategory('');
      setTransactionDate(new Date().toISOString().split('T')[0]);
      setTransactionModalVisible(false);
      
      // Refresh data
      fetchProjectData();
      
      Alert.alert('Success', 'Transaction added successfully');
    } catch (err: any) {
      console.error('Error adding transaction:', err);
      Alert.alert('Error', err.message || 'Failed to add transaction');
    } finally {
      setIsSubmittingTransaction(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#2aabf3" />
      </View>
    );
  }

  if (!project) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>Project not found</Text>
        <TouchableOpacity 
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.backButtonText}>Go Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.projectDescription}>
          {project.description || 'No description'}
        </Text>
      </View>

      <View style={styles.actionsContainer}>
        {isAdmin && (
          <>
            <TouchableOpacity 
              style={[styles.actionButton, styles.incomeButton]}
              onPress={() => {
                setTransactionType('income');
                setTransactionModalVisible(true);
              }}
            >
              <Ionicons name="add-circle-outline" size={20} color="white" />
              <Text style={styles.actionButtonText}>Add Income</Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={[styles.actionButton, styles.expenseButton]}
              onPress={() => {
                setTransactionType('expense');
                setTransactionModalVisible(true);
              }}
            >
              <Ionicons name="remove-circle-outline" size={20} color="white" />
              <Text style={styles.actionButtonText}>Add Expense</Text>
            </TouchableOpacity>
          </>
        )}
      </View>

      <View style={styles.summaryCard}>
        <Text style={styles.sectionTitle}>Financial Summary</Text>
        <View style={styles.summaryRow}>
          <Text style={styles.summaryLabel}>Income:</Text>
          <Text style={styles.incomeText}>
            {financialSummary.currency} {financialSummary.income.toFixed(2)}
          </Text>
        </View>
        <View style={styles.summaryRow}>
          <Text style={styles.summaryLabel}>Expenses:</Text>
          <Text style={styles.expenseText}>
            {financialSummary.currency} {financialSummary.expense.toFixed(2)}
          </Text>
        </View>
        <View style={[styles.summaryRow, styles.balanceRow]}>
          <Text style={styles.balanceLabel}>Balance:</Text>
          <Text style={[
            styles.balanceText,
            financialSummary.balance >= 0 ? styles.positiveBalance : styles.negativeBalance
          ]}>
            {financialSummary.currency} {financialSummary.balance.toFixed(2)}
          </Text>
        </View>
      </View>

      <View style={styles.detailsCard}>
        <Text style={styles.sectionTitle}>Project Details</Text>
        <View style={styles.detailRow}>
          <Text style={styles.detailLabel}>Base Currency:</Text>
          <Text style={styles.detailValue}>{project.base_currency}</Text>
        </View>
        <View style={styles.detailRow}>
          <Text style={styles.detailLabel}>Created:</Text>
          <Text style={styles.detailValue}>
            {format(new Date(project.created_at), 'MMM d, yyyy')}
          </Text>
        </View>
        <View style={styles.detailRow}>
          <Text style={styles.detailLabel}>Status:</Text>
          <Text style={[
            styles.statusBadge,
            project.status === 'active' ? styles.activeStatus : 
            project.status === 'completed' ? styles.completedStatus : 
            styles.archivedStatus
          ]}>
            {project.status.charAt(0).toUpperCase() + project.status.slice(1)}
          </Text>
        </View>
      </View>

      <View style={styles.membersCard}>
        <Text style={styles.sectionTitle}>Team Members</Text>
        {members.length > 0 ? (
          members.map((member) => (
            <View key={member.id} style={styles.memberRow}>
              <View style={styles.memberAvatar}>
                <Text style={styles.memberInitial}>
                  {member.full_name.charAt(0).toUpperCase()}
                </Text>
              </View>
              <View style={styles.memberInfo}>
                <Text style={styles.memberName}>{member.full_name}</Text>
                <Text style={styles.memberEmail}>{member.email}</Text>
              </View>
              <View style={[
                styles.roleBadge,
                member.role === 'admin' ? styles.adminRole : styles.memberRole
              ]}>
                <Text style={styles.roleText}>{member.role}</Text>
              </View>
            </View>
          ))
        ) : (
          <Text style={styles.emptyText}>No team members yet</Text>
        )}
      </View>

      <View style={styles.transactionsCard}>
        <Text style={styles.sectionTitle}>Recent Transactions</Text>
        {transactions.length > 0 ? (
          transactions.slice(0, 5).map((transaction) => (
            <View 
              key={transaction.id} 
              style={[
                styles.transactionRow,
                transaction.type === 'income' ? styles.incomeRow : {}
              ]}
            >
              <View style={styles.transactionMain}>
                <Text style={styles.transactionDescription}>
                  {transaction.description}
                </Text>
                <Text style={styles.transactionDate}>
                  {format(new Date(transaction.date), 'MMM d, yyyy')}
                </Text>
                <Text style={styles.transactionCategory}>
                  {transaction.expense_categories?.name || 'Uncategorized'}
                </Text>
              </View>
              <View style={styles.transactionAmount}>
                <Text style={[
                  styles.amountText,
                  transaction.type === 'income' ? styles.incomeAmount : styles.expenseAmount
                ]}>
                  {transaction.type === 'income' ? '+' : '-'} {transaction.currency} {transaction.amount.toFixed(2)}
                </Text>
              </View>
            </View>
          ))
        ) : (
          <Text style={styles.emptyText}>No transactions yet</Text>
        )}
      </View>

      {/* Transaction Modal */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={transactionModalVisible}
        onRequestClose={() => setTransactionModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>
              {transactionType === 'income' ? 'Add Income' : 'Add Expense'}
            </Text>
            
            <View style={styles.inputContainer}>
              <Text style={styles.label}>Description</Text>
              <TextInput
                style={styles.input}
                value={transactionDescription}
                onChangeText={setTransactionDescription}
                placeholder="Enter description"
              />
            </View>
            
            <View style={styles.inputContainer}>
              <Text style={styles.label}>Amount</Text>
              <TextInput
                style={styles.input}
                value={transactionAmount}
                onChangeText={setTransactionAmount}
                placeholder="0.00"
                keyboardType="numeric"
              />
            </View>
            
            <View style={styles.inputContainer}>
              <Text style={styles.label}>Date</Text>
              <TextInput
                style={styles.input}
                value={transactionDate}
                onChangeText={setTransactionDate}
                placeholder="YYYY-MM-DD"
              />
            </View>
            
            {transactionType === 'expense' && categories.length > 0 && (
              <View style={styles.inputContainer}>
                <Text style={styles.label}>Category</Text>
                <View style={styles.pickerContainer}>
                  {categories.map((category) => (
                    <TouchableOpacity
                      key={category.id}
                      style={[
                        styles.categoryChip,
                        transactionCategory === category.id ? styles.selectedCategory : {}
                      ]}
                      onPress={() => setTransactionCategory(category.id)}
                    >
                      <Text style={[
                        styles.categoryChipText,
                        transactionCategory === category.id ? styles.selectedCategoryText : {}
                      ]}>
                        {category.name}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>
            )}
            
            <View style={styles.modalButtons}>
              <TouchableOpacity 
                style={styles.cancelButton}
                onPress={() => setTransactionModalVisible(false)}
                disabled={isSubmittingTransaction}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={[
                  styles.submitButton,
                  transactionType === 'income' ? styles.incomeButton : styles.expenseButton
                ]}
                onPress={addTransaction}
                disabled={isSubmittingTransaction}
              >
                {isSubmittingTransaction ? (
                  <ActivityIndicator color="#fff" size="small" />
                ) : (
                  <Text style={styles.submitButtonText}>
                    {transactionType === 'income' ? 'Add Income' : 'Add Expense'}
                  </Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  errorText: {
    fontSize: 16,
    color: '#dc3545',
    marginBottom: 20,
  },
  backButton: {
    backgroundColor: '#2aabf3',
    borderRadius: 8,
    padding: 12,
  },
  backButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
  header: {
    padding: 20,
    paddingBottom: 10,
  },
  projectDescription: {
    fontSize: 16,
    color: '#495057',
  },
  actionsContainer: {
    flexDirection: 'row',
    padding: 20,
    paddingTop: 10,
    paddingBottom: 10,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 8,
    padding: 12,
    marginRight: 10,
  },
  incomeButton: {
    backgroundColor: '#3eaa65',
  },
  expenseButton: {
    backgroundColor: '#dc3545',
  },
  actionButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
    marginLeft: 5,
  },
  summaryCard: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    margin: 20,
    marginTop: 10,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#212529',
    marginBottom: 10,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 8,
  },
  summaryLabel: {
    fontSize: 14,
    color: '#495057',
  },
  incomeText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#3eaa65',
  },
  expenseText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#dc3545',
  },
  balanceRow: {
    borderTopWidth: 1,
    borderTopColor: '#e9ecef',
    paddingTop: 10,
    marginTop: 5,
  },
  balanceLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#212529',
  },
  balanceText: {
    fontSize: 16,
    fontWeight: '600',
  },
  positiveBalance: {
    color: '#3eaa65',
  },
  negativeBalance: {
    color: '#dc3545',
  },
  detailsCard: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    margin: 20,
    marginTop: 10,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 2,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
  },
  detailLabel: {
    fontSize: 14,
    color: '#495057',
  },
  detailValue: {
    fontSize: 14,
    color: '#212529',
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    fontSize: 12,
    fontWeight: '600',
  },
  activeStatus: {
    backgroundColor: '#d1e7dd',
    color: '#0f5132',
  },
  completedStatus: {
    backgroundColor: '#cff4fc',
    color: '#055160',
  },
  archivedStatus: {
    backgroundColor: '#e2e3e5',
    color: '#41464b',
  },
  membersCard: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    margin: 20,
    marginTop: 10,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 2,
  },
  memberRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#e9ecef',
  },
  memberAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#e9ecef',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
  memberInitial: {
    fontSize: 18,
    fontWeight: '600',
    color: '#495057',
  },
  memberInfo: {
    flex: 1,
  },
  memberName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#212529',
  },
  memberEmail: {
    fontSize: 12,
    color: '#6c757d',
  },
  roleBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  adminRole: {
    backgroundColor: '#f8d7da',
  },
  memberRole: {
    backgroundColor: '#d1e7dd',
  },
  roleText: {
    fontSize: 12,
    fontWeight: '600',
  },
  emptyText: {
    fontSize: 14,
    color: '#6c757d',
    fontStyle: 'italic',
    textAlign: 'center',
    paddingVertical: 10,
  },
  transactionsCard: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    margin: 20,
    marginTop: 10,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 2,
  },
  transactionRow: {
    flexDirection: 'row',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#e9ecef',
  },
  incomeRow: {
    backgroundColor: '#f8f9fa',
  },
  transactionMain: {
    flex: 1,
  },
  transactionDescription: {
    fontSize: 14,
    fontWeight: '600',
    color: '#212529',
  },
  transactionDate: {
    fontSize: 12,
    color: '#6c757d',
    marginTop: 2,
  },
  transactionCategory: {
    fontSize: 12,
    color: '#6c757d',
    marginTop: 2,
  },
  transactionAmount: {
    justifyContent: 'center',
  },
  amountText: {
    fontSize: 14,
    fontWeight: '600',
  },
  incomeAmount: {
    color: '#3eaa65',
  },
  expenseAmount: {
    color: '#dc3545',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 20,
    width: '90%',
    maxWidth: 400,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
    color: '#212529',
  },
  inputContainer: {
    marginBottom: 15,
  },
  label: {
    fontSize: 14,
    fontWeight: '500',
    color: '#495057',
    marginBottom: 5,
  },
  input: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#dee2e6',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
  },
  pickerContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  categoryChip: {
    backgroundColor: '#e9ecef',
    borderRadius: 16,
    paddingHorizontal: 12,
    paddingVertical: 6,
    margin: 4,
  },
  selectedCategory: {
    backgroundColor: '#2aabf3',
  },
  categoryChipText: {
    fontSize: 12,
    color: '#495057',
  },
  selectedCategoryText: {
    color: '#fff',
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginTop: 10,
  },
  cancelButton: {
    padding: 10,
    marginRight: 10,
  },
  cancelButtonText: {
    color: '#6c757d',
    fontSize: 14,
    fontWeight: '600',
  },
  submitButton: {
    borderRadius: 8,
    padding: 10,
    minWidth: 100,
    alignItems: 'center',
  },
  submitButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
});