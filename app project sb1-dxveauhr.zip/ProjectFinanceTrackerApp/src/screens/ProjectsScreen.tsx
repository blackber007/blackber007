import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  Modal,
  TextInput,
  ScrollView
} from 'react-native';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { format } from 'date-fns';
import Ionicons from '@expo/vector-icons/Ionicons';

export default function ProjectsScreen({ navigation }: any) {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [projects, setProjects] = useState<any[]>([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [projectName, setProjectName] = useState('');
  const [projectDescription, setProjectDescription] = useState('');
  const [projectCurrency, setProjectCurrency] = useState('USD');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    fetchProjects();
    checkAdminStatus();
  }, []);

  const checkAdminStatus = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('is_admin')
        .eq('id', user?.id)
        .single();
        
      if (error) throw error;
      
      setIsAdmin(data?.is_admin || false);
    } catch (err) {
      console.error('Error checking admin status:', err);
    }
  };

  const fetchProjects = async () => {
    try {
      setLoading(true);
      
      // Get projects where user is the owner
      const { data: ownedProjects, error: ownedError } = await supabase
        .from('projects')
        .select(`
          id,
          name,
          description,
          base_currency,
          created_at,
          owner_id,
          status
        `)
        .eq('owner_id', user?.id);
        
      if (ownedError) throw ownedError;
      
      // Get projects where user is a member
      const { data: memberProjects, error: memberError } = await supabase
        .rpc('get_user_project_memberships', { user_id: user?.id });
        
      if (memberError) throw memberError;
      
      let memberProjectDetails: any[] = [];
      
      if (memberProjects && memberProjects.length > 0) {
        const memberProjectIds = memberProjects.map((mp: any) => mp.project_id);
        
        const { data: projectDetails, error: detailsError } = await supabase
          .from('projects')
          .select(`
            id,
            name,
            description,
            base_currency,
            created_at,
            owner_id,
            status
          `)
          .in('id', memberProjectIds);
          
        if (detailsError) throw detailsError;
        
        memberProjectDetails = projectDetails || [];
      }
      
      // Combine both arrays
      const allProjects = [...(ownedProjects || []), ...memberProjectDetails];
      
      // Sort by created_at desc
      allProjects.sort((a, b) => 
        new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
      );
      
      setProjects(allProjects);
    } catch (err) {
      console.error('Error fetching projects:', err);
      Alert.alert('Error', 'Failed to load projects');
    } finally {
      setLoading(false);
    }
  };

  const createProject = async () => {
    if (!projectName) {
      Alert.alert('Error', 'Project name is required');
      return;
    }

    try {
      setIsSubmitting(true);
      
      // Insert project
      const { data: project, error: projectError } = await supabase
        .from('projects')
        .insert([
          { 
            name: projectName,
            description: projectDescription,
            base_currency: projectCurrency,
            owner_id: user?.id,
            status: 'active'
          }
        ])
        .select();
        
      if (projectError) throw projectError;
      
      // Add owner as a project member with 'admin' role
      const { error: memberError } = await supabase
        .from('project_members')
        .insert([
          { 
            project_id: project[0].id,
            user_id: user?.id,
            role: 'admin'
          }
        ]);
        
      if (memberError) throw memberError;
      
      // Reset form and close modal
      setProjectName('');
      setProjectDescription('');
      setProjectCurrency('USD');
      setModalVisible(false);
      
      // Refresh projects list
      fetchProjects();
      
      // Navigate to the new project
      navigation.navigate('ProjectDetails', { 
        projectId: project[0].id,
        projectName: project[0].name
      });
    } catch (err: any) {
      console.error('Error creating project:', err);
      Alert.alert('Error', err.message || 'Failed to create project');
    } finally {
      setIsSubmitting(false);
    }
  };

  const renderProjectItem = ({ item }: { item: any }) => (
    <TouchableOpacity 
      style={styles.projectCard}
      onPress={() => navigation.navigate('ProjectDetails', { 
        projectId: item.id,
        projectName: item.name
      })}
    >
      <Text style={styles.projectName}>{item.name}</Text>
      <Text style={styles.projectDescription} numberOfLines={2}>
        {item.description || 'No description'}
      </Text>
      <View style={styles.projectFooter}>
        <Text style={styles.projectDate}>
          Created: {format(new Date(item.created_at), 'MMM d, yyyy')}
        </Text>
        <Text style={styles.projectCurrency}>
          {item.base_currency || 'USD'}
        </Text>
      </View>
    </TouchableOpacity>
  );

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#2aabf3" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Projects</Text>
        {isAdmin && (
          <TouchableOpacity 
            style={styles.addButton}
            onPress={() => setModalVisible(true)}
          >
            <Ionicons name="add" size={24} color="white" />
          </TouchableOpacity>
        )}
      </View>

      {projects.length > 0 ? (
        <FlatList
          data={projects}
          renderItem={renderProjectItem}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.listContainer}
        />
      ) : (
        <View style={styles.emptyState}>
          <Text style={styles.emptyStateText}>No projects yet</Text>
          {isAdmin ? (
            <TouchableOpacity 
              style={styles.createButton}
              onPress={() => setModalVisible(true)}
            >
              <Text style={styles.createButtonText}>Create your first project</Text>
            </TouchableOpacity>
          ) : (
            <Text style={styles.adminOnlyText}>
              Only administrators can create new projects. Please contact an administrator if you need to create a project.
            </Text>
          )}
        </View>
      )}

      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>New Project</Text>
            
            <View style={styles.inputContainer}>
              <Text style={styles.label}>Project Name</Text>
              <TextInput
                style={styles.input}
                value={projectName}
                onChangeText={setProjectName}
                placeholder="Enter project name"
              />
            </View>
            
            <View style={styles.inputContainer}>
              <Text style={styles.label}>Description</Text>
              <TextInput
                style={[styles.input, styles.textArea]}
                value={projectDescription}
                onChangeText={setProjectDescription}
                placeholder="Enter project description (optional)"
                multiline
                numberOfLines={4}
              />
            </View>
            
            <View style={styles.inputContainer}>
              <Text style={styles.label}>Base Currency</Text>
              <TextInput
                style={styles.input}
                value={projectCurrency}
                onChangeText={setProjectCurrency}
                placeholder="USD"
              />
            </View>
            
            <View style={styles.modalButtons}>
              <TouchableOpacity 
                style={styles.cancelButton}
                onPress={() => setModalVisible(false)}
                disabled={isSubmitting}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={styles.submitButton}
                onPress={createProject}
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <ActivityIndicator color="#fff" size="small" />
                ) : (
                  <Text style={styles.submitButtonText}>Create Project</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    paddingBottom: 10,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#212529',
  },
  addButton: {
    backgroundColor: '#2aabf3',
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  listContainer: {
    padding: 20,
  },
  projectCard: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 2,
  },
  projectName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#2aabf3',
    marginBottom: 5,
  },
  projectDescription: {
    fontSize: 14,
    color: '#495057',
    marginBottom: 10,
  },
  projectFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  projectDate: {
    fontSize: 12,
    color: '#6c757d',
  },
  projectCurrency: {
    fontSize: 12,
    color: '#6c757d',
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  emptyStateText: {
    fontSize: 16,
    color: '#6c757d',
    marginBottom: 15,
  },
  createButton: {
    backgroundColor: '#2aabf3',
    borderRadius: 8,
    padding: 12,
  },
  createButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
  adminOnlyText: {
    textAlign: 'center',
    color: '#6c757d',
    padding: 20,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 20,
    width: '90%',
    maxWidth: 400,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
    color: '#212529',
  },
  inputContainer: {
    marginBottom: 15,
  },
  label: {
    fontSize: 14,
    fontWeight: '500',
    color: '#495057',
    marginBottom: 5,
  },
  input: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#dee2e6',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
  },
  textArea: {
    height: 100,
    textAlignVertical: 'top',
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginTop: 10,
  },
  cancelButton: {
    padding: 10,
    marginRight: 10,
  },
  cancelButtonText: {
    color: '#6c757d',
    fontSize: 14,
    fontWeight: '600',
  },
  submitButton: {
    backgroundColor: '#2aabf3',
    borderRadius: 8,
    padding: 10,
    minWidth: 100,
    alignItems: 'center',
  },
  submitButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
});