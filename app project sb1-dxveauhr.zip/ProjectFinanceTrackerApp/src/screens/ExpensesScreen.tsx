import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  ScrollView
} from 'react-native';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { format } from 'date-fns';
import Ionicons from '@expo/vector-icons/Ionicons';

export default function ExpensesScreen({ navigation }: any) {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [projects, setProjects] = useState<any[]>([]);
  const [filters, setFilters] = useState({
    type: 'all',
    project: 'all',
    dateRange: 'all'
  });
  const [summary, setSummary] = useState<Record<string, { income: number, expense: number }>>({});

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    calculateSummary();
  }, [transactions, filters]);

  const fetchData = async () => {
    try {
      setLoading(true);
      
      // Fetch projects
      const { data: projectsData, error: projectsError } = await supabase
        .from('projects')
        .select('id, name')
        .order('name');
        
      if (projectsError) throw projectsError;
      
      setProjects(projectsData || []);
      
      // Fetch all transactions from all projects
      const { data: transactionsData, error: transactionsError } = await supabase
        .from('transactions')
        .select(`
          *,
          projects (
            id,
            name,
            base_currency
          ),
          expense_categories (
            id,
            name
          )
        `)
        .order('date', { ascending: false });
        
      if (transactionsError) throw transactionsError;
      
      setTransactions(transactionsData || []);
    } catch (err) {
      console.error('Error fetching data:', err);
      Alert.alert('Error', 'Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  const calculateSummary = () => {
    const filteredTransactions = filterTransactions();
    
    const newSummary: Record<string, { income: number, expense: number }> = {};
    
    filteredTransactions.forEach(transaction => {
      const currency = transaction.currency;
      
      if (!newSummary[currency]) {
        newSummary[currency] = { income: 0, expense: 0 };
      }
      
      if (transaction.type === 'income') {
        newSummary[currency].income += transaction.amount;
      } else {
        newSummary[currency].expense += transaction.amount;
      }
    });
    
    setSummary(newSummary);
  };

  const filterTransactions = () => {
    return transactions.filter(transaction => {
      // Filter by type
      if (filters.type !== 'all' && transaction.type !== filters.type) {
        return false;
      }
      
      // Filter by project
      if (filters.project !== 'all' && transaction.project_id !== filters.project) {
        return false;
      }
      
      // Filter by date range
      if (filters.dateRange !== 'all') {
        const transactionDate = new Date(transaction.date);
        const today = new Date();
        
        if (filters.dateRange === 'today') {
          const todayStr = format(today, 'yyyy-MM-dd');
          const transactionStr = format(transactionDate, 'yyyy-MM-dd');
          if (todayStr !== transactionStr) {
            return false;
          }
        } else if (filters.dateRange === 'week') {
          const weekAgo = new Date();
          weekAgo.setDate(today.getDate() - 7);
          if (transactionDate < weekAgo) {
            return false;
          }
        } else if (filters.dateRange === 'month') {
          const monthAgo = new Date();
          monthAgo.setDate(today.getDate() - 30);
          if (transactionDate < monthAgo) {
            return false;
          }
        } else if (filters.dateRange === 'year') {
          const yearAgo = new Date();
          yearAgo.setFullYear(today.getFullYear() - 1);
          if (transactionDate < yearAgo) {
            return false;
          }
        }
      }
      
      return true;
    });
  };

  const renderTransactionItem = ({ item }: { item: any }) => (
    <TouchableOpacity 
      style={[
        styles.transactionCard,
        item.type === 'income' ? styles.incomeCard : {}
      ]}
      onPress={() => navigation.navigate('ProjectDetails', { 
        projectId: item.project_id,
        projectName: item.projects?.name
      })}
    >
      <View style={styles.transactionHeader}>
        <Text style={styles.transactionDescription}>{item.description}</Text>
        <Text style={[
          styles.transactionAmount,
          item.type === 'income' ? styles.incomeAmount : styles.expenseAmount
        ]}>
          {item.type === 'income' ? '+' : '-'} {item.currency} {item.amount.toFixed(2)}
        </Text>
      </View>
      <View style={styles.transactionDetails}>
        <Text style={styles.transactionProject}>{item.projects?.name}</Text>
        <Text style={styles.transactionDate}>
          {format(new Date(item.date), 'MMM d, yyyy')}
        </Text>
        <Text style={styles.transactionCategory}>
          {item.expense_categories?.name || 'Uncategorized'}
        </Text>
      </View>
    </TouchableOpacity>
  );

  const renderSummaryItem = ([currency, data]: [string, { income: number, expense: number }]) => (
    <View key={currency} style={styles.summaryCard}>
      <Text style={styles.summaryTitle}>{currency} Summary</Text>
      <View style={styles.summaryRow}>
        <Text style={styles.summaryLabel}>Income:</Text>
        <Text style={styles.incomeText}>
          {currency} {data.income.toFixed(2)}
        </Text>
      </View>
      <View style={styles.summaryRow}>
        <Text style={styles.summaryLabel}>Expenses:</Text>
        <Text style={styles.expenseText}>
          {currency} {data.expense.toFixed(2)}
        </Text>
      </View>
      <View style={[styles.summaryRow, styles.balanceRow]}>
        <Text style={styles.balanceLabel}>Balance:</Text>
        <Text style={[
          styles.balanceText,
          data.income - data.expense >= 0 ? styles.positiveBalance : styles.negativeBalance
        ]}>
          {currency} {(data.income - data.expense).toFixed(2)}
        </Text>
      </View>
    </View>
  );

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#2aabf3" />
      </View>
    );
  }

  const filteredTransactions = filterTransactions();

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Expenses & Income</Text>
      </View>

      <View style={styles.filtersContainer}>
        <Text style={styles.filtersTitle}>Filters</Text>
        
        <View style={styles.filterRow}>
          <Text style={styles.filterLabel}>Transaction Type:</Text>
          <View style={styles.filterOptions}>
            <TouchableOpacity
              style={[
                styles.filterOption,
                filters.type === 'all' ? styles.activeFilter : {}
              ]}
              onPress={() => setFilters({...filters, type: 'all'})}
            >
              <Text style={[
                styles.filterText,
                filters.type === 'all' ? styles.activeFilterText : {}
              ]}>All</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.filterOption,
                filters.type === 'income' ? styles.activeFilter : {}
              ]}
              onPress={() => setFilters({...filters, type: 'income'})}
            >
              <Text style={[
                styles.filterText,
                filters.type === 'income' ? styles.activeFilterText : {}
              ]}>Income</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.filterOption,
                filters.type === 'expense' ? styles.activeFilter : {}
              ]}
              onPress={() => setFilters({...filters, type: 'expense'})}
            >
              <Text style={[
                styles.filterText,
                filters.type === 'expense' ? styles.activeFilterText : {}
              ]}>Expenses</Text>
            </TouchableOpacity>
          </View>
        </View>
        
        <View style={styles.filterRow}>
          <Text style={styles.filterLabel}>Project:</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <View style={styles.filterOptions}>
              <TouchableOpacity
                style={[
                  styles.filterOption,
                  filters.project === 'all' ? styles.activeFilter : {}
                ]}
                onPress={() => setFilters({...filters, project: 'all'})}
              >
                <Text style={[
                  styles.filterText,
                  filters.project === 'all' ? styles.activeFilterText : {}
                ]}>All Projects</Text>
              </TouchableOpacity>
              {projects.map(project => (
                <TouchableOpacity
                  key={project.id}
                  style={[
                    styles.filterOption,
                    filters.project === project.id ? styles.activeFilter : {}
                  ]}
                  onPress={() => setFilters({...filters, project: project.id})}
                >
                  <Text style={[
                    styles.filterText,
                    filters.project === project.id ? styles.activeFilterText : {}
                  ]}>{project.name}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </ScrollView>
        </View>
        
        <View style={styles.filterRow}>
          <Text style={styles.filterLabel}>Date Range:</Text>
          <View style={styles.filterOptions}>
            <TouchableOpacity
              style={[
                styles.filterOption,
                filters.dateRange === 'all' ? styles.activeFilter : {}
              ]}
              onPress={() => setFilters({...filters, dateRange: 'all'})}
            >
              <Text style={[
                styles.filterText,
                filters.dateRange === 'all' ? styles.activeFilterText : {}
              ]}>All Time</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.filterOption,
                filters.dateRange === 'today' ? styles.activeFilter : {}
              ]}
              onPress={() => setFilters({...filters, dateRange: 'today'})}
            >
              <Text style={[
                styles.filterText,
                filters.dateRange === 'today' ? styles.activeFilterText : {}
              ]}>Today</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.filterOption,
                filters.dateRange === 'week' ? styles.activeFilter : {}
              ]}
              onPress={() => setFilters({...filters, dateRange: 'week'})}
            >
              <Text style={[
                styles.filterText,
                filters.dateRange === 'week' ? styles.activeFilterText : {}
              ]}>Last 7 Days</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.filterOption,
                filters.dateRange === 'month' ? styles.activeFilter : {}
              ]}
              onPress={() => setFilters({...filters, dateRange: 'month'})}
            >
              <Text style={[
                styles.filterText,
                filters.dateRange === 'month' ? styles.activeFilterText : {}
              ]}>Last 30 Days</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>

      {Object.entries(summary).length > 0 && (
        <View style={styles.summaryContainer}>
          <Text style={styles.summaryHeader}>Summary</Text>
          {Object.entries(summary).map(renderSummaryItem)}
        </View>
      )}

      {filteredTransactions.length > 0 ? (
        <FlatList
          data={filteredTransactions}
          renderItem={renderTransactionItem}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.listContainer}
        />
      ) : (
        <View style={styles.emptyState}>
          <Text style={styles.emptyStateText}>
            No transactions found with the current filters
          </Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    padding: 20,
    paddingBottom: 10,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#212529',
  },
  filtersContainer: {
    backgroundColor: '#fff',
    padding: 15,
    margin: 20,
    marginTop: 10,
    marginBottom: 10,
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 2,
  },
  filtersTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#212529',
    marginBottom: 10,
  },
  filterRow: {
    marginBottom: 10,
  },
  filterLabel: {
    fontSize: 14,
    color: '#495057',
    marginBottom: 5,
  },
  filterOptions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  filterOption: {
    backgroundColor: '#e9ecef',
    borderRadius: 16,
    paddingHorizontal: 12,
    paddingVertical: 6,
    marginRight: 8,
    marginBottom: 8,
  },
  activeFilter: {
    backgroundColor: '#2aabf3',
  },
  filterText: {
    fontSize: 12,
    color: '#495057',
  },
  activeFilterText: {
    color: '#fff',
  },
  summaryContainer: {
    padding: 20,
    paddingTop: 0,
    paddingBottom: 10,
  },
  summaryHeader: {
    fontSize: 16,
    fontWeight: '600',
    color: '#212529',
    marginBottom: 10,
  },
  summaryCard: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 2,
  },
  summaryTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#212529',
    marginBottom: 10,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 5,
  },
  summaryLabel: {
    fontSize: 14,
    color: '#495057',
  },
  incomeText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#3eaa65',
  },
  expenseText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#dc3545',
  },
  balanceRow: {
    borderTopWidth: 1,
    borderTopColor: '#e9ecef',
    paddingTop: 10,
    marginTop: 5,
  },
  balanceLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#212529',
  },
  balanceText: {
    fontSize: 14,
    fontWeight: '600',
  },
  positiveBalance: {
    color: '#3eaa65',
  },
  negativeBalance: {
    color: '#dc3545',
  },
  listContainer: {
    padding: 20,
    paddingTop: 0,
  },
  transactionCard: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 2,
  },
  incomeCard: {
    borderLeftWidth: 4,
    borderLeftColor: '#3eaa65',
  },
  transactionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  transactionDescription: {
    fontSize: 16,
    fontWeight: '600',
    color: '#212529',
    flex: 1,
  },
  transactionAmount: {
    fontSize: 16,
    fontWeight: '600',
  },
  incomeAmount: {
    color: '#3eaa65',
  },
  expenseAmount: {
    color: '#dc3545',
  },
  transactionDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  transactionProject: {
    fontSize: 12,
    color: '#2aabf3',
  },
  transactionDate: {
    fontSize: 12,
    color: '#6c757d',
  },
  transactionCategory: {
    fontSize: 12,
    color: '#6c757d',
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  emptyStateText: {
    fontSize: 16,
    color: '#6c757d',
    textAlign: 'center',
  },
});