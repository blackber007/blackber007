import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  FlatList
} from 'react-native';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { format } from 'date-fns';
import { LineChart } from 'react-native-chart-kit';
import { Dimensions } from 'react-native';

const screenWidth = Dimensions.get('window').width;

export default function DashboardScreen({ navigation }: any) {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [projects, setProjects] = useState<any[]>([]);
  const [stats, setStats] = useState({
    activeProjects: 0,
    completedProjects: 0
  });
  const [chartData, setChartData] = useState({
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
    datasets: [
      {
        data: [0, 0, 0, 0, 0, 0],
      }
    ]
  });

  useEffect(() => {
    fetchProjects();
  }, []);

  const fetchProjects = async () => {
    try {
      setLoading(true);
      
      // Get projects where user is the owner
      const { data: ownedProjects, error: ownedError } = await supabase
        .from('projects')
        .select(`
          id,
          name,
          description,
          base_currency,
          created_at,
          owner_id,
          status
        `)
        .eq('owner_id', user?.id);
        
      if (ownedError) throw ownedError;
      
      // Get projects where user is a member
      const { data: memberProjects, error: memberError } = await supabase
        .rpc('get_user_project_memberships', { user_id: user?.id });
        
      if (memberError) throw memberError;
      
      let memberProjectDetails: any[] = [];
      
      if (memberProjects && memberProjects.length > 0) {
        const memberProjectIds = memberProjects.map((mp: any) => mp.project_id);
        
        const { data: projectDetails, error: detailsError } = await supabase
          .from('projects')
          .select(`
            id,
            name,
            description,
            base_currency,
            created_at,
            owner_id,
            status
          `)
          .in('id', memberProjectIds);
          
        if (detailsError) throw detailsError;
        
        memberProjectDetails = projectDetails || [];
      }
      
      // Combine both arrays
      const allProjects = [...(ownedProjects || []), ...memberProjectDetails];
      
      // Sort by created_at desc
      allProjects.sort((a, b) => 
        new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
      );
      
      setProjects(allProjects);
      
      // Calculate stats
      const active = allProjects.filter(p => p.status !== 'completed' && p.status !== 'archived').length;
      const completed = allProjects.filter(p => p.status === 'completed').length;
      
      setStats({
        activeProjects: active,
        completedProjects: completed
      });
      
      // Generate some sample chart data
      if (allProjects.length > 0) {
        // Just create some dummy data for the chart
        setChartData({
          labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
          datasets: [
            {
              data: [
                Math.random() * 100,
                Math.random() * 100,
                Math.random() * 100,
                Math.random() * 100,
                Math.random() * 100,
                Math.random() * 100
              ],
            }
          ]
        });
      }
    } catch (err) {
      console.error('Error fetching projects:', err);
    } finally {
      setLoading(false);
    }
  };

  const renderProjectItem = ({ item }: { item: any }) => (
    <TouchableOpacity 
      style={styles.projectCard}
      onPress={() => navigation.navigate('ProjectDetails', { 
        projectId: item.id,
        projectName: item.name
      })}
    >
      <Text style={styles.projectName}>{item.name}</Text>
      <Text style={styles.projectDescription} numberOfLines={2}>
        {item.description || 'No description'}
      </Text>
      <View style={styles.projectFooter}>
        <Text style={styles.projectDate}>
          Created: {format(new Date(item.created_at), 'MMM d, yyyy')}
        </Text>
        <Text style={styles.projectCurrency}>
          {item.base_currency || 'USD'}
        </Text>
      </View>
    </TouchableOpacity>
  );

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#2aabf3" />
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Dashboard</Text>
      </View>

      <View style={styles.statsContainer}>
        <View style={styles.statCard}>
          <Text style={styles.statValue}>{stats.activeProjects}</Text>
          <Text style={styles.statLabel}>Active Projects</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statValue}>{stats.completedProjects}</Text>
          <Text style={styles.statLabel}>Completed Projects</Text>
        </View>
      </View>

      {projects.length > 0 && (
        <View style={styles.chartContainer}>
          <Text style={styles.sectionTitle}>Financial Overview</Text>
          <LineChart
            data={chartData}
            width={screenWidth - 40}
            height={220}
            chartConfig={{
              backgroundColor: '#ffffff',
              backgroundGradientFrom: '#ffffff',
              backgroundGradientTo: '#ffffff',
              decimalPlaces: 0,
              color: (opacity = 1) => `rgba(42, 171, 243, ${opacity})`,
              labelColor: (opacity = 1) => `rgba(73, 80, 87, ${opacity})`,
              style: {
                borderRadius: 16
              },
              propsForDots: {
                r: '6',
                strokeWidth: '2',
                stroke: '#2aabf3'
              }
            }}
            bezier
            style={{
              marginVertical: 8,
              borderRadius: 16
            }}
          />
        </View>
      )}

      <View style={styles.projectsContainer}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Recent Projects</Text>
          {projects.length > 3 && (
            <TouchableOpacity onPress={() => navigation.navigate('Projects')}>
              <Text style={styles.viewAllText}>View all</Text>
            </TouchableOpacity>
          )}
        </View>

        {projects.length > 0 ? (
          <FlatList
            data={projects.slice(0, 3)}
            renderItem={renderProjectItem}
            keyExtractor={item => item.id}
            scrollEnabled={false}
          />
        ) : (
          <View style={styles.emptyState}>
            <Text style={styles.emptyStateText}>No projects yet</Text>
            <TouchableOpacity 
              style={styles.createButton}
              onPress={() => navigation.navigate('Projects')}
            >
              <Text style={styles.createButtonText}>Create your first project</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    padding: 20,
    paddingBottom: 10,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#212529',
  },
  statsContainer: {
    flexDirection: 'row',
    padding: 20,
    paddingTop: 10,
    paddingBottom: 10,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    marginRight: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 2,
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#2aabf3',
  },
  statLabel: {
    fontSize: 14,
    color: '#495057',
    marginTop: 5,
  },
  chartContainer: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    margin: 20,
    marginTop: 10,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 2,
  },
  projectsContainer: {
    padding: 20,
    paddingTop: 10,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#212529',
  },
  viewAllText: {
    fontSize: 14,
    color: '#2aabf3',
  },
  projectCard: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 2,
  },
  projectName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#2aabf3',
    marginBottom: 5,
  },
  projectDescription: {
    fontSize: 14,
    color: '#495057',
    marginBottom: 10,
  },
  projectFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  projectDate: {
    fontSize: 12,
    color: '#6c757d',
  },
  projectCurrency: {
    fontSize: 12,
    color: '#6c757d',
  },
  emptyState: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 20,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 2,
  },
  emptyStateText: {
    fontSize: 16,
    color: '#6c757d',
    marginBottom: 15,
  },
  createButton: {
    backgroundColor: '#2aabf3',
    borderRadius: 8,
    padding: 12,
  },
  createButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
});