import { createClient } from '@supabase/supabase-js';
import AsyncStorage from '@react-native-async-storage/async-storage';
import 'react-native-url-polyfill/auto';

// Replace with your Supabase URL and anon key
const supabaseUrl = 'https://xmordbjpdmzpntyzbkxc.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inhtb3JkYmpwZG16cG50eXpia3hjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDA4NTE2OTksImV4cCI6MjA1NjQyNzY5OX0.y4BQNQUDJ9y9fj8ZC1Vp6awRm2MMstoW1t3o8puAMfw';

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    storage: AsyncStorage,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});