# Project Finance Tracker - Android App

This is the Android version of the Project Finance Tracker application. It allows you to track project finances across multiple currencies and team members.

## Features

- Track project finances
- Multiple currency support
- Team member management
- Expense categorization
- Financial reporting
- Internationalization support

## Getting Started

### Prerequisites

- Node.js
- Expo CLI
- Android Studio (for Android emulator) or a physical Android device

### Installation

1. Clone this repository
2. Install dependencies:
   ```
   cd ProjectFinanceTrackerApp
   npm install
   ```
3. Start the Expo development server:
   ```
   npm start
   ```
4. Run the app on an Android device or emulator:
   - Scan the QR code with the Expo Go app on your Android device
   - Press 'a' in the terminal to open in an Android emulator

## Building for Production

To create a standalone Android APK:

1. Install EAS CLI:
   ```
   npm install -g eas-cli
   ```

2. Build the app:
   ```
   eas build -p android
   ```

3. Follow the prompts to complete the build process

## Project Structure

- `/src` - Source code
  - `/components` - Reusable UI components
  - `/screens` - App screens
  - `/navigation` - Navigation configuration
  - `/contexts` - React contexts for state management
  - `/lib` - Utility functions and API clients
  - `/i18n` - Internationalization files

## Connecting to Supabase

The app uses Supabase for backend services. The Supabase URL and anon key are already configured in the app.

## License

This project is licensed under the MIT License.