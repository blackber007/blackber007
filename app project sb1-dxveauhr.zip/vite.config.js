import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [
    react()
  ],
  server: {
    host: true,
    hmr: {
      // Use HTTP protocol for HMR instead of WebSocket to prevent connection issues
      protocol: 'http',
      host: 'localhost',
      clientPort: 5173
    }
  }
})