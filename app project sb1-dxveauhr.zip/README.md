# FINNIF05 - Project Finance Tracker

A comprehensive finance tracking application for managing project finances across multiple currencies and team members.

## Features

- Track project finances
- Multiple currency support
- Team member management
- Expense categorization
- Financial reporting
- Internationalization support (8 languages)
- Web and Android versions

## Web Application

The web application is built with React and uses Supabase for backend services.

### Getting Started

1. Clone this repository
2. Install dependencies:
   ```
   npm install
   ```
3. Start the development server:
   ```
   npm run dev
   ```

## Android Application

The Android application is built with React Native and Expo, and uses the same Supabase backend.

### Getting Started

1. Initialize the Android app (only needed once):
   ```
   npm run android:init
   ```

2. Navigate to the Android app directory and install dependencies:
   ```
   cd ProjectFinanceTrackerApp
   npm install
   ```

3. Start the Expo development server:
   ```
   npm start
   ```

4. Run the app on an Android device or emulator:
   - Scan the QR code with the Expo Go app on your Android device
   - Press 'a' in the terminal to open in an Android emulator

### Building for Production

To create a standalone Android APK:

1. Install EAS CLI:
   ```
   npm install -g eas-cli
   ```

2. Build the app:
   ```
   eas build -p android
   ```

3. Follow the prompts to complete the build process

## Project Structure

- `/src` - Web application source code
- `/ProjectFinanceTrackerApp` - Android application source code
- `/supabase` - Supabase migrations and configuration

## License

This project is licensed under the MIT License.