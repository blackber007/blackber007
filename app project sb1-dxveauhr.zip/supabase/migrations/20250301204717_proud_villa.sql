-- Add bank_accounts table to track different banks and their fees
CREATE TABLE IF NOT EXISTS bank_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  account_number text,
  bank_name text NOT NULL,
  withdrawal_fee numeric(15, 2) DEFAULT 0,
  transfer_fee numeric(15, 2) DEFAULT 0,
  currency text NOT NULL DEFAULT 'USD',
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE bank_accounts ENABLE ROW LEVEL SECURITY;

-- Create policies for bank_accounts
CREATE POLICY "admins_can_manage_bank_accounts"
ON bank_accounts
FOR ALL
USING (
  EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.is_admin = true
  )
);

CREATE POLICY "project_leaders_can_view_bank_accounts"
ON bank_accounts
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM project_members
    WHERE project_members.user_id = auth.uid()
    AND project_members.role = 'project_leader'
  )
);

CREATE POLICY "members_can_view_bank_accounts"
ON bank_accounts
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM project_members
    WHERE project_members.user_id = auth.uid()
  )
);

-- Add finance_controller role to project_members
DO $$
BEGIN
  -- Ensure the role column has the correct constraint
  ALTER TABLE project_members DROP CONSTRAINT IF EXISTS project_members_role_check;
  ALTER TABLE project_members ADD CONSTRAINT project_members_role_check 
    CHECK (role IN ('admin', 'member', 'project_leader', 'finance_controller'));
END $$;

-- Add bank_account_id to transactions table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'transactions' AND column_name = 'bank_account_id'
  ) THEN
    ALTER TABLE transactions ADD COLUMN bank_account_id uuid REFERENCES bank_accounts(id);
  END IF;
END $$;

-- Add bank_fee column to transactions table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'transactions' AND column_name = 'bank_fee'
  ) THEN
    ALTER TABLE transactions ADD COLUMN bank_fee numeric(15, 2) DEFAULT 0;
  END IF;
END $$;

-- Add is_withdrawal column to transactions table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'transactions' AND column_name = 'is_withdrawal'
  ) THEN
    ALTER TABLE transactions ADD COLUMN is_withdrawal boolean DEFAULT false;
  END IF;
END $$;

-- Add expense category for bank fees if it doesn't exist
DO $$
DECLARE
  project_ids uuid[];
  project_id uuid;
BEGIN
  -- Get all project IDs
  SELECT array_agg(id) INTO project_ids FROM projects;
  
  -- For each project, create a bank fee category if it doesn't exist
  IF project_ids IS NOT NULL THEN
    FOREACH project_id IN ARRAY project_ids
    LOOP
      IF NOT EXISTS (
        SELECT 1 FROM expense_categories 
        WHERE project_id = project_id AND name = 'Bank Fees'
      ) THEN
        INSERT INTO expense_categories (project_id, name, description)
        VALUES (project_id, 'Bank Fees', 'Fees charged by banks for withdrawals and transfers');
      END IF;
    END LOOP;
  END IF;
END $$;