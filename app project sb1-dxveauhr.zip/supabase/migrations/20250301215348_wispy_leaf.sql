/*
  # Admin-only project creation

  1. Changes
     - Modify the projects_insert_policy to only allow administrators to create new projects
     - Add a new column to profiles table to track if a user is an admin (if not already exists)
     - Set the first user as an admin if no admins exist

  2. Security
     - Restricts project creation to admin users only
     - Maintains existing security policies for other operations
*/

-- First check if the policy exists and drop it
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'projects' AND policyname = 'projects_insert_policy'
  ) THEN
    DROP POLICY "projects_insert_policy" ON projects;
  END IF;
  
  IF EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'projects' AND policyname = 'Authenticated users can create projects'
  ) THEN
    DROP POLICY "Authenticated users can create projects" ON projects;
  END IF;
END $$;

-- Create new admin-only project creation policy
CREATE POLICY "admin_only_project_creation"
  ON projects
  FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.is_admin = true
    )
  );

-- Ensure is_admin column exists in profiles table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'is_admin'
  ) THEN
    ALTER TABLE profiles ADD COLUMN is_admin boolean NOT NULL DEFAULT false;
    
    -- Add an index on the is_admin column
    CREATE INDEX IF NOT EXISTS idx_profiles_is_admin ON profiles(is_admin);
  END IF;
END $$;

-- Set first user as admin if no admins exist
DO $$
DECLARE
  first_user_id uuid;
  admin_count integer;
BEGIN
  -- Check if there are already admin users
  SELECT COUNT(*) INTO admin_count FROM profiles WHERE is_admin = true;
  
  -- Only set an admin if there are none
  IF admin_count = 0 THEN
    -- Get the first user in the system to make them an admin
    SELECT id INTO first_user_id FROM profiles LIMIT 1;
    
    IF first_user_id IS NOT NULL THEN
      UPDATE profiles SET is_admin = true WHERE id = first_user_id;
    END IF;
  END IF;
END $$;