-- Fix project_leader role and permissions
DO $$
BEGIN
  -- Ensure project_members role constraint is correct
  ALTER TABLE project_members DROP CONSTRAINT IF EXISTS project_members_role_check;
  ALTER TABLE project_members ADD CONSTRAINT project_members_role_check 
    CHECK (role IN ('admin', 'member', 'project_leader'));

  -- Drop existing policies to avoid conflicts
  DROP POLICY IF EXISTS "project_leaders_can_manage_categories" ON expense_categories;
  DROP POLICY IF EXISTS "project_leaders_can_manage_transactions" ON transactions;
  DROP POLICY IF EXISTS "project_leaders_can_view_members" ON project_members;

  -- Create new policies for project leaders
  CREATE POLICY "project_leaders_can_manage_categories"
  ON expense_categories
  FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM project_members
      WHERE project_members.project_id = expense_categories.project_id
      AND project_members.user_id = auth.uid()
      AND project_members.role IN ('project_leader', 'admin')
    )
  );

  CREATE POLICY "project_leaders_can_manage_transactions"
  ON transactions
  FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM project_members
      WHERE project_members.project_id = transactions.project_id
      AND project_members.user_id = auth.uid()
      AND project_members.role IN ('project_leader', 'admin')
    )
  );

  CREATE POLICY "project_leaders_can_view_members"
  ON project_members
  FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM project_members pm
      WHERE pm.project_id = project_members.project_id
      AND pm.user_id = auth.uid()
      AND pm.role IN ('project_leader', 'admin')
    )
  );
END $$;

-- Add function to check if user is project leader
CREATE OR REPLACE FUNCTION is_project_leader(project_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM project_members
    WHERE project_members.project_id = $1
    AND project_members.user_id = auth.uid()
    AND project_members.role IN ('project_leader', 'admin')
  );
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION is_project_leader TO authenticated;