-- This migration fixes the issue with the translations table and policies

-- Check if the policy already exists and drop it if it does
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'translations' AND policyname = 'Anyone can read translations'
  ) THEN
    DROP POLICY "Anyone can read translations" ON translations;
  END IF;
END $$;

-- Create the policy again
CREATE POLICY "Anyone can read translations"
  ON translations
  FOR SELECT
  USING (true);

-- Set first admin user if not already done
DO $$
DECLARE
  first_user_id uuid;
  admin_count integer;
BEGIN
  -- Check if there are already admin users
  SELECT COUNT(*) INTO admin_count FROM profiles WHERE is_admin = true;
  
  -- Only set an admin if there are none
  IF admin_count = 0 THEN
    -- Get the first user in the system to make them an admin
    SELECT id INTO first_user_id FROM profiles LIMIT 1;
    
    IF first_user_id IS NOT NULL THEN
      -- Check if is_admin column exists before updating
      IF EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'profiles' AND column_name = 'is_admin'
      ) THEN
        UPDATE profiles SET is_admin = true WHERE id = first_user_id;
      END IF;
    END IF;
  END IF;
END $$;