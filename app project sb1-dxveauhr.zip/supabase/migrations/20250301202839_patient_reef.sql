-- Add project parts functionality
DO $$
BEGIN
  -- Add total_parts and available_parts columns to projects table
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'projects' AND column_name = 'total_parts'
  ) THEN
    ALTER TABLE projects ADD COLUMN total_parts integer NOT NULL DEFAULT 100;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'projects' AND column_name = 'available_parts'
  ) THEN
    ALTER TABLE projects ADD COLUMN available_parts integer NOT NULL DEFAULT 100;
  END IF;
  
  -- Add is_project_leader column to project_members table
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'project_members' AND column_name = 'is_project_leader'
  ) THEN
    ALTER TABLE project_members ADD COLUMN is_project_leader boolean NOT NULL DEFAULT false;
  END IF;
  
  -- Add allocated_parts column to project_members table
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'project_members' AND column_name = 'allocated_parts'
  ) THEN
    ALTER TABLE project_members ADD COLUMN allocated_parts integer NOT NULL DEFAULT 0;
  END IF;
  
  -- Add requested_parts column to project_members table
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'project_members' AND column_name = 'requested_parts'
  ) THEN
    ALTER TABLE project_members ADD COLUMN requested_parts integer NOT NULL DEFAULT 0;
  END IF;
END $$;