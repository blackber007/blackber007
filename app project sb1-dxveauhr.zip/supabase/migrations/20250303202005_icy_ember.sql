-- Add location column to profiles table if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'location'
  ) THEN
    ALTER TABLE profiles ADD COLUMN location text;
  END IF;
END $$;

-- Add payment_status table to track user payments for projects
CREATE TABLE IF NOT EXISTS payment_status (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid REFERENCES projects(id) ON DELETE CASCADE NOT NULL,
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  amount_paid numeric(15, 2) DEFAULT 0,
  amount_expected numeric(15, 2) DEFAULT 0,
  is_paid_full boolean DEFAULT false,
  last_updated timestamptz DEFAULT now(),
  UNIQUE(project_id, user_id)
);

-- Enable Row Level Security
ALTER TABLE payment_status ENABLE ROW LEVEL SECURITY;

-- Create policies for payment_status
CREATE POLICY "Users can view their own payment status"
  ON payment_status
  FOR SELECT
  USING (user_id = auth.uid());

CREATE POLICY "Project admins can manage payment status"
  ON payment_status
  FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM project_members
      WHERE project_members.project_id = payment_status.project_id
      AND project_members.user_id = auth.uid()
      AND project_members.role = 'admin'
    )
  );

-- Add project_rentability table to track project profitability
CREATE TABLE IF NOT EXISTS project_rentability (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid REFERENCES projects(id) ON DELETE CASCADE NOT NULL,
  total_income numeric(15, 2) DEFAULT 0,
  total_expense numeric(15, 2) DEFAULT 0,
  rentability_percentage numeric(15, 2) DEFAULT 0,
  last_calculated timestamptz DEFAULT now(),
  UNIQUE(project_id)
);

-- Enable Row Level Security
ALTER TABLE project_rentability ENABLE ROW LEVEL SECURITY;

-- Create policies for project_rentability
CREATE POLICY "Project members can view rentability"
  ON project_rentability
  FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM project_members
      WHERE project_members.project_id = project_rentability.project_id
      AND project_members.user_id = auth.uid()
    )
  );

CREATE POLICY "Project admins can manage rentability"
  ON project_rentability
  FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM project_members
      WHERE project_members.project_id = project_rentability.project_id
      AND project_members.user_id = auth.uid()
      AND project_members.role = 'admin'
    )
  );

-- Create function to update payment status and rentability after transaction
CREATE OR REPLACE FUNCTION update_payment_and_rentability()
RETURNS TRIGGER AS $$
BEGIN
  -- Update project rentability
  INSERT INTO project_rentability (
    project_id, 
    total_income, 
    total_expense, 
    rentability_percentage, 
    last_calculated
  )
  SELECT 
    NEW.project_id,
    COALESCE(SUM(CASE WHEN type = 'income' THEN amount ELSE 0 END), 0) as total_income,
    COALESCE(SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END), 0) as total_expense,
    CASE 
      WHEN COALESCE(SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END), 0) > 0 
      THEN (COALESCE(SUM(CASE WHEN type = 'income' THEN amount ELSE 0 END), 0) - 
            COALESCE(SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END), 0)) / 
           COALESCE(SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END), 0) * 100
      ELSE 0
    END as rentability_percentage,
    NOW()
  FROM transactions
  WHERE project_id = NEW.project_id
  GROUP BY project_id
  ON CONFLICT (project_id) 
  DO UPDATE SET
    total_income = EXCLUDED.total_income,
    total_expense = EXCLUDED.total_expense,
    rentability_percentage = EXCLUDED.rentability_percentage,
    last_calculated = NOW();
    
  -- Update user payment status
  -- First, calculate total expected contribution per user (equal split of expenses)
  WITH project_expenses AS (
    SELECT 
      project_id,
      COALESCE(SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END), 0) as total_expense
    FROM transactions
    WHERE project_id = NEW.project_id
    GROUP BY project_id
  ),
  project_members_count AS (
    SELECT 
      project_id,
      COUNT(*) as member_count
    FROM project_members
    WHERE project_id = NEW.project_id
    GROUP BY project_id
  ),
  user_expenses AS (
    SELECT 
      t.project_id,
      t.user_id,
      COALESCE(SUM(CASE WHEN t.type = 'expense' THEN t.amount ELSE 0 END), 0) as paid_amount
    FROM transactions t
    WHERE t.project_id = NEW.project_id
    GROUP BY t.project_id, t.user_id
  )
  INSERT INTO payment_status (
    project_id,
    user_id,
    amount_paid,
    amount_expected,
    is_paid_full,
    last_updated
  )
  SELECT 
    pm.project_id,
    pm.user_id,
    COALESCE(ue.paid_amount, 0) as amount_paid,
    CASE 
      WHEN pmc.member_count > 0 
      THEN pe.total_expense / pmc.member_count
      ELSE 0
    END as amount_expected,
    COALESCE(ue.paid_amount, 0) >= 
      CASE 
        WHEN pmc.member_count > 0 
        THEN pe.total_expense / pmc.member_count
        ELSE 0
      END as is_paid_full,
    NOW()
  FROM project_members pm
  JOIN project_expenses pe ON pm.project_id = pe.project_id
  JOIN project_members_count pmc ON pm.project_id = pmc.project_id
  LEFT JOIN user_expenses ue ON pm.project_id = ue.project_id AND pm.user_id = ue.user_id
  WHERE pm.project_id = NEW.project_id
  ON CONFLICT (project_id, user_id) 
  DO UPDATE SET
    amount_paid = EXCLUDED.amount_paid,
    amount_expected = EXCLUDED.amount_expected,
    is_paid_full = EXCLUDED.is_paid_full,
    last_updated = NOW();
    
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to update payment status and rentability after transaction
DROP TRIGGER IF EXISTS update_payment_and_rentability_trigger ON transactions;

CREATE TRIGGER update_payment_and_rentability_trigger
AFTER INSERT OR UPDATE ON transactions
FOR EACH ROW
EXECUTE FUNCTION update_payment_and_rentability();