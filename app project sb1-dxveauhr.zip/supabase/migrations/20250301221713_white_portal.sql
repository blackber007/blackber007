/*
  # Create RPC function for project memberships

  1. Changes
     - Add a database function to safely get user project memberships
     - Avoid recursive policies by using direct SQL

  2. Security
     - Function uses SECURITY DEFINER to bypass RLS
     - Results are filtered to only return the user's own memberships
*/

-- Create a function to get user project memberships without triggering recursion
CREATE OR REPLACE FUNCTION get_user_project_memberships(user_id uuid)
RETURNS TABLE (
  project_id uuid,
  role text
) 
LANGUAGE sql
SECURITY DEFINER
AS $$
  SELECT project_id, role
  FROM project_members
  WHERE user_id = get_user_project_memberships.user_id;
$$;

-- Grant execute permission to the anon and authenticated roles
GRANT EXECUTE ON FUNCTION get_user_project_memberships TO anon, authenticated;