/*
  # Final fix for infinite recursion in RLS policies

  1. Changes
    - Drop all previous policies that might be causing recursion
    - Implement clean, non-recursive policies for all tables
    - Fix circular references between policies
  
  2. Security
    - Maintain same security model but eliminate recursion
    - Ensure all tables still have proper RLS protection
*/

-- First, check if policies exist before dropping them to avoid errors
DO $$
BEGIN
    -- Drop projects policies if they exist
    IF EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'Users can view projects they are members of' AND tablename = 'projects') THEN
        DROP POLICY "Users can view projects they are members of" ON projects;
    END IF;
    
    IF EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'users_can_view_their_projects' AND tablename = 'projects') THEN
        DROP POLICY "users_can_view_their_projects" ON projects;
    END IF;
    
    IF EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'projects_view_policy' AND tablename = 'projects') THEN
        DROP POLICY "projects_view_policy" ON projects;
    END IF;
    
    IF EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'Project owners can update their projects' AND tablename = 'projects') THEN
        DROP POLICY "Project owners can update their projects" ON projects;
    END IF;
    
    IF EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'Project owners can delete their projects' AND tablename = 'projects') THEN
        DROP POLICY "Project owners can delete their projects" ON projects;
    END IF;
    
    IF EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'Authenticated users can create projects' AND tablename = 'projects') THEN
        DROP POLICY "Authenticated users can create projects" ON projects;
    END IF;
    
    -- Drop project_members policies if they exist
    IF EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'select_project_members' AND tablename = 'project_members') THEN
        DROP POLICY "select_project_members" ON project_members;
    END IF;
    
    IF EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'members_can_view_project_members' AND tablename = 'project_members') THEN
        DROP POLICY "members_can_view_project_members" ON project_members;
    END IF;
    
    IF EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'Users can view members of projects they belong to' AND tablename = 'project_members') THEN
        DROP POLICY "Users can view members of projects they belong to" ON project_members;
    END IF;
    
    IF EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'project_members_view_policy' AND tablename = 'project_members') THEN
        DROP POLICY "project_members_view_policy" ON project_members;
    END IF;
    
    IF EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'Project admins can manage members' AND tablename = 'project_members') THEN
        DROP POLICY "Project admins can manage members" ON project_members;
    END IF;
    
    -- Drop expense_categories policies if they exist
    IF EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'select_expense_categories' AND tablename = 'expense_categories') THEN
        DROP POLICY "select_expense_categories" ON expense_categories;
    END IF;
    
    IF EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'members_can_view_expense_categories' AND tablename = 'expense_categories') THEN
        DROP POLICY "members_can_view_expense_categories" ON expense_categories;
    END IF;
    
    IF EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'Users can view categories of projects they belong to' AND tablename = 'expense_categories') THEN
        DROP POLICY "Users can view categories of projects they belong to" ON expense_categories;
    END IF;
    
    IF EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'expense_categories_view_policy' AND tablename = 'expense_categories') THEN
        DROP POLICY "expense_categories_view_policy" ON expense_categories;
    END IF;
    
    IF EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'Project admins can manage categories' AND tablename = 'expense_categories') THEN
        DROP POLICY "Project admins can manage categories" ON expense_categories;
    END IF;
    
    -- Drop transactions policies if they exist
    IF EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'select_transactions' AND tablename = 'transactions') THEN
        DROP POLICY "select_transactions" ON transactions;
    END IF;
    
    IF EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'members_can_view_transactions' AND tablename = 'transactions') THEN
        DROP POLICY "members_can_view_transactions" ON transactions;
    END IF;
    
    IF EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'Users can view transactions of projects they belong to' AND tablename = 'transactions') THEN
        DROP POLICY "Users can view transactions of projects they belong to" ON transactions;
    END IF;
    
    IF EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'transactions_view_policy' AND tablename = 'transactions') THEN
        DROP POLICY "transactions_view_policy" ON transactions;
    END IF;
    
    IF EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'Project members can add transactions' AND tablename = 'transactions') THEN
        DROP POLICY "Project members can add transactions" ON transactions;
    END IF;
    
    IF EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'Users can update their own transactions' AND tablename = 'transactions') THEN
        DROP POLICY "Users can update their own transactions" ON transactions;
    END IF;
    
    IF EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'Project admins can update any transaction' AND tablename = 'transactions') THEN
        DROP POLICY "Project admins can update any transaction" ON transactions;
    END IF;
    
    IF EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'Project admins can delete any transaction' AND tablename = 'transactions') THEN
        DROP POLICY "Project admins can delete any transaction" ON transactions;
    END IF;
END $$;

-- Create new non-recursive policies with optimized queries

-- Projects policy - fundamental policy that others depend on
CREATE POLICY "projects_view_policy" 
ON projects
FOR SELECT
USING (
  -- User is the owner of the project (direct ownership)
  owner_id = auth.uid()
  OR
  -- User is a member of the project (direct membership check without recursion)
  id IN (
    SELECT project_id 
    FROM project_members
    WHERE user_id = auth.uid()
  )
);

-- Project members policy
CREATE POLICY "project_members_view_policy"
ON project_members
FOR SELECT
USING (
  -- User is a member of this project
  user_id = auth.uid()
  OR
  -- User is the owner of the project
  project_id IN (
    SELECT id
    FROM projects
    WHERE owner_id = auth.uid()
  )
);

-- Expense categories policy
CREATE POLICY "expense_categories_view_policy"
ON expense_categories
FOR SELECT
USING (
  -- User is the owner of the project
  project_id IN (
    SELECT id
    FROM projects
    WHERE owner_id = auth.uid()
  )
  OR
  -- User is a member of this project
  project_id IN (
    SELECT project_id
    FROM project_members
    WHERE user_id = auth.uid()
  )
);

-- Transactions policy
CREATE POLICY "transactions_view_policy"
ON transactions
FOR SELECT
USING (
  -- User created the transaction
  user_id = auth.uid()
  OR
  -- User is the owner of the project
  project_id IN (
    SELECT id
    FROM projects
    WHERE owner_id = auth.uid()
  )
  OR
  -- User is a member of this project
  project_id IN (
    SELECT project_id
    FROM project_members
    WHERE user_id = auth.uid()
  )
);

-- Recreate other necessary policies for INSERT, UPDATE, DELETE operations

-- Projects policies
CREATE POLICY "projects_update_policy"
  ON projects
  FOR UPDATE
  USING (owner_id = auth.uid());

CREATE POLICY "projects_delete_policy"
  ON projects
  FOR DELETE
  USING (owner_id = auth.uid());

CREATE POLICY "projects_insert_policy"
  ON projects
  FOR INSERT
  WITH CHECK (auth.uid() = owner_id);

-- Project members policies
CREATE POLICY "project_members_all_policy"
  ON project_members
  FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM project_members
      WHERE project_members.project_id = project_id
      AND project_members.user_id = auth.uid()
      AND project_members.role = 'admin'
    )
  );

-- Expense categories policies
CREATE POLICY "expense_categories_all_policy"
  ON expense_categories
  FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM project_members
      WHERE project_members.project_id = project_id
      AND project_members.user_id = auth.uid()
      AND project_members.role = 'admin'
    )
  );

-- Transactions policies
CREATE POLICY "transactions_insert_policy"
  ON transactions
  FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM project_members
      WHERE project_members.project_id = project_id
      AND project_members.user_id = auth.uid()
    )
  );

CREATE POLICY "transactions_update_own_policy"
  ON transactions
  FOR UPDATE
  USING (user_id = auth.uid());

CREATE POLICY "transactions_update_admin_policy"
  ON transactions
  FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM project_members
      WHERE project_members.project_id = project_id
      AND project_members.user_id = auth.uid()
      AND project_members.role = 'admin'
    )
  );

CREATE POLICY "transactions_delete_policy"
  ON transactions
  FOR DELETE
  USING (
    EXISTS (
      SELECT 1 FROM project_members
      WHERE project_members.project_id = project_id
      AND project_members.user_id = auth.uid()
      AND project_members.role = 'admin'
    )
  );