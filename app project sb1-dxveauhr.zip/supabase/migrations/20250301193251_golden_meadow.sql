/*
  # Fix infinite recursion in RLS policies

  1. Changes
    - Replace recursive policy for projects table
    - Fix circular references in RLS policies
    - Implement more efficient policy patterns
  
  2. Security
    - Maintain same security model but eliminate recursion
    - Ensure all tables still have proper RLS protection
*/

-- Fix the infinite recursion in projects policy
DROP POLICY IF EXISTS "Users can view projects they are members of" ON projects;

CREATE POLICY "users_can_view_their_projects" 
ON projects
FOR SELECT
USING (
  -- User is the owner of the project
  owner_id = auth.uid()
  OR
  -- User is a member of the project (direct check without recursion)
  EXISTS (
    SELECT 1 
    FROM project_members
    WHERE project_members.project_id = id
    AND project_members.user_id = auth.uid()
  )
);

-- Fix project_members policy to avoid circular references
DROP POLICY IF EXISTS "select_project_members" ON project_members;

CREATE POLICY "members_can_view_project_members"
ON project_members
FOR SELECT
USING (
  -- User is the owner of the project
  EXISTS (
    SELECT 1
    FROM projects
    WHERE projects.id = project_members.project_id
    AND projects.owner_id = auth.uid()
  )
  OR
  -- User is a member of this project
  user_id = auth.uid()
);

-- Fix expense_categories policy
DROP POLICY IF EXISTS "select_expense_categories" ON expense_categories;

CREATE POLICY "members_can_view_expense_categories"
ON expense_categories
FOR SELECT
USING (
  -- User is the owner of the project
  EXISTS (
    SELECT 1
    FROM projects
    WHERE projects.id = expense_categories.project_id
    AND projects.owner_id = auth.uid()
  )
  OR
  -- User is a member of this project
  EXISTS (
    SELECT 1
    FROM project_members
    WHERE project_members.project_id = expense_categories.project_id
    AND project_members.user_id = auth.uid()
  )
);

-- Fix transactions policy
DROP POLICY IF EXISTS "select_transactions" ON transactions;

CREATE POLICY "members_can_view_transactions"
ON transactions
FOR SELECT
USING (
  -- User is the owner of the project
  EXISTS (
    SELECT 1
    FROM projects
    WHERE projects.id = transactions.project_id
    AND projects.owner_id = auth.uid()
  )
  OR
  -- User is a member of this project
  EXISTS (
    SELECT 1
    FROM project_members
    WHERE project_members.project_id = transactions.project_id
    AND project_members.user_id = auth.uid()
  )
  OR
  -- User created the transaction
  user_id = auth.uid()
);