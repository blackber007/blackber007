/*
  # Simplify database schema by removing bank-related features

  1. Changes
     - Remove bank_accounts table and related columns
     - Simplify project_members roles
     - Remove bank fee categories
     - Update transaction policies

  2. Security
     - Make transaction management admin-only
*/

-- First drop any foreign key constraints that reference bank_accounts
DO $$
BEGIN
  -- Check if the foreign key constraint exists and drop it
  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_name = 'transactions_bank_account_id_fkey'
    AND table_name = 'transactions'
  ) THEN
    ALTER TABLE transactions DROP CONSTRAINT transactions_bank_account_id_fkey;
  END IF;
END $$;

-- Now we can safely drop the bank_accounts table
DROP TABLE IF EXISTS bank_accounts CASCADE;

-- Remove bank-related columns from transactions
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'transactions' AND column_name = 'bank_account_id'
  ) THEN
    ALTER TABLE transactions DROP COLUMN bank_account_id;
  END IF;
  
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'transactions' AND column_name = 'is_withdrawal'
  ) THEN
    ALTER TABLE transactions DROP COLUMN is_withdrawal;
  END IF;
  
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'transactions' AND column_name = 'bank_fee'
  ) THEN
    ALTER TABLE transactions DROP COLUMN bank_fee;
  END IF;
END $$;

-- Simplify project_members roles
DO $$
BEGIN
  -- Ensure the role column has the correct constraint
  ALTER TABLE project_members DROP CONSTRAINT IF EXISTS project_members_role_check;
  ALTER TABLE project_members ADD CONSTRAINT project_members_role_check 
    CHECK (role IN ('admin', 'member'));
    
  -- Update any existing roles to either admin or member
  UPDATE project_members 
  SET role = 'member' 
  WHERE role NOT IN ('admin', 'member');
END $$;

-- Remove bank fee categories
DO $$
BEGIN
  DELETE FROM expense_categories WHERE name = 'Bank Fees';
END $$;

-- Update transaction policies to make certain functions admin-only
DO $$
BEGIN
  -- Drop existing policies
  DROP POLICY IF EXISTS "Project members can add transactions" ON transactions;
  DROP POLICY IF EXISTS "Users can update their own transactions" ON transactions;
  DROP POLICY IF EXISTS "Project admins can update any transaction" ON transactions;
  DROP POLICY IF EXISTS "Project admins can delete any transaction" ON transactions;
  DROP POLICY IF EXISTS "finance_controllers_can_manage_transactions" ON transactions;
  
  -- Check if policies already exist before creating them
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'transactions' AND policyname = 'admins_can_add_transactions'
  ) THEN
    CREATE POLICY "admins_can_add_transactions"
    ON transactions
    FOR INSERT
    WITH CHECK (
      EXISTS (
        SELECT 1 FROM project_members
        WHERE project_members.project_id = project_id
        AND project_members.user_id = auth.uid()
        AND project_members.role = 'admin'
      )
    );
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'transactions' AND policyname = 'admins_can_update_transactions'
  ) THEN
    CREATE POLICY "admins_can_update_transactions"
    ON transactions
    FOR UPDATE
    USING (
      EXISTS (
        SELECT 1 FROM project_members
        WHERE project_members.project_id = project_id
        AND project_members.user_id = auth.uid()
        AND project_members.role = 'admin'
      )
    );
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'transactions' AND policyname = 'admins_can_delete_transactions'
  ) THEN
    CREATE POLICY "admins_can_delete_transactions"
    ON transactions
    FOR DELETE
    USING (
      EXISTS (
        SELECT 1 FROM project_members
        WHERE project_members.project_id = project_id
        AND project_members.user_id = auth.uid()
        AND project_members.role = 'admin'
      )
    );
  END IF;
END $$;