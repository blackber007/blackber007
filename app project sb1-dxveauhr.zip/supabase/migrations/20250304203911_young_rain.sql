-- Add project_leader role to project_members
DO $$
BEGIN
  -- Ensure the role column has the correct constraint
  ALTER TABLE project_members DROP CONSTRAINT IF EXISTS project_members_role_check;
  ALTER TABLE project_members ADD CONSTRAINT project_members_role_check 
    CHECK (role IN ('admin', 'member', 'project_leader'));
END $$;

-- Add notes/comments column to expense_categories if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'expense_categories' AND column_name = 'notes'
  ) THEN
    ALTER TABLE expense_categories ADD COLUMN notes text;
  END IF;
END $$;

-- Add order_index column to expense_categories if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'expense_categories' AND column_name = 'order_index'
  ) THEN
    ALTER TABLE expense_categories ADD COLUMN order_index integer DEFAULT 0;
    
    -- Create index for faster ordering
    CREATE INDEX idx_expense_categories_order ON expense_categories(project_id, order_index);
  END IF;
END $$;

-- Create policy for project leaders to manage categories
CREATE POLICY "project_leaders_can_manage_categories"
ON expense_categories
FOR ALL
USING (
  EXISTS (
    SELECT 1 FROM project_members
    WHERE project_members.project_id = expense_categories.project_id
    AND project_members.user_id = auth.uid()
    AND project_members.role = 'project_leader'
  )
);

-- Update transactions policy to allow project leaders to manage transactions
CREATE POLICY "project_leaders_can_manage_transactions"
ON transactions
FOR ALL
USING (
  EXISTS (
    SELECT 1 FROM project_members
    WHERE project_members.project_id = transactions.project_id
    AND project_members.user_id = auth.uid()
    AND project_members.role = 'project_leader'
  )
);