/*
  # Fix infinite recursion in RLS policies

  1. Changes
    - Replace recursive policy for projects table
    - Fix circular references in RLS policies
    - Implement more efficient policy patterns
  
  2. Security
    - Maintain same security model but eliminate recursion
    - Ensure all tables still have proper RLS protection
*/

-- Drop all potentially recursive policies first
DROP POLICY IF EXISTS "Users can view projects they are members of" ON projects;
DROP POLICY IF EXISTS "users_can_view_their_projects" ON projects;
DROP POLICY IF EXISTS "select_project_members" ON project_members;
DROP POLICY IF EXISTS "members_can_view_project_members" ON project_members;
DROP POLICY IF EXISTS "Users can view members of projects they belong to" ON project_members;
DROP POLICY IF EXISTS "select_expense_categories" ON expense_categories;
DROP POLICY IF EXISTS "members_can_view_expense_categories" ON expense_categories;
DROP POLICY IF EXISTS "Users can view categories of projects they belong to" ON expense_categories;
DROP POLICY IF EXISTS "select_transactions" ON transactions;
DROP POLICY IF EXISTS "members_can_view_transactions" ON transactions;
DROP POLICY IF EXISTS "Users can view transactions of projects they belong to" ON transactions;

-- Create new non-recursive policies

-- Projects policy - fundamental policy that others depend on
CREATE POLICY "projects_view_policy" 
ON projects
FOR SELECT
USING (
  -- User is the owner of the project (direct ownership)
  owner_id = auth.uid()
  OR
  -- User is a member of the project (direct membership check)
  EXISTS (
    SELECT 1 
    FROM project_members
    WHERE project_members.project_id = id
    AND project_members.user_id = auth.uid()
  )
);

-- Project members policy
CREATE POLICY "project_members_view_policy"
ON project_members
FOR SELECT
USING (
  -- User is a member of this project
  user_id = auth.uid()
  OR
  -- User is the owner of the project
  EXISTS (
    SELECT 1
    FROM projects
    WHERE projects.id = project_members.project_id
    AND projects.owner_id = auth.uid()
  )
);

-- Expense categories policy
CREATE POLICY "expense_categories_view_policy"
ON expense_categories
FOR SELECT
USING (
  -- User is the owner of the project
  EXISTS (
    SELECT 1
    FROM projects
    WHERE projects.id = expense_categories.project_id
    AND projects.owner_id = auth.uid()
  )
  OR
  -- User is a member of this project
  EXISTS (
    SELECT 1
    FROM project_members
    WHERE project_members.project_id = expense_categories.project_id
    AND project_members.user_id = auth.uid()
  )
);

-- Transactions policy
CREATE POLICY "transactions_view_policy"
ON transactions
FOR SELECT
USING (
  -- User created the transaction
  user_id = auth.uid()
  OR
  -- User is the owner of the project
  EXISTS (
    SELECT 1
    FROM projects
    WHERE projects.id = transactions.project_id
    AND projects.owner_id = auth.uid()
  )
  OR
  -- User is a member of this project
  EXISTS (
    SELECT 1
    FROM project_members
    WHERE project_members.project_id = transactions.project_id
    AND project_members.user_id = auth.uid()
  )
);