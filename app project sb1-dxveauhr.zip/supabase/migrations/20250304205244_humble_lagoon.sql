-- Add last_modified and modified_by to expense_categories
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'expense_categories' AND column_name = 'last_modified'
  ) THEN
    ALTER TABLE expense_categories ADD COLUMN last_modified timestamptz DEFAULT now();
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'expense_categories' AND column_name = 'modified_by'
  ) THEN
    ALTER TABLE expense_categories ADD COLUMN modified_by uuid REFERENCES auth.users(id);
  END IF;
END $$;

-- Add category_history table to track changes
CREATE TABLE IF NOT EXISTS category_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id uuid REFERENCES expense_categories(id) ON DELETE CASCADE,
  changed_by uuid REFERENCES auth.users(id),
  change_type text NOT NULL CHECK (change_type IN ('create', 'update', 'delete', 'reorder')),
  old_values jsonb,
  new_values jsonb,
  changed_at timestamptz DEFAULT now()
);

-- Enable RLS on category_history
ALTER TABLE category_history ENABLE ROW LEVEL SECURITY;

-- Create policies for category_history
CREATE POLICY "project_leaders_can_view_history"
ON category_history
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM expense_categories ec
    JOIN project_members pm ON pm.project_id = ec.project_id
    WHERE ec.id = category_history.category_id
    AND pm.user_id = auth.uid()
    AND pm.role IN ('project_leader', 'admin')
  )
);

-- Create trigger to track category changes
CREATE OR REPLACE FUNCTION track_category_changes()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    INSERT INTO category_history (
      category_id,
      changed_by,
      change_type,
      new_values
    ) VALUES (
      NEW.id,
      auth.uid(),
      'create',
      row_to_json(NEW)
    );
  ELSIF TG_OP = 'UPDATE' THEN
    INSERT INTO category_history (
      category_id,
      changed_by,
      change_type,
      old_values,
      new_values
    ) VALUES (
      NEW.id,
      auth.uid(),
      CASE 
        WHEN NEW.order_index != OLD.order_index THEN 'reorder'
        ELSE 'update'
      END,
      row_to_json(OLD),
      row_to_json(NEW)
    );
  ELSIF TG_OP = 'DELETE' THEN
    INSERT INTO category_history (
      category_id,
      changed_by,
      change_type,
      old_values
    ) VALUES (
      OLD.id,
      auth.uid(),
      'delete',
      row_to_json(OLD)
    );
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create triggers for tracking changes
DROP TRIGGER IF EXISTS category_audit_trigger ON expense_categories;
CREATE TRIGGER category_audit_trigger
  AFTER INSERT OR UPDATE OR DELETE ON expense_categories
  FOR EACH ROW EXECUTE FUNCTION track_category_changes();