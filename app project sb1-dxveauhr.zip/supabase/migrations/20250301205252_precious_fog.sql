-- Create translations table if it doesn't exist
CREATE TABLE IF NOT EXISTS translations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  language_code text NOT NULL,
  key text NOT NULL,
  value text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(language_code, key)
);

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_translations_language_key ON translations(language_code, key);

-- Enable Row Level Security
ALTER TABLE translations ENABLE ROW LEVEL SECURITY;

-- Create policies (only if they don't exist)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'translations' AND policyname = 'Anyone can read translations'
  ) THEN
    CREATE POLICY "Anyone can read translations"
      ON translations
      FOR SELECT
      USING (true);
  END IF;
END $$;

-- Set first admin user
DO $$
DECLARE
  first_user_id uuid;
BEGIN
  -- Get the first user in the system to make them an admin
  SELECT id INTO first_user_id FROM profiles LIMIT 1;
  
  IF first_user_id IS NOT NULL THEN
    -- Check if is_admin column exists before updating
    IF EXISTS (
      SELECT 1 FROM information_schema.columns
      WHERE table_name = 'profiles' AND column_name = 'is_admin'
    ) THEN
      UPDATE profiles SET is_admin = true WHERE id = first_user_id;
    END IF;
  END IF;
END $$;