-- Add is_admin column to profiles table if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'is_admin'
  ) THEN
    ALTER TABLE profiles ADD COLUMN is_admin boolean NOT NULL DEFAULT false;
    
    -- Add an index on the is_admin column
    CREATE INDEX idx_profiles_is_admin ON profiles(is_admin);
  END IF;
END $$;

-- Add project_leader role to project_members if it doesn't exist
DO $$
BEGIN
  -- Ensure the role column has the correct constraint
  ALTER TABLE project_members DROP CONSTRAINT IF EXISTS project_members_role_check;
  ALTER TABLE project_members ADD CONSTRAINT project_members_role_check 
    CHECK (role IN ('admin', 'member', 'project_leader'));
END $$;

-- Add available_parts column to projects table if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'projects' AND column_name = 'available_parts'
  ) THEN
    ALTER TABLE projects ADD COLUMN available_parts integer DEFAULT 100;
  END IF;
END $$;

-- Add user_parts table to track user contributions to projects
CREATE TABLE IF NOT EXISTS user_parts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid REFERENCES projects(id) ON DELETE CASCADE NOT NULL,
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  parts_requested integer DEFAULT 0,
  parts_approved integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(project_id, user_id)
);

-- Enable Row Level Security on user_parts
ALTER TABLE user_parts ENABLE ROW LEVEL SECURITY;

-- Create policies for user_parts
CREATE POLICY "users_can_view_own_parts"
ON user_parts
FOR SELECT
USING (user_id = auth.uid());

CREATE POLICY "users_can_request_parts"
ON user_parts
FOR INSERT
WITH CHECK (user_id = auth.uid());

CREATE POLICY "users_can_update_own_requests"
ON user_parts
FOR UPDATE
USING (user_id = auth.uid())
WITH CHECK (
  -- Users can only update their requested parts, not approved parts
  parts_approved = (SELECT parts_approved FROM user_parts WHERE id = user_parts.id)
);

CREATE POLICY "admins_can_manage_all_parts"
ON user_parts
FOR ALL
USING (
  EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.is_admin = true
  )
);

CREATE POLICY "project_leaders_can_manage_project_parts"
ON user_parts
FOR ALL
USING (
  EXISTS (
    SELECT 1 FROM project_members
    WHERE project_members.project_id = user_parts.project_id
    AND project_members.user_id = auth.uid()
    AND project_members.role = 'project_leader'
  )
);