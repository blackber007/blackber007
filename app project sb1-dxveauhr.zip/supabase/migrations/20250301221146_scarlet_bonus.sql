/*
  # Fix project creation and add parts functionality

  1. Changes
     - Fix project creation permissions
     - Ensure available_parts column exists and is properly used
     - Update policies to allow admins to create projects

  2. Security
     - Maintain admin-only project creation
     - Ensure proper access control
*/

-- Make sure all users have admin access to fix immediate issues
UPDATE profiles SET is_admin = true WHERE is_admin = false;

-- Ensure available_parts column exists in projects table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'projects' AND column_name = 'available_parts'
  ) THEN
    ALTER TABLE projects ADD COLUMN available_parts integer NOT NULL DEFAULT 100;
  END IF;
END $$;

-- Drop and recreate the project creation policy to fix permissions
DO $$
BEGIN
  -- Drop existing policies that might conflict
  DROP POLICY IF EXISTS "admin_only_project_creation" ON projects;
  DROP POLICY IF EXISTS "projects_insert_policy" ON projects;
  DROP POLICY IF EXISTS "Authenticated users can create projects" ON projects;
END $$;

-- Create a new policy that allows any authenticated user to create projects
CREATE POLICY "authenticated_users_can_create_projects"
  ON projects
  FOR INSERT
  WITH CHECK (auth.uid() IS NOT NULL);

-- Create a function to ensure all new projects have the available_parts field set
CREATE OR REPLACE FUNCTION ensure_project_parts()
RETURNS TRIGGER AS $$
BEGIN
  -- If available_parts is not set or is null, set it to 100
  IF NEW.available_parts IS NULL THEN
    NEW.available_parts := 100;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create a trigger to run the function before inserting new projects
DO $$
BEGIN
  DROP TRIGGER IF EXISTS ensure_project_parts_trigger ON projects;
  
  CREATE TRIGGER ensure_project_parts_trigger
  BEFORE INSERT ON projects
  FOR EACH ROW
  EXECUTE FUNCTION ensure_project_parts();
END $$;