-- First check if policies exist and drop them
DO $$
BEGIN
  -- Drop policies if they exist
  DROP POLICY IF EXISTS "Admins can manage imported data" ON imported_excel_data;
  DROP POLICY IF EXISTS "All authenticated users can view imported data" ON imported_excel_data;
END $$;

-- Create imported_excel_data table if it doesn't exist
CREATE TABLE IF NOT EXISTS imported_excel_data (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  full_name text,
  company text,
  position text,
  phone text,
  imported_at timestamptz DEFAULT now()
);

-- Create index on email for faster lookups
CREATE INDEX IF NOT EXISTS idx_imported_excel_data_email ON imported_excel_data(email);

-- Enable Row Level Security
ALTER TABLE imported_excel_data ENABLE ROW LEVEL SECURITY;

-- Create policies for imported_excel_data
CREATE POLICY "Admins can manage imported data"
  ON imported_excel_data
  FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.is_admin = true
    )
  );

CREATE POLICY "All authenticated users can view imported data"
  ON imported_excel_data
  FOR SELECT
  USING (auth.role() = 'authenticated');