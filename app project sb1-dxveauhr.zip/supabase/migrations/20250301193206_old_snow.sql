/*
  # Fix recursion in RLS policies

  1. Changes
    - Replace potentially recursive policies with non-recursive alternatives
    - Improve project_members policy to avoid self-reference
    - Add more efficient policies for transactions and expense_categories
  
  2. Security
    - Maintain same security model but with better performance
    - Ensure all tables still have proper RLS protection
*/

-- Replace potentially recursive project_members policy
DROP POLICY IF EXISTS "Users can view members of projects they belong to" ON project_members;

CREATE POLICY "select_project_members"
ON "project_members"
FOR SELECT
USING (
  -- Ensure this policy does not reference itself or cause recursion
  EXISTS (
    SELECT 1
    FROM projects
    WHERE projects.id = project_members.project_id
    AND projects.owner_id = auth.uid()
  )
  OR
  -- Allow users to see members of projects they are directly part of
  project_id IN (
    SELECT id FROM projects WHERE owner_id = auth.uid()
  )
);

-- Improve expense_categories policy to avoid recursion
DROP POLICY IF EXISTS "Users can view categories of projects they belong to" ON expense_categories;

CREATE POLICY "select_expense_categories"
ON "expense_categories"
FOR SELECT
USING (
  -- Direct project ownership check
  EXISTS (
    SELECT 1
    FROM projects
    WHERE projects.id = expense_categories.project_id
    AND projects.owner_id = auth.uid()
  )
  OR
  -- Project membership check without recursion
  expense_categories.project_id IN (
    SELECT id FROM projects WHERE owner_id = auth.uid()
  )
);

-- Improve transactions policy to avoid recursion
DROP POLICY IF EXISTS "Users can view transactions of projects they belong to" ON transactions;

CREATE POLICY "select_transactions"
ON "transactions"
FOR SELECT
USING (
  -- Direct project ownership check
  EXISTS (
    SELECT 1
    FROM projects
    WHERE projects.id = transactions.project_id
    AND projects.owner_id = auth.uid()
  )
  OR
  -- Project membership check without recursion
  transactions.project_id IN (
    SELECT id FROM projects WHERE owner_id = auth.uid()
  )
  OR
  -- User's own transactions
  transactions.user_id = auth.uid()
);