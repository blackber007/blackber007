/*
  # Add status field to projects table

  1. Changes
    - Add `status` column to the `projects` table with default value 'active'
    - Add index on the `status` column for better query performance
  
  2. Notes
    - This migration assumes the tables and policies already exist from previous migrations
*/

-- Add status column to projects table if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'projects' AND column_name = 'status'
  ) THEN
    ALTER TABLE projects ADD COLUMN status text NOT NULL DEFAULT 'active';
    
    -- Add an index on the status column
    CREATE INDEX idx_projects_status ON projects(status);
    
    -- Add a check constraint to ensure status is one of the allowed values
    ALTER TABLE projects ADD CONSTRAINT projects_status_check 
      CHECK (status IN ('active', 'completed', 'archived'));
  END IF;
END $$;