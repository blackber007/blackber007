/*
  # Final fix for infinite recursion in RLS policies

  1. Changes
    - Ensure all previous policies are dropped
    - Implement clean, non-recursive policies for all tables
    - Fix any remaining circular references
  
  2. Security
    - Maintain same security model but eliminate recursion
    - Ensure all tables still have proper RLS protection
*/

-- Drop all potentially recursive policies first to ensure a clean slate
DROP POLICY IF EXISTS "projects_view_policy" ON projects;
DROP POLICY IF EXISTS "project_members_view_policy" ON project_members;
DROP POLICY IF EXISTS "expense_categories_view_policy" ON expense_categories;
DROP POLICY IF EXISTS "transactions_view_policy" ON transactions;

-- Create new non-recursive policies with optimized queries

-- Projects policy - fundamental policy that others depend on
CREATE POLICY "projects_view_policy" 
ON projects
FOR SELECT
USING (
  -- User is the owner of the project (direct ownership)
  owner_id = auth.uid()
  OR
  -- User is a member of the project (direct membership check)
  id IN (
    SELECT project_id 
    FROM project_members
    WHERE user_id = auth.uid()
  )
);

-- Project members policy
CREATE POLICY "project_members_view_policy"
ON project_members
FOR SELECT
USING (
  -- User is a member of this project
  user_id = auth.uid()
  OR
  -- User is the owner of the project
  project_id IN (
    SELECT id
    FROM projects
    WHERE owner_id = auth.uid()
  )
);

-- Expense categories policy
CREATE POLICY "expense_categories_view_policy"
ON expense_categories
FOR SELECT
USING (
  -- User is the owner of the project
  project_id IN (
    SELECT id
    FROM projects
    WHERE owner_id = auth.uid()
  )
  OR
  -- User is a member of this project
  project_id IN (
    SELECT project_id
    FROM project_members
    WHERE user_id = auth.uid()
  )
);

-- Transactions policy
CREATE POLICY "transactions_view_policy"
ON transactions
FOR SELECT
USING (
  -- User created the transaction
  user_id = auth.uid()
  OR
  -- User is the owner of the project
  project_id IN (
    SELECT id
    FROM projects
    WHERE owner_id = auth.uid()
  )
  OR
  -- User is a member of this project
  project_id IN (
    SELECT project_id
    FROM project_members
    WHERE user_id = auth.uid()
  )
);