-- Add translations for admin-only project creation
DO $$
BEGIN
  -- Add English translations
  INSERT INTO translations (language_code, key, value)
  VALUES 
    ('en', 'projects.adminOnlyCreate', 'Only administrators can create new projects'),
    ('en', 'projects.adminOnlyCreateInfo', 'Only administrators can create new projects. Please contact an administrator if you need to create a project.'),
    ('en', 'projects.userNotFound', 'User not found with this email'),
    ('en', 'projects.alreadyMember', 'User is already a member of this project'),
    ('en', 'projects.noDescription', 'No description')
  ON CONFLICT (language_code, key) DO UPDATE
  SET value = EXCLUDED.value;
  
  -- Add Spanish translations
  INSERT INTO translations (language_code, key, value)
  VALUES 
    ('es', 'projects.adminOnlyCreate', 'Solo los administradores pueden crear nuevos proyectos'),
    ('es', 'projects.adminOnlyCreateInfo', 'Solo los administradores pueden crear nuevos proyectos. Póngase en contacto con un administrador si necesita crear un proyecto.'),
    ('es', 'projects.userNotFound', 'Usuario no encontrado con este correo electrónico'),
    ('es', 'projects.alreadyMember', 'El usuario ya es miembro de este proyecto'),
    ('es', 'projects.noDescription', 'Sin descripción')
  ON CONFLICT (language_code, key) DO UPDATE
  SET value = EXCLUDED.value;
  
  -- Add French translations
  INSERT INTO translations (language_code, key, value)
  VALUES 
    ('fr', 'projects.adminOnlyCreate', 'Seuls les administrateurs peuvent créer de nouveaux projets'),
    ('fr', 'projects.adminOnlyCreateInfo', 'Seuls les administrateurs peuvent créer de nouveaux projets. Veuillez contacter un administrateur si vous avez besoin de créer un projet.'),
    ('fr', 'projects.userNotFound', 'Utilisateur non trouvé avec cet e-mail'),
    ('fr', 'projects.alreadyMember', 'L''utilisateur est déjà membre de ce projet'),
    ('fr', 'projects.noDescription', 'Pas de description')
  ON CONFLICT (language_code, key) DO UPDATE
  SET value = EXCLUDED.value;
  
  -- Add German translations
  INSERT INTO translations (language_code, key, value)
  VALUES 
    ('de', 'projects.adminOnlyCreate', 'Nur Administratoren können neue Projekte erstellen'),
    ('de', 'projects.adminOnlyCreateInfo', 'Nur Administratoren können neue Projekte erstellen. Bitte kontaktieren Sie einen Administrator, wenn Sie ein Projekt erstellen müssen.'),
    ('de', 'projects.userNotFound', 'Benutzer mit dieser E-Mail nicht gefunden'),
    ('de', 'projects.alreadyMember', 'Benutzer ist bereits Mitglied dieses Projekts'),
    ('de', 'projects.noDescription', 'Keine Beschreibung')
  ON CONFLICT (language_code, key) DO UPDATE
  SET value = EXCLUDED.value;
  
  -- Add Portuguese translations
  INSERT INTO translations (language_code, key, value)
  VALUES 
    ('pt', 'projects.adminOnlyCreate', 'Apenas administradores podem criar novos projetos'),
    ('pt', 'projects.adminOnlyCreateInfo', 'Apenas administradores podem criar novos projetos. Entre em contato com um administrador se precisar criar um projeto.'),
    ('pt', 'projects.userNotFound', 'Usuário não encontrado com este e-mail'),
    ('pt', 'projects.alreadyMember', 'O usuário já é membro deste projeto'),
    ('pt', 'projects.noDescription', 'Sem descrição')
  ON CONFLICT (language_code, key) DO UPDATE
  SET value = EXCLUDED.value;
EXCEPTION
  WHEN undefined_table THEN
    NULL;
END $$;