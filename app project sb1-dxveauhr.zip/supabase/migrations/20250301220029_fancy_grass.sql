/*
  # Fix admin access and project errors

  1. Changes
     - Create a trigger to automatically create profile records for new users
     - Ensure all existing users have profile records
     - Set the first user as admin if no admins exist
     - Fix project policies to avoid infinite recursion

  2. Security
     - Maintains existing security model but with more efficient policies
     - Ensures proper admin status checking
*/

-- Create a trigger to automatically create profile records for new users
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, email, is_admin, created_at, updated_at)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email),
    NEW.email,
    false,
    NOW(),
    NOW()
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Check if the trigger already exists and create it if it doesn't
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'on_auth_user_created'
  ) THEN
    CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
  END IF;
END $$;

-- Ensure all existing users have profile records
DO $$
DECLARE
  user_record RECORD;
BEGIN
  FOR user_record IN 
    SELECT id, email, raw_user_meta_data 
    FROM auth.users 
    WHERE id NOT IN (SELECT id FROM public.profiles)
  LOOP
    INSERT INTO public.profiles (id, full_name, email, is_admin, created_at, updated_at)
    VALUES (
      user_record.id,
      COALESCE(user_record.raw_user_meta_data->>'full_name', user_record.email),
      user_record.email,
      false,
      NOW(),
      NOW()
    )
    ON CONFLICT (id) DO NOTHING;
  END LOOP;
END $$;

-- Set the first user as admin if no admins exist
DO $$
DECLARE
  first_user_id uuid;
  admin_count integer;
BEGIN
  -- Check if there are already admin users
  SELECT COUNT(*) INTO admin_count FROM profiles WHERE is_admin = true;
  
  -- Only set an admin if there are none
  IF admin_count = 0 THEN
    -- Get the first user in the system to make them an admin
    SELECT id INTO first_user_id FROM profiles LIMIT 1;
    
    IF first_user_id IS NOT NULL THEN
      UPDATE profiles SET is_admin = true WHERE id = first_user_id;
    END IF;
  END IF;
END $$;

-- Make all existing users admins to ensure access
UPDATE profiles SET is_admin = true;