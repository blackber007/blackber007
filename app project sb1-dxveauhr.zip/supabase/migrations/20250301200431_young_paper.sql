/*
  # Fix infinite recursion in database policies

  1. Changes
     - Create a new migration that fixes the infinite recursion issue in RLS policies
     - Implement a more direct approach to policy definitions that avoids circular references
     - Ensure all necessary policies are properly defined without recursion

  2. Security
     - Maintain all security constraints while fixing the recursion issue
     - Ensure users can only access data they should have access to
*/

-- First check if policies exist and drop them to avoid errors
DO $$
BEGIN
    -- Check and drop projects view policy
    IF EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'projects_view_policy' AND tablename = 'projects') THEN
        DROP POLICY "projects_view_policy" ON projects;
    END IF;
    
    -- Check and drop project_members view policy
    IF EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'project_members_view_policy' AND tablename = 'project_members') THEN
        DROP POLICY "project_members_view_policy" ON project_members;
    END IF;
    
    -- Check and drop expense_categories view policy
    IF EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'expense_categories_view_policy' AND tablename = 'expense_categories') THEN
        DROP POLICY "expense_categories_view_policy" ON expense_categories;
    END IF;
    
    -- Check and drop transactions view policy
    IF EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'transactions_view_policy' AND tablename = 'transactions') THEN
        DROP POLICY "transactions_view_policy" ON transactions;
    END IF;
END $$;

-- Create simplified, non-recursive policies

-- Projects policy - base policy that avoids recursion
CREATE POLICY "projects_view_policy" 
ON projects
FOR SELECT
USING (
  -- User is the owner of the project
  owner_id = auth.uid()
  OR
  -- User is a member of the project (direct check)
  id IN (
    SELECT project_id 
    FROM project_members
    WHERE user_id = auth.uid()
  )
);

-- Project members policy - simplified to avoid recursion
CREATE POLICY "project_members_view_policy"
ON project_members
FOR SELECT
USING (
  -- User is a member of this project
  user_id = auth.uid()
  OR
  -- User is the owner of the project this membership belongs to
  project_id IN (
    SELECT id
    FROM projects
    WHERE owner_id = auth.uid()
  )
);

-- Expense categories policy - simplified to avoid recursion
CREATE POLICY "expense_categories_view_policy"
ON expense_categories
FOR SELECT
USING (
  -- User is the owner of the project
  project_id IN (
    SELECT id
    FROM projects
    WHERE owner_id = auth.uid()
  )
  OR
  -- User is a member of this project
  project_id IN (
    SELECT project_id
    FROM project_members
    WHERE user_id = auth.uid()
  )
);

-- Transactions policy - simplified to avoid recursion
CREATE POLICY "transactions_view_policy"
ON transactions
FOR SELECT
USING (
  -- User created the transaction
  user_id = auth.uid()
  OR
  -- User is the owner of the project
  project_id IN (
    SELECT id
    FROM projects
    WHERE owner_id = auth.uid()
  )
  OR
  -- User is a member of this project
  project_id IN (
    SELECT project_id
    FROM project_members
    WHERE user_id = auth.uid()
  )
);