/*
  # Fix policies and admin status check

  1. Changes
     - Fix infinite recursion in policies by simplifying them
     - Ensure all users have a profile record to prevent admin status check errors
     - Create a trigger to automatically create profile records for new users

  2. Security
     - Maintains existing security model but with more efficient policies
     - Ensures proper admin status checking
*/

-- First, drop all potentially recursive policies
DO $$
BEGIN
    -- Drop projects policies if they exist
    DROP POLICY IF EXISTS "projects_view_policy" ON projects;
    DROP POLICY IF EXISTS "projects_insert_policy" ON projects;
    DROP POLICY IF EXISTS "users_can_view_their_projects" ON projects;
    DROP POLICY IF EXISTS "projects_update_policy" ON projects;
    DROP POLICY IF EXISTS "projects_delete_policy" ON projects;
    DROP POLICY IF EXISTS "admin_only_project_creation" ON projects;
    
    -- Drop project_members policies if they exist
    DROP POLICY IF EXISTS "project_members_view_policy" ON project_members;
    DROP POLICY IF EXISTS "project_members_all_policy" ON project_members;
    
    -- Drop expense_categories policies if they exist
    DROP POLICY IF EXISTS "expense_categories_view_policy" ON expense_categories;
    DROP POLICY IF EXISTS "expense_categories_all_policy" ON expense_categories;
    
    -- Drop transactions policies if they exist
    DROP POLICY IF EXISTS "transactions_view_policy" ON transactions;
    DROP POLICY IF EXISTS "transactions_insert_policy" ON transactions;
    DROP POLICY IF EXISTS "transactions_update_own_policy" ON transactions;
    DROP POLICY IF EXISTS "transactions_update_admin_policy" ON transactions;
    DROP POLICY IF EXISTS "transactions_delete_policy" ON transactions;
    DROP POLICY IF EXISTS "admins_can_add_transactions" ON transactions;
    DROP POLICY IF EXISTS "admins_can_update_transactions" ON transactions;
    DROP POLICY IF EXISTS "admins_can_delete_transactions" ON transactions;
END $$;

-- Create simplified, non-recursive policies

-- Projects policies
CREATE POLICY "projects_view_policy" 
ON projects
FOR SELECT
USING (
  -- User is the owner of the project
  owner_id = auth.uid()
  OR
  -- User is a member of the project (direct check)
  id IN (
    SELECT project_id 
    FROM project_members
    WHERE user_id = auth.uid()
  )
);

CREATE POLICY "projects_update_policy"
ON projects
FOR UPDATE
USING (owner_id = auth.uid());

CREATE POLICY "projects_delete_policy"
ON projects
FOR DELETE
USING (owner_id = auth.uid());

CREATE POLICY "admin_only_project_creation"
ON projects
FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.is_admin = true
  )
);

-- Project members policies
CREATE POLICY "project_members_view_policy"
ON project_members
FOR SELECT
USING (
  -- User is a member of this project
  user_id = auth.uid()
  OR
  -- User is the owner of the project this membership belongs to
  project_id IN (
    SELECT id
    FROM projects
    WHERE owner_id = auth.uid()
  )
);

CREATE POLICY "project_members_all_policy"
ON project_members
FOR ALL
USING (
  EXISTS (
    SELECT 1 FROM project_members
    WHERE project_members.project_id = project_id
    AND project_members.user_id = auth.uid()
    AND project_members.role = 'admin'
  )
);

-- Expense categories policies
CREATE POLICY "expense_categories_view_policy"
ON expense_categories
FOR SELECT
USING (
  -- User is the owner of the project
  project_id IN (
    SELECT id
    FROM projects
    WHERE owner_id = auth.uid()
  )
  OR
  -- User is a member of this project
  project_id IN (
    SELECT project_id
    FROM project_members
    WHERE user_id = auth.uid()
  )
);

CREATE POLICY "expense_categories_all_policy"
ON expense_categories
FOR ALL
USING (
  EXISTS (
    SELECT 1 FROM project_members
    WHERE project_members.project_id = project_id
    AND project_members.user_id = auth.uid()
    AND project_members.role = 'admin'
  )
);

-- Transactions policies
CREATE POLICY "transactions_view_policy"
ON transactions
FOR SELECT
USING (
  -- User created the transaction
  user_id = auth.uid()
  OR
  -- User is the owner of the project
  project_id IN (
    SELECT id
    FROM projects
    WHERE owner_id = auth.uid()
  )
  OR
  -- User is a member of this project
  project_id IN (
    SELECT project_id
    FROM project_members
    WHERE user_id = auth.uid()
  )
);

CREATE POLICY "admins_can_add_transactions"
ON transactions
FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1 FROM project_members
    WHERE project_members.project_id = project_id
    AND project_members.user_id = auth.uid()
    AND project_members.role = 'admin'
  )
);

CREATE POLICY "admins_can_update_transactions"
ON transactions
FOR UPDATE
USING (
  EXISTS (
    SELECT 1 FROM project_members
    WHERE project_members.project_id = project_id
    AND project_members.user_id = auth.uid()
    AND project_members.role = 'admin'
  )
);

CREATE POLICY "admins_can_delete_transactions"
ON transactions
FOR DELETE
USING (
  EXISTS (
    SELECT 1 FROM project_members
    WHERE project_members.project_id = project_id
    AND project_members.user_id = auth.uid()
    AND project_members.role = 'admin'
  )
);

-- Create a trigger to automatically create profile records for new users
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, email, is_admin, created_at, updated_at)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email),
    NEW.email,
    false,
    NOW(),
    NOW()
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Check if the trigger already exists and create it if it doesn't
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'on_auth_user_created'
  ) THEN
    CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
  END IF;
END $$;

-- Ensure all existing users have profile records
DO $$
DECLARE
  user_record RECORD;
BEGIN
  FOR user_record IN 
    SELECT id, email, raw_user_meta_data 
    FROM auth.users 
    WHERE id NOT IN (SELECT id FROM public.profiles)
  LOOP
    INSERT INTO public.profiles (id, full_name, email, is_admin, created_at, updated_at)
    VALUES (
      user_record.id,
      COALESCE(user_record.raw_user_meta_data->>'full_name', user_record.email),
      user_record.email,
      false,
      NOW(),
      NOW()
    )
    ON CONFLICT (id) DO NOTHING;
  END LOOP;
END $$;

-- Set the first user as admin if no admins exist
DO $$
DECLARE
  first_user_id uuid;
  admin_count integer;
BEGIN
  -- Check if there are already admin users
  SELECT COUNT(*) INTO admin_count FROM profiles WHERE is_admin = true;
  
  -- Only set an admin if there are none
  IF admin_count = 0 THEN
    -- Get the first user in the system to make them an admin
    SELECT id INTO first_user_id FROM profiles LIMIT 1;
    
    IF first_user_id IS NOT NULL THEN
      UPDATE profiles SET is_admin = true WHERE id = first_user_id;
    END IF;
  END IF;
END $$;