-- Create bank_accounts table
CREATE TABLE IF NOT EXISTS bank_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  account_number text,
  bank_name text NOT NULL,
  withdrawal_fee numeric(15, 2) DEFAULT 0,
  transfer_fee numeric(15, 2) DEFAULT 0,
  currency text NOT NULL DEFAULT 'USD',
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE bank_accounts ENABLE ROW LEVEL SECURITY;

-- Create policies for bank_accounts
CREATE POLICY "admins_can_manage_bank_accounts"
ON bank_accounts
FOR ALL
USING (
  EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.is_admin = true
  )
);

CREATE POLICY "members_can_view_bank_accounts"
ON bank_accounts
FOR SELECT
USING (true);